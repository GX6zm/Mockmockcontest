# 项目交接（PROGRESS · 给下一个 AGENT）

> 最后更新：2026 10 19 21:40（Asia/Shanghai）
> 项目：`C:\Users\高新一中\Desktop\mockmockcontest` —— OI 校赛模拟器（Vite 6 + React 18 + TS，产物是双击即玩的单文件 `OI模拟赛.html`）
> 用户偏好：干活时**每一步都要向他报告**（含轮内步骤）；喜欢「数值要经得起推导，别拍脑袋」；说话偏简洁、要中文。

---

## 0. 一句话现状

- **两个模式都在用同一套比赛引擎**（M5）：教练模式的正赛/模拟赛复用观战的 `ContestScreen`（实时榜单、暂停、1x–4x、+10 分钟、到收卷、估分榜、公布真实成绩），默认观看、可「跳过观看」；`scripts/trace-check.mjs` 保证「即时结算」与「回放」同 seed 逐分一致。
- **教练模式 = 真实 OI 赛制三年生涯（M3–M6）**：一学年 32 周、每年 7 场正赛（CSP 初赛 9/19 → 复赛 10/31 → NOIP 11/29 → WC → 省选两试 → APIO → NOI 两试）；删掉 CSP-J 赛道（初赛全校一张 S 卷、笔试直接出分）；每题有难度区间、每场有「得分率曲线」把引擎分映射到真实分数区间；正赛虚构外校选手，按官方名额与分数线出省内排名/分位/奖项。单文件 **370 KB**，`tsc` 0。
- **所有学生数据都可手填**：`data/年级对照表.txt`（54 人真实年级）、`data/天赋对照表.txt`（用户已填 53/54）、`data/属性对照表.csv`（年级/性格/天赋/实力/8 知识点/7 元能力，54 人全列）。改完分别跑 `scripts/grades.mjs`、`scripts/talent.mjs`、`scripts/profile.mjs`。
- **随机事件** 7 模板、约 62%/周（§2.4）；选手详情面板展示全部属性与本学期每场成绩。
- **校验入口**：`scripts/career-check.mjs`（三年生涯校准，约 9 分钟）、`coach-smoke.mjs`（`--full` 跑完整届 + 6 张截图）、`e2e-check.mjs`（观战 20s）、`trace-check.mjs`（回放一致性）。每次跑完自动追加 `logs/verify.log`，历史改动见 `CHANGELOG.md`。
## 1. 环境与命令（关键：PATH 上没有 node / npm / git）

```powershell
$deps = "C:\Users\高新一中\.dsh\dsh-runtimes\dsh-next-primary-runtime\dependencies"
& "$deps\node\bin\node.exe"            # node（v24.21.0，可直接 import .ts，不需要 ts-node）
& "$deps\node\bin\node.exe" node_modules/typescript/bin/tsc --noEmit     # 类型检查（注意是 node_modules，不是 .node_modules）
& "$deps\node\bin\node.exe" node_modules/vite/bin/vite.js build           # 构建到 dist/
& "$deps\node\bin\node.exe" scripts/inline.mjs                            # 把 dist 内联成单文件 OI模拟赛.html
```

- 没有 git，没有 npm；`package.json` 里的脚本只能手动等价执行。
- 单文件产物约 300 KB，双击即玩；`scripts/e2e-check.mjs`（观战）和 `scripts/coach-smoke.mjs`（教练）都用 CDP 驱动无头 Edge 打开这个产物跑完整流程并截图。
- 沙箱里 `msedge --dump-dom` 输出 0 字节（不可用于静态验证）；e2e 走 CDP 是可行的。
- pwsh 控制台里中文可能显示成乱码（GBK），文件本身是 UTF-8，别被吓到。

## 2. 本轮完成的三块

### 2.1 挂分 / 估分模型重构（用户最关心，已完成）

用户原话要点：**"挂分幅度太大。幅度越大挂出的概率应该越低（代码 CE -100 的概率远小于精度 -10）；减少反挂，一般不可能反挂超过 40；平均挂分 10~20 即可。"**

核心思路改动：**估分不再是"期望值"，而是"选手自测知道的那份干净分"**。正赛发了大样例，选手自测完基本知道自己哪些子任务过了；暗病（赛后才知道的挂分）才不可知。于是 `估分误差 = 挂分 + 少量自我认知噪声`，尾部完全可控。

`src/game.ts` 现在的实现（行号会漂，函数名稳定）：

- `bugChance()` @646：挂分概率
  ```ts
  let bugP = (0.235 + (p.detail / 100) * 0.15) * clamp(0.55 + p.difficulty / 110, 0.65, 1.5)
    - st.skills.debug * 0.04 - (tested ? 0.05 : 0) - debugRounds * 0.025 - (mode === 'brute' ? 0.03 : 0);
  bugP *= 1 - 0.55 * fam;            // 顺手题手抖也少
  return clamp(bugP, 0.03, 0.5);
  ```
- `tleChance()` @659：只作为"原因风味"出现，不再是独立击杀机制。
- `expectedScore()` @671：确定性期望分，**只给 AI 决策用**（`decide`/`chooseRetry`），不展示。
- `beliefOf()` @683：估分 = `clean + (性格 bias − 全校均值) × 0.3 + gauss × (1.5 + 2.5×(1−selfAwareness))`，四舍五入到 10，clamp 0–100；另有 0.3% 概率严重低估（`clean − 30 − rng×30`）= **天神眷顾**。
- `applyDamage()` @695：**挂分梯子**，越狠越少见
  | 概率 | 打掉 | 理由文案 |
  |---|---|---|
  | 0.70 | 最小的一个子任务 | `WA · 精度写挂`（math/geometry/impl）或 `WA · 边界没处理好` |
  | 0.20 | 最大的一个 | `TLE · 常数被卡` / `WA · 多测没清空` |
  | 0.07 | 两个最大的 | 同上 |
  | 0.03 | 全灭 | `RE · 数组开小` / `CE · freopen 写错` / `WA · 算法有反例` |
- `submitAttempt()` @736：先按 `subtaskPass(gap, i, 0, p.level)` 抽 `passed[]` 得 `clean` → `est = beliefOf(clean)` → `truth = applyDamage(clean)`；最后 15 分钟内还有 `1.2% × (1 − debug×0.6)` 的**匆忙交卷忘写 freopen → CE 爆零**。
- `decide()` @777：用 `expectedScore` 决策，`doubt` 取刚记录的 `attempt.est`。

**校准结果（`scripts/calib.mjs`，40 场 × 54 人，校赛 3 题 levels [3,4,5] 180min，seed 20261018+s）**

| 指标 | 数值 |
|---|---|
| 平均真分 | 124.3 / 300 |
| 平均估分 | 136.2 |
| 平均挂分 | **−11.8**（中位 −10） |
| 估准（\|差\| ≤ 20） | 84.3% |
| 挂分 ≥ 41 | 6.3% |
| 反挂 ≥ 41 | **0.0%**（最大 +40） |
| 挂穿（估 ≥60 真 0） | 0.1% |
| AK 率 | 1.48% |

幅度递减（`scripts/calib-detail.mjs`）：0–10 分 **24.9%** → 11–20 12.2% → 21–30 4.6% → 31–40 4.3% → 41–60 3.3% → 61–80 2.4% → 81–100 0.8% → 100+ 0.5%。

### 2.2 NOI 模板（已完成）

`src/game.ts` `PRESETS`（@104）新增：

```ts
{ id: 'noi', name: 'NOI', note: '3 题 · 5 小时', levels: [5, 6, 7], minutes: 300, clock: '8:30–13:30' }
```

（NOI 正赛两天，每天 3 题 5 小时，这里跑其中一天。）设置页模板网格 `grid-cols-4` → `grid-cols-5`（`src/App.tsx:139`），README 模板表加了 NOI 行。跑 `scripts/sim-check.mjs`（12 场）确认难度合理：平均 AK 0%、平均分 33.4、最高 120–190、中位 10–40。

### 2.3 教练模式 M3：按真实 OI 赛制重做（10-19 晚，已完成）

用户原话（m00634）：「你这个根本就不是现实OI的模式啊，CSP初赛复赛,NOIP,WC,NOI在教练模式一个都没体现。还有为什么一个赛季就结束了？高一打完高二还要打呢呀？你不知道学生的年级信息就给我txt我来填啊」；后来（m01339）又要求：「自己搜索OI赛制，完善内容，不确定的都要查，查不到问我（比如初中生有体验名额可参赛NOIP,WC,NOI夏令营，并且S组只要过初赛就能正常参加），正赛结束展示学生全国排名（查资料确定参赛人数大概是多少，得多少分是多少分位、什么奖）并以此颁奖」。

**结论：旧版「校内 15% 省一 / 校内前 3 省队 / NOI 按得分率划线」全部作废。** 现在奖项 = 官方分数线折出的「全国分位」→ 官方奖项档；资格链按 2025–26 赛季官方通知。

**官方资料（已抓取，出处可复查）**

- CSP-J/S 2024 第二轮评级规则（noi.cn/xw/2024-11-19/834421.shtml）：S 一等基准线 165、拟评比例 20%、全国一等 5,505 人；二等基准 105（一等线 ≥165 的省：105+ 未获一等即二等，否则 60+）；三等 60；一等线低于基准的省不设三等。J：一等基准 250、拟评 8,085 人、二等 170、三等 80。名额 = (省均分−全国均分)×0.1%+20% 的一等名额 + 平衡项 + 晋级率奖励（≥20% 每 +10% 加 1，≤40%）；陕西 S 138 人（一等线 130/400）、J 161 人（225/400）。
- NOIP 2025 评奖规则（854070）：总获奖 67%（一等 20%、二等 22%、三等 25%），全国基准线 137/108/86；陕西 一等 128 分（32 人）、二等 95、三等 86。全国一等 1,545 人 ÷20% → 全国高中生参赛约 7,725 人。
- 陕西 CSP-J/S 2025 晋级（849265）：J 线 37.5、S 线 37；最低晋级 J 26 / S 24；优先晋级 J ≥75（全国前 10%）、S ≥62.5（前 25%）；**晋级人数 ≥ 第一轮实考 20%**；第二轮 2025-11-01；2026 陕西第一轮 9/19、第二轮 10/31。
- 陕西 NOIP 2025 报名通知（852459）：2025-11-29 8:30–13:00，4 题 4.5h，西工大附中；A/B 174 个 + C/D，总数 ≤240；资格 = 已参加 CSP-S 2025 第二轮 的陕西在籍在校**高中生**；A 类 30（前 30 名，男 ≥27 女 ≥3）；B1 87、B2 29、B3 28（NOI2024 金 8/银 4/铜 3 每枚，西安高新一中铜牌 → 3 个 B3 名额）；顺延 78 人、线 20 分；C/D 推荐（女生 D 类 12 个）；**低年级后备体验 ≤200 人（初二以下、推荐制、不授证书、成绩只通知学校）**。
- 陕西省选 2027 方案（853322）：两试 2027-03-07/08 各 4.5h、满分各 300；总分 = NOIP 2026（折算百分）×30% + 省选（两试和 ÷3）×70%；省队 = 总分前 5 进 A 类（含女生 1 名）+ 按名额进 B；同分依次比 NOIP、高年级、CSP-S2、CSP-S1；**单校 ≤ 省队 1/3**；陕西 8 名额 → 我校最多 2 人；初中生只能体验（非正式）。
- NOI2026 名额分配（854153）：全国 303（A 160 + B 143），陕西 A5+B3=8。
- NOI 2025 获奖规则（845949）：总获奖 85%；金 50、银 152（金银合并）、铜 85 且 ≥100 分；A 类自动 +5 分仅用于划线；夏令营 D/E 只有成绩证明；正式选手约 337 人（287÷0.85）。
- APIO 2025 中国区（842324）：28 省市 744 位师生；金 64 / 银 128 / 铜 193；线 193/130/80（满分 300）。
- WC 2026（853061）：2027-02-06~13 青岛；正式 / 非正式 / 超额 / AI 30 人；学生营员按 CSP-S 第二轮成绩、中学生在籍；测试不评金银铜。
- CSP-J/S 2025 解答（845928）：当年 9 月 1 日前满 12 周岁、任何人可报名，J/S 可同报、各两轮、都有证书；CSP 是认证不是竞赛。

**实现（`src/season.ts`）**

- `StageDef` 增 `national`（全国参赛人数）、`anchors`（得分率 → 全国分位锚点）、`bands`（奖项档）、`note`；`YEAR_STAGES` 按上表填死。
- 初赛：`prelimScoreOf` 不变；`passed = score >= 官方线 && pct <= 0.25`（名额 = 实考 20%，强校取前 25%）；`prelim` 行带 `nationalRank/pct`，结算页新增「组别 / 全国排名 / 前 X%」。
- （⚠️ M6 已废，见 §2.7：现在只有 S 组）复赛 `runCsp2`：J/S 分组各跑一场，按 `CSP2J_ANCHORS` / `stage.anchors` 折全国分位 → `rank = round(national × pct)`，`bandOf()` 发省一/二/三；S 组省一、省二进 NOIP；J 组奖加「J 组」前缀。
- 正式赛事 `runStage`：`eligOfficial` / `eligExperience` 两个资格函数（NOIP 后备体验、省选/NOI 初中体验）；省选总分 = NOIP 标准分 30% + 省选 70%（`anchors=[[0.87,0.05],[0.7,0.2],[0.55,0.5]]`，陕西 160 人、省队线前 5%），省队前 8 且单校 ≤2；NOIP/NOI/APIO 按 `bands` 发奖，NOI 铜牌额外要求 ≥100 分；体验名额不进 `awards`。
- `ContestRecap.national = {total, rows[{name,score,rank,pct,award,tone,team,note}]}`，结算页展示「全国排名 / 前 X%」列；`qualifiedFor` 与 `runStage` 同口径（正式 + 体验）。
- 年级仍六级（1 初一 ~ 6 高三）；`beginNextYear` 清空上一学年资格链、`grade===6` 毕业、补 6 初一 + 4 高一、新生名去重。生涯评分按每年平均产出（见 README）。

### 2.4 教练模式随机事件（10-19 新增，已完成）

**为什么加**：用户说「教练模式可以加随机事件（学生谈恋爱、文化课班主任谈话、校领导压力、家长焦虑）」。动机是让每周的决策有戏剧性——原来的教练模式每周只有一个决定（练什么 × 强度），16 周下来很像填表。

**设计**（数据驱动，不碰 `game.ts`）

- 新文件 `src/events.ts`：`EVENT_DEFS` 7 个模板 —— 早恋风波（感情）/ 班主任找上门（教学）/ 校领导的压力（行政）/ 家长焦虑（家庭）/ 隔壁学校约交流赛（机会）/ 有人感冒了（健康）/ 隔壁教练来挖人（竞争），每个 2–3 个选项。
- 选项效果用 `apply(ctx)` 回调返回 `EventPatch`：`log` 文案、`target` 指定某个队员、`team` 全队、`growthMult` 本周训练倍率。这样加事件只改 `events.ts`，`season.ts` 不用动。
- `season.ts`：`SeasonState` 加 `pendingEvent / eventLog / lastEventResult / weekMult`；`EVENT_CHANCE = 0.62`；`rollWeekEvent()` 用 `makeRng(seed*8191 + week*7331 + 3)`，跳过上一周的同名事件（避免连着两周撞同一件事），按 `weight` 加权抽；`chooseEventOption(s, optionId)` 应用 patch 并消耗随机数（选项里写「结果不确定」的才真随机）。
- 事件卡出现时**不能排训练**（`pendingEvent` 存在时隐藏训练面板，显示「处理完才能排训练」），选完显示「📌 本周插曲」；周赛结算页会回放当周事件（`data-testid="week-events"`）。
- 选项 `note` 故意写清数值（「心态 +6% · 疲劳 +6」「结果不确定：谈成了 +5%，谈崩了 −4%」）：训练报告模糊，但事件后果要可推理，否则选择变成盲抽。

**实测（可复现）**

- `node scripts/event-check.mjs`（约 2.5 分钟，放后台）：同 seed 同策略跑两遍事件流完全一致 ✅；6 个 seed 覆盖 7/7 个事件 ✅；每步校验疲劳 0–100、心态 0.05–1、专题 0–1 不越界 ✅；6 季评分 49/85/73/85/91/91。
- `node scripts/event-choice-check.mjs`（约 3 分钟）：同一 seed、同一训练策略，只把事件选项固定成第 1/2/3 个 → seed 1 极差 **12 分**、seed 777 **27 分**、seed 4242 **24 分**，平均 **21 分**。也就是说「同样练，选法不同，B 和 S 的差距」，事件不是装饰。
- `node scripts/coach-smoke.mjs`（约 30 秒，无头 Edge）：建队 → 16 周（自动挑最弱专题、累了休息）→ 结算，实测 11 次事件、评级 A 79 分，截图 `coach-smoke-event.png` / `coach-smoke-week.png` / `coach-smoke-final.png`。
- 顺带发现：`script` 里的 `process.exit()` 会跳过 `finally`，`edge.kill()` 只杀父进程 → 每跑一次 e2e/冒烟泄漏 10+ 个 msedge 子进程并占住 pwsh 管道（脚本「跑完了但 job 永远 running」）。两个脚本都改成 `process.exitCode` + `taskkill /T /F` 杀进程树，见 §5。

## 2.5 教练模式 M4：报名 / 初赛分卷 / 比赛成长 / 模拟赛 / 省线判奖（10-19 晚）

- **正赛统一走比赛引擎**（m01726 用户要求）：每场比赛用 `ContestConfig.difficultyRanges` 给每道题定难度区间，按历年真题的难度分布抽题（CSP-J2 [35,50]/[48,62]/[58,72]/[70,85]；CSP-S2 [45,60]/[60,75]/[72,85]/[85,100]；NOIP [58,72]/[62,78]/[72,86]/[86,100]；省选 [62,76]/[76,90]/[88,102]；NOI [80,92]/[88,100]/[92,108]）。levels 只决定专题/名次标签。
- **初赛改成笔试直接出分**（不再跑比赛引擎）：J/S 分卷，分数 = 0.45×阅读 + 0.32×代码 + 0.13×心态 + 0.10×年级经验，陕西线 S 37 / J 37.5，晋级名额 ≈ 实考 20%；强选手稳定 90+（回归测试：NOI 银牌选手初赛 ≥95）。
- （⚠️ M6 已废，见 §2.7：J 组整体移除，所有比赛晋级即报名）**报名规则**：只有 J 初赛是教练可选报名（jRoster，setJuniorRoster）；J 初赛是 J 复赛的门槛，不 gate 其他比赛；其余比赛晋级即自动报名。初中生主赛道 J 组，J 没过但过了 S 的初中生去打 S；同一个人只进一个组（避免两组成绩互相覆盖）。
- **比赛成长与疲劳**：正式赛按「题目平均难度 vs 个人水平」给实力成长，赛后加疲劳（一场 +8 / 两试 +16）；比赛周仍然可以排训练，只是不再打模拟赛。
- **校内模拟赛可配置**：`MockConfig{preset,count,minutes}`，题数 2–4、时长 2–4h、难度档 基础/提高/冲刺（MOCK_PRESETS）；难度和队伍水平匹配时成长最多。
- **按官方分数线判奖**（m01950 用户要求）：不再按全国分位套档，卷面分直接对各省官方线——CSP 复赛陕西 S 130/60（138 名额）、J 225/80（161 名额）；NOIP 陕西 128/95/86；APIO 193/130/80；NOI 金/银/铜按 50/152/85 名额比例反推。结算页同时显示**省内排名**（陕西 CSP 第二轮约 1,495 人 = S 690 + J 805）。
- **省选**：两试各 3 题 4.5h；总分 = NOIP 标准分×0.3 + 省选标准分×0.7；陕西 8 个名额（A 5 含 1 名女生 + B 3），单校 ≤ 1/3 → 我校最多 2 人；初中生只能「体验」（不评奖）。

## 2.6 教练模式 M5：正赛/模拟赛改成实时观战 + 虚构外校选手（10-19 深夜）

- **比赛流程统一**（m02845 用户要求）：点「开考」后先瞬时结算出真实成绩，再用同一套观战引擎重放，一帧帧播；暂停 / 1x·2x·4x / +10 分 / 到收卷 / 「跳过观看直接出成绩」都有。播完（或跳过）先出**估分榜**，点「🔓 公布真实成绩」才把省排名、奖项、成长、疲劳写回赛季状态。初赛是笔试，直接出分、不套引擎。
- **同 seed 逐分一致**：`runWeeklyContest(s, trace)` 把每场的 ContestConfig 记进 trace，UI 用 `createContest(cfg)` 重建播放；瞬时结算与回放走同一份 cfg。`scripts/trace-check.mjs` 逐场重建、`tick` 到收卷、`finalize`，与 recap.rows 逐人比 real：seed 20261019 共 25 场、0 处不一致。
- **虚构外校/外省选手**（m02849 用户答「正赛会虚构外校选手」）：新增 `src/field.ts`——按官方公布的名额与分数线反推分数分布锚点，外校选手按分位等距取样，于是「线 = 第 N 名」严格成立；省排名 = 池子里比自己高的人数 + 1。CSP 复赛 J/S 各 770/785 人、NOIP 陕西 160、省选 79、WC 500、APIO 640、NOI 338。
- **官方数据更新到 2025 赛季**（score-researcher 联网核实）：CSP-S 陕西 157 人 / 100 分（二等 30）、CSP-J 162 人 / 230 分（二等 130）、均不设三等；NOIP 陕西 128/95/86（32/37/10）；NOI 2025 满分 705、金 571/银 410/铜 320、正式 338、金 50/银 152/铜 85；APIO 金 64/银 128/铜 193（193/130/80）；WC2025 银 257/铜 211。省队 A5+B3=8、单校 ≤1/3、总分 = NOIP 标准分×30% + 省选标准分×70%。
- **队伍人数不设上限**（m02849 用户答「没有上限」）：`setTeam` 不再 `slice(0, TEAM_MAX)`，选队页「至少 6 个、上不封顶」；训练成长按人数稀释 `sizePenalty = max(0.2, (6/teamSize)^0.6)`，6 人满额。
- **观战界面抽成公共组件**：`src/ContestScreen.tsx`（ui-extractor），App.tsx 1086 → 736 行，testid/文案零漂移（新旧 bundle 字符串字面量多重集一致）。
## 2.7 教练模式 M6：按用户给定分数校准 + 删 J 组 + 选手详情（10-19 深夜）

- **删掉 CSP-J 整条线**（用户 m03187「J 组没必要，删了都行」）：初赛全校一张 S 卷（笔试直接出分，陕西线 37），过线才能进复赛；所有正式比赛晋级即自动报名。`SeasonStudent.csp1/csp2` 不再带组别，`jRoster`/`setJuniorRoster`/`cspjFirst`/`juniorCutoff` 全部删除，教练评分里的 J 省一项一并去掉。
- **初赛分数重标定**：`prelimPaperScore` 改为 `ability = 0.45*阅读 + 0.32*代码 + 0.13*心态 + 0.10*年级经验`，`base = clamp((ability - 0.55) / 0.40, 0, 1)`（37 分 ≈ 全国前 20%，62.5 ≈ 前 25%），加 gauss×3.2 噪声、疲劳最多扣 4。54 人的学校一周大约过线 16 人（对应陕西 20% 晋级率 + 名校偏高）。
- **每题得分率曲线**（核心校准，`StageDef.curve` + `ContestConfig.scoreCurve`）：引擎算的是「原始分」，和真实考场绝对值不是一个刻度。`src/game.ts` 的 `curveScore(curve, raw)` 分段线性映射，端点 (0,0)/(1,1) 外推取端点，同时作用于估分与真实分。曲线只给正式赛（观战模式不传），按用户给的数（特别之处 S 336 / NOIP 270 / NOI 557；王思琦 S 274 / NOIP 228 / NOI 446）和 2025 官方线定锚点。
- **实测校准**（seed 20261019，特别之处/王思琦）：复赛 188–338（满分 400）、NOIP 119–308、WC 55–151、省选 147–405、NOI 301–450。强队顶尖选手稳定在 300–340（省一线 100），中段 180–250，弱学生 27–46，省排名 #59–#590。
- **两名指定选手的三年实测**（seed 20261019，`scripts/calib2.mjs`）：特别之处 复赛 127/196/295、NOIP 349/185/222、NOI 271；王思琦 复赛 154/100/193、NOIP 337/112/162。用户锚点是特别之处 S 336 / NOIP 270 / NOI 557、王思琦 S 274 / NOIP 228 / NOI 446——**同一人不同学年能差 40%**（题目难度抽签 + 心态/疲劳 + 引擎噪声），所以只能对齐量级，不能逐场对齐；要更贴就得压小噪声，但会失去「同一人不同场次起伏」的真实感。
- **选手详情展示全部属性**（用户 m03676「展示选手全部属性」）：`src/StudentDetail.tsx` 改成四段——顶部性格/天赋/年级/校队，四个大数字（综合/实力/心态/疲劳），知识点 2 列进度条 + 元能力 3 列，底部成长信息（入学第几年、开学综合、开学排名）与本学年各赛成绩（初赛过线、复赛奖、NOIP 省一、WC/省选/APIO/NOI 奖牌）。用户已手填 54 人天赋（多为 1.09–1.21，median≈1.10），只有「韩亦书」填了 0.001 被判无效并回退种子随机。
- **天赋/性格可手填**（用户 m03606「天赋我来填」）：`data/天赋对照表.txt`（54 行，Tab 分隔：姓名/天赋/性格/备注，备注自动带 OIerDb 全国排名与 CSP 奖项）→ `node scripts/talent.mjs` → `src/talent.ts`（`TALENT_BY_NAME` / `ARCHETYPE_BY_NAME`）。`createSeason()` 里 `talent: TALENT_BY_NAME[e.name] ?? talentRoll`、`archetype: ARCHETYPE_BY_NAME[e.name] ?? e.archetype`，随机数照常消耗所以没填的人结果不变；选手详情卡显示性格 + 天赋 + 年级。
- **选手详情面板**（用户 m03187「选手信息要更详细的展示」）：`src/StudentDetail.tsx`，队伍状态里点名字展开——综合/心态/疲劳三个大数字 + 8 个知识点进度条 + 代码/阅读/调试/自我认知/抗压/耐心/冒险迷你数值；testid `student-detail-<name>` / `student-detail-panel`。冒烟脚本新增 `--full-detail.png` 截图。
- **修掉一个旧 bug**：`runStage` 里 NOIP/WC/省选/APIO/NOI 调 `runOneDay` 时把 `ranges` 传成了 `undefined`，难度区间其实一直没生效（只有 CSP 复赛生效），M6 一并修好。

## 2.8 选手全属性对照表（M6.5）

- **用户需求**：m03716「把选手全部属性txt给我，我要录入」——天赋表之后，实力/知识点/元能力也要能手填。
- **`data/属性对照表.txt`**：Tab 分隔、`#` 注释，列顺序 = 姓名 / 年级 / 性格 / 天赋 / 实力 / 数学 / 动态规划 / 图论 / 贪心 / 数据结构 / 模拟实现 / 字符串 / 计算几何 / 代码 / 阅读 / 调试 / 自我认知 / 抗压 / 耐心 / 冒险 / 备注。按 seed 20261019 的当前值预填 54 人，属性是 0–100 整数。
- **`scripts/profile.mjs`**：`--init` 生成模板（已有文件保留已填单元格，按姓名匹配）、默认读 txt 写 `src/profile.ts`、`--check` 只校验。校验项：姓名在名单内、属性 0–100、天赋 0.5–1.5、年级中文/数字、性格全名或简称（`暴力`/`dp`/`贪心`…）。
- **`src/season.ts`**：`createSeason` 里 `const over = PROFILE_BY_NAME[e.name]`，先覆盖 strength/topics/meta 再 `startSkills = cloneSkills(skills)`；年级/性格/天赋优先级 profile > 旧天赋表 > 引擎生成，随机数照常消耗，未填的人结果不变。
- 坑 36：profile.ts 与 season.ts 互相引用——首次生成前必须有占位 `src/profile.ts`，否则 `profile.mjs` 导入 season.ts 报 `ERR_MODULE_NOT_FOUND`；坑 37：`ProfileOverride.grade` 要写成 `1|2|3|4|5|6`，写 `number` 会与 `SeasonStudent.grade: Grade` 冲突（TS2322）。

## 3. 验证状态

| 项 | 状态 |
|---|---|
| tsc --noEmit | ✅ 通过（M6：删 J 组 / 得分率曲线 / 选手详情后） |
| vite build + inline.mjs | ✅ 单文件 OI模拟赛.html 352 KB（M6 构建，359,953 B） |
| 单文件 OI模拟赛.html | ✅ 含实时回放 + 跳过、估分榜/公布真实成绩、虚构外校分数池、选手详情面板；J 组已移除 |
| scripts/career-check.mjs | ✅ 3 条三年生涯 541.4s；best 91 S / mid 36 B / worst 20 C（强-弱差 71） |
| scripts/coach-smoke.mjs | ✅ 一届 32 周 + --full 生涯结算（B 评级）；新增 `--full-detail.png`（选手详情展开） |
| scripts/e2e-check.mjs | ✅ 观战模式 20.1s、战报徽章 16 个（ContestScreen 抽取后回归） |
| scripts/trace-check.mjs | ✅ 25 场回放，0 处不一致（含 scoreCurve 校准后，瞬时 vs 重放逐人逐分） |
| scripts/season-check.mjs | ⏳ M3 口径作废，待改写或删除；`scripts/calib2.mjs` 为得分率探针，改曲线后先跑它 |

**三年生涯校准（M6，career-check seed 20261019，2026-10-19）**

| 队伍 | 逐年（初赛过线 / S省一 / NOIP省一 / 省队 / NOI牌） | 评分 | 等级 |
|---|---|---|---|
| best | Y1 7/7/4/0/0 · Y2 7/7/7/1/0 · Y3 7/7/7/1/1 | 91 | S |
| mid | Y1 2/2/0/0/0 · Y2 5/5/2/0/0 · Y3 5/4/2/0/0 | 36 | B |
| worst | Y1–Y3 全部 0（三年没一个初赛过线） | 20 | C |

- 阈值 **S 85 / A 55 / B 34 / C 19 / D 0**（M6 重标定，因为删了 J 省一、初赛过线率也按陕西 20% 重算）。
- 强队路径：三年 7 个省一/年 + 2 次省队 + 1 枚 NOI 牌；中队靠省二和零散省一；弱队三年零产出 = 20 分。
- 分数校准（同一 seed 的顶尖两人，满分见括号）：复赛 188–338（400）、NOIP 119–308（400）、WC 55–151（300）、省选 147–405（600）、NOI 301–450（600）。用户给的锚点：特别之处 S 336 / NOIP 270 / NOI 557，王思琦 S 274 / NOIP 228 / NOI 446。

## 4. 下一步 TODO（按优先级）

1. **等用户填完 `data/属性对照表.csv`**：现在表里是「当前值预填」，用户录入真实属性后跑 `node scripts/profile.mjs && pnpm build:single`，并对比 `logs/verify.log` 里 career-check 的 best 是否变化过大（全员属性变化会直接影响评分分布）。`王思琦/特别之处` 的真实分若要严格贴合用户给的锚点，最直接是调这两人的属性行而不是再动曲线。
2. **观战模式没有接得分率曲线**：`ContestConfig.scoreCurve` 只有教练模式传，观战模式（自由组卷）仍是引擎原始分，同难度下教练正赛分会明显高于观战；要口径统一可以给观战也加曲线（在 `App.tsx` 建 ContestConfig 处传一条通用曲线）。
3. **两名选手的排序和用户给的数据相反**：引擎里王思琦综合略高，复赛分常比特别之处高；用户给的是特别之处高 62 分。改曲线会破坏单调性，正解是改这两人的属性/天赋行。
4. **WC / NOI 还可以再往上抬一点**：现在顶尖选手 NOI 301–450（目标 557/705 ≈ 474/600），调 `stage.curve` 的 (0.3, 0.75) 锚点即可。
5. **初赛结果页还没有单独截图**：`coach-smoke.mjs` 只截 week/detail/event/stage/awards/final 六张。

## 5. 踩过的坑（别再踩）

1. **`edit` 不要吃掉行尾换行**：一次把 `// ===== 阶段四：赛后 =====\n` 的换行吃掉，下一行 `function ResultView(...)` 被注释吞掉，esbuild 报 `src/CoachScreen.tsx:508:0: ERROR: Unexpected "}"`。改多行时 new_string 要带着原来的换行。
2. **`mergeDays` 题号冲突**：两天的题都从 id 0 开始，合并后 `perProblem` 的 problemId 撞车，调试脚本报 `TypeError: Cannot read properties of undefined (reading 'topic')`（`problems.find()` 返回 undefined）。两处都要按累计偏移重编号：第二天的题 `id + pidOffset`，合并后的 perProblem 也加偏移。
3. **`node_modules` 不是 `.node_modules`**（旧记忆写错了）。
4. 校准脚本很慢：`season-check` 一个 seed × 3 队 ≈ 3–3.5 分钟，**放后台跑**，别在前台等。
5. 训练成长最初太小（base 0.06、常规 k=0.6）导致"教练决策不影响结果"——已提到 0.1/0.7，别再调回去。
6. 省一按"校内前 5"太像抽奖；现在前 15%（≈8 人），且用两天合分排名。
7. 赛季自检里的"队伍 710/300"是打印分母错（`fullScore` 没乘人数），不是引擎错。
8. **e2e 只认 `data-testid`**：观战 7 个（`start-contest` / `cfg-duration` / `contest-screen` / `finish-paper` / `reveal-real` / `final-heading` / `final-meta`），教练模式若干（`coach-btn` / `pick-auto` / `pick-<行号>` / `start-season` / `topic-<专题>` / `intensity-<模式>` / `plan-confirm` / `event-card` / `event-opt-<id>` / `run-contest` / `result-next` / `week-events` / `finale-grade` / `coach-watch` / `coach-skip` / `coach-reveal` / `student-detail-<名字>` / `student-detail-panel`）。改 DOM 时保留这些标记，否则脚本会明确报错而不是傻等。
9. **CDP 脚本别用 `process.exit()`**：它会跳过 `finally`，`edge.kill()` 又只杀父进程，于是每次跑完泄漏 10+ 个 msedge，`pwsh ... | Out-String` 的管道被这些子进程占住，job 显示 running 但脚本其实早结束了（本次踩了两次，还占着端口 9335）。正确写法：`process.exitCode = code` + 在 `finally` 里 `spawnSync('taskkill', ['/pid', pid, '/T', '/F'])`。另外给 CDP 求值加 `Promise.race` 超时，否则页面崩了会永久挂起。
10. **初始名单的专题值能到 0.9986**（`buildCohort` 上限 1，不是 0.99），自检校验别写死 0.99。
11. 事件抽选用独立 rng（`seed*8191 + week*7331 + 3`），**不要**复用比赛 rng，否则加事件会改变同 seed 的比赛结果。

12. **`[IO.File]::ReadAllText('相对路径')` 按 .NET 进程 cwd 解析，不是 PowerShell 的 `Get-Location`**：`Set-Location` 到项目根后再读相对路径会报 `FileNotFoundException`（本次踩过）。统一写 `Join-Path (Get-Location) '...'` 或绝对路径。
13. **PowerShell 单引号字符串不转义反引号**：写 README 目录表时把 `'...|`n|...'` 当换行插进了文件，结果表格里出现字面量 `` `n ``。写文件要换行用 `[string][char]10` 拼接，或者用双引号字符串 / 逐行数组 `-join`。
14. **多学年不变量**：`beginNextYear()` 之后 `team` 必须过滤掉毕业的人（否则 `teamStudents()` 会拿到 undefined 的技能直接崩）；`history` 必须每年 push 一条；`overallGain` 要拿「最终在校队」对比「最初队」，别拿已经毕业的人算。
15. **跨学年 `picked` 残留毕业名字** → 白屏 `Cannot read properties of undefined (reading 'skills')`。渲染新学年选队页时 `picked` 还存着上一年的名字，`season.students.find(...)!` 拿到 undefined。修复：`PickTeam` 里先算 `pickedValid = picked.filter(byName.has)`，平均分/列表/提交都用过滤后的；`setTeam()` 本身也会过滤，但渲染层必须先过滤。用 `?seed=` 固定种子后冒烟才稳定复现（原来 `randomSeed()` 导致时好时坏）。
16. **教练模式支持 `?seed=20261019&years=1`**：调试/冒烟用；`coach-smoke.mjs` 读环境变量 `COACH_SEED`。
17. **全国分位锚点必须用「官方分数线 ÷ 满分 → 官方比例」**（如 CSP-S 一等 130/400=0.325 → 前 20%），不要用校内排名（旧版就是校内 15%，被用户否了）。
18. **省选排名必须用总分**（NOIP 标准分 ×30% + 省选 ×70%），直接拿省选原始分排会把 NOIP 的权重丢掉。
19. **体验/夏令营名额不能进奖项**：行上标 note:体验、奖写「后备体验 / 夏令营（成绩证明）」；否则 career-check 会报「初中生拿到正式奖」。
20. **初赛只按官方 37 分线会让 90% 的人晋级**：必须同时加名额约束（pct <= 0.25），因为官方晋级人数 ≥ 实考 20%。

21. **NOIP 资格用「CSP-S 二等及以上」近似名额**：官方是「已参加 CSP-S2 的在籍高中生 + 240 人上限」，用二等及以上相当于在省内截前 45%。
22. **省选标准分的分母不能拿满分**：官方标准分 = 本人 ÷ 全省最高 × 100。一开始写成 ÷ 满分，强队 300/600 只折成 50 分，省队永远进不去（career-check 强队 0 省队、评分从 97 掉到 59）。改成本人 ÷ 推算全省最高（省选 450/600、NOIP 300/400）后恢复正常。
23. **虚构分数池的 top 锚点必须高于自家最高分**：J 组 top 设 330 时，我校 8 个 400 分并列省排名 #1，榜单全是 #1 0.1%。把 J/S 池的 q=0 改成 400（满分）后才拉出正常名次梯度。
24. **回放不能另算一遍**：观战播放必须用结算时 trace 记录的同一份 ContestConfig 重建，否则「看到的」和「写回状态」会是两套数。trace-check 就是守这条。
25. **TEAM_MAX 从 8 放开后 UI 还有 4 处引用**（选队标题/计数/ready 判定/toggle 条件），只改 setTeam 会 TS2304；一起改完再 tsc。

26. **CSP 复赛 J/S 两组合并展示会串人**：同一个人可能 J 初和 S 初都过线，若两组合并进 `allRows` 且用姓名做 key，info.set(name) 会被后一组的成绩覆盖（400 分显示成省二）。修法：一个人只进一个组（初中生优先 J 组、J 没过才去 S），info 的 key 用 `name|group`，查成绩时先 S 后 J。
27. **省选难度档一开始给太高**：`levels:[5,6,7]` 时全省选得分率只有 0.1–0.22，锚点全对不上、省队永远进不去。改成 `[4,5,6]`（T1 提高+ / T2 省选- / T3 省选）并把锚点对齐到 0.20→50% / 0.27→20% / 0.32→5% 后，陕西 160 人里能稳定进 1–2 个省队（单校上限 2）。
28. **奖项判定和报名资格要用两套口径**：现在奖项完全按官方分数线（考到线就发，不按分位），分位只用来显示省内排名；若把两者混用会出现「400 分显示前 35%」。

29. **`Contest` 的配置字段是 `config` 不是 `cfg`**：`c.cfg.scoreCurve` 会 TS2339，写 `c.config.scoreCurve`。
30. **`runStage` 曾经把 ranges 传丢**：调用是 `runOneDay(..., undefined, trace, ...)`，于是 NOIP/WC/省选/APIO/NOI 的每题难度区间从 M4 起一直没生效（只有复赛生效）。改签名时一定要对齐位置参数；更好的做法是改成 options 对象。
31. **得分率曲线只对「考出来的分」做映射，不改机器人做题逻辑**：`submitAttempt()` 里先算 raw（beliefOf），再用 `curveScore(cfg.scoreCurve, raw)` 同时映射估分与真分，所以「估分 vs 真分」的挂分感仍然保留。
32. **曲线低分段不能太肥**：低段抬太高会让弱学生也过省一线（M6 第一版 50 人里 37 个省一，官方只有约 20%）。判断标准是「省一人数 / 参赛人数 ≈ 官方比例」。
33. **删 J 组不是只删 UI**：`season.ts` 的类型（SeasonStudent.csp1/csp2 无 group）、`CareerRow.cspjFirst`、`GRADES`、`PRELIM_ANCHORS_J`、`CSP2_GUIDE.J`、`FIELDS['csp2.J']`、`qualifiedFor`、`beginNextYear` 都要一起删，否则 tsc 会连环报 11 处。
34. **改 season.ts 用一次性脚本时先归一化 CRLF**：`t.replace(/\r\n/g,'\n')`，否则多行片段永远匹配不上。
35. **后台 job 用 `Out-String` 会把输出缓到结束才吐**：长脚本想看中间进度就直接 `Write-Output` 逐行打印，或者写成日志文件再 `Get-Content -Tail`。

## 6. 还没定的事

- **推算值**（官方没直接公布，M6 口径）：CSP 复赛陕西参赛 = 一等人数 ÷ 20% ≈ S 785；NOIP 全国 ≈ 7,500（获奖率 67% 反推）；NOI 正式 338（官方公布）；省选陕西 79（NOIP 获奖者）；WC 学生营员 ≈ 500；APIO 中国区 ≈ 640。省选全省最高分按 450/600、NOIP 最高按 300/400 推算。
- **2027 赛季部分通知尚未发布**（省选、APIO、NOI 具体日期先用「2027-03/05/07」占位）；2026 陕西赛历已按官方调整（第一轮 9/19、第二轮 10/31）。
- 初中生「后备体验」只写了 NOIP（官方 ≤200 人、无证书），省选/NOI 的初中体验按「非正式、只给成绩证明」建模，官方名额细节未见公开文件。
- **得分率曲线是经验校准**：六条曲线由「探针脚本测出的原始得分率」对「官方分数线 → 应有得分率」手调，官方没公布分数段；用户再给具体选手的分数时可以继续贴。
- **观战模式没有全国排名/奖项展示**，也没接 scoreCurve；是否把两套口径统一，等用户决定。
