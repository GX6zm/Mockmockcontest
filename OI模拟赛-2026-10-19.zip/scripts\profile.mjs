#!/usr/bin/env node
/**
 * 选手全属性对照表工具
 *
 *   node scripts/profile.mjs --init    生成 data/属性对照表.csv（Excel 直接打开）和 .txt
 *   node scripts/profile.mjs           读表 → 生成 src/profile.ts
 *   node scripts/profile.mjs --check   只校验，不写文件
 *   node scripts/profile.mjs --show    终端里按列对齐打印
 *
 * 列顺序：姓名 年级 性格 天赋 实力 数学 动态规划 图论 贪心 数据结构 模拟实现 字符串 计算几何
 *        代码 阅读 调试 自我认知 抗压 耐心 冒险 备注
 * 除姓名外留空 = 沿用当前值；属性写 0–100 整数；天赋写 0.85–1.15；年级写 初一…高三 或 1–6。
 * 优先读 .csv（Excel 改完直接保存 CSV 即可），没有 csv 再读 .txt。
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const CSV = path.join(ROOT, 'data', '属性对照表.csv');
const TXT = path.join(ROOT, 'data', '属性对照表.txt');
const OUT = path.join(ROOT, 'src', 'profile.ts');
const SEED = 20261019;

const { ARCHETYPE_NAMES, TOPIC_LIST, TOPIC_NAMES } = await import(pathToFileURL(path.join(ROOT, 'src', 'game.ts')).href);
const { createSeason, GRADE_NAMES } = await import(pathToFileURL(path.join(ROOT, 'src', 'season.ts')).href);

const LABEL_TO_ARCH = new Map(Object.entries(ARCHETYPE_NAMES).map(([k, label]) => [label, k]));
const SHORT_ARCH = new Map([
  ['全能', 'allrounder'], ['数学', 'math_genius'], ['dp', 'dp_master'], ['图论', 'graph_expert'],
  ['暴力', 'brute_force'], ['稳定', 'steady'], ['爆发', 'explosive'], ['焦虑', 'anxious'],
  ['贪心', 'greedy_solver'], ['实现', 'impl_king'],
]);
const GRADE_LABEL = { 初一: 1, 初二: 2, 初三: 3, 高一: 4, 高二: 5, 高三: 6 };

const TOPIC_COLS = TOPIC_LIST.map((t) => ({ col: TOPIC_NAMES[t], key: t }));
const META_COLS = [
  { col: '代码', key: 'coding' }, { col: '阅读', key: 'reading' }, { col: '调试', key: 'debug' },
  { col: '自我认知', key: 'selfAwareness' }, { col: '抗压', key: 'mental' },
  { col: '耐心', key: 'patience' }, { col: '冒险', key: 'risk' },
];
const HEADER_COLS = ['姓名', '年级', '性格', '天赋', '实力', ...TOPIC_COLS.map((c) => c.col), ...META_COLS.map((c) => c.col), '备注'];

/** 显示宽度：中文算 2 列 */
function width(s) {
  let w = 0;
  for (const ch of String(s)) w += ch.codePointAt(0) > 255 ? 2 : 1;
  return w;
}
function pad(s, n) {
  const t = String(s);
  return t + ' '.repeat(Math.max(0, n - width(t)));
}

function readTable() {
  if (fs.existsSync(CSV)) return { text: fs.readFileSync(CSV, 'utf8'), file: CSV };
  if (fs.existsSync(TXT)) return { text: fs.readFileSync(TXT, 'utf8'), file: TXT };
  return null;
}

/** 按 CSV/TSV 规则切一行（支持引号） */
function splitLine(line) {
  const out = [];
  let cur = '';
  let q = false;
  for (let i = 0; i < line.length; i++) {
    const ch = line[i];
    if (q) {
      if (ch === '"' && line[i + 1] === '"') { cur += '"'; i++; }
      else if (ch === '"') q = false;
      else cur += ch;
    } else if (ch === '"') q = true;
    else if (ch === ',' || ch === '\t') { out.push(cur); cur = ''; }
    else cur += ch;
  }
  out.push(cur);
  return out.map((c) => c.trim());
}

/** 按行切（引号里的换行不算） */
function splitRows(text) {
  const rows = [];
  let cur = '';
  let q = false;
  const push = () => { if (cur.trim()) rows.push(cur); cur = ''; };
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (q) {
      cur += ch;
      if (ch === '"' && text[i + 1] === '"') cur += text[++i];
      else if (ch === '"') q = false;
    } else if (ch === '"') { q = true; cur += ch; }
    else if (ch === '\n') push();
    else cur += ch;
  }
  push();
  return rows;
}

function emptyOverride() {
  return { grade: null, arch: null, talent: null, strength: null, topics: {}, meta: {} };
}

function parse(text) {
  const rows = [];
  const errors = [];
  const lines = splitRows(text.replace(/^\uFEFF/, '').replace(/\r\n/g, '\n'));
  for (const line of lines) {
    if (!line.trim() || line.trimStart().startsWith('#')) continue;
    const cols = splitLine(line);
    const name = cols[0];
    if (!name || name === '姓名') continue;
    const o = emptyOverride();

    const gradeRaw = cols[1] ?? '';
    if (gradeRaw) {
      const g = GRADE_LABEL[gradeRaw] ?? Number(gradeRaw);
      if (Number.isInteger(g) && g >= 1 && g <= 6) o.grade = g;
      else errors.push(`${name}：年级「${gradeRaw}」不认识（初一…初三 / 高一…高三 / 1–6）`);
    }

    const archRaw = cols[2] ?? '';
    if (archRaw) {
      o.arch = LABEL_TO_ARCH.get(archRaw) ?? SHORT_ARCH.get(archRaw.toLowerCase()) ?? null;
      if (!o.arch) errors.push(`${name}：性格「${archRaw}」不认识（${Object.values(ARCHETYPE_NAMES).join(' / ')}）`);
    }

    const talentRaw = cols[3] ?? '';
    if (talentRaw) {
      const v = Number(talentRaw);
      if (!Number.isFinite(v)) errors.push(`${name}：天赋「${talentRaw}」不是数字`);
      else if (v < 0.5 || v > 1.5) errors.push(`${name}：天赋 ${v} 超出 0.5–1.5`);
      else o.talent = Math.round(v * 1000) / 1000;
    }

    const attrAt = (i) => {
      const raw = cols[i] ?? '';
      if (!raw) return null;
      const v = Number(raw);
      if (!Number.isFinite(v) || v < 0 || v > 100) {
        errors.push(`${name}：${HEADER_COLS[i]}「${raw}」要是 0–100 的数字`);
        return null;
      }
      return Math.round(v) / 100;
    };

    o.strength = attrAt(4);
    TOPIC_COLS.forEach((c, i) => {
      const v = attrAt(5 + i);
      if (v != null) o.topics[c.key] = v;
    });
    META_COLS.forEach((c, i) => {
      const v = attrAt(5 + TOPIC_COLS.length + i);
      if (v != null) o.meta[c.key] = v;
    });

    rows.push({ name, o });
  }
  return { rows, errors };
}

/** 当前引擎算出来的完整表（用于 --init 预填） */
function currentRows() {
  const season = createSeason(SEED, 1);
  const order = [...season.students].sort((a, b) => b.startOverall - a.startOverall);
  return order.map((s) => {
    const sk = s.skills;
    return [
      s.name,
      GRADE_NAMES[s.grade],
      ARCHETYPE_NAMES[s.archetype],
      s.talent.toFixed(3),
      String(Math.round(sk.strength * 100)),
      ...TOPIC_COLS.map((c) => String(Math.round((sk.topics[c.key] ?? 0) * 100))),
      ...META_COLS.map((c) => String(Math.round(sk[c.key] * 100))),
      '',
    ];
  });
}

function init() {
  const old = readTable();
  const kept = new Map();
  if (old) for (const r of parse(old.text).rows) kept.set(r.name, r.o);

  const rows = currentRows().map((cells) => {
    const o = kept.get(cells[0]);
    if (!o) return cells;
    const v = (x, fallback) => (x != null ? String(Math.round(x * 100)) : fallback);
    return [
      cells[0],
      o.grade != null ? GRADE_NAMES[o.grade] : cells[1],
      o.arch ? ARCHETYPE_NAMES[o.arch] : cells[2],
      o.talent != null ? o.talent.toFixed(3) : cells[3],
      v(o.strength, cells[4]),
      ...TOPIC_COLS.map((c, i) => v(o.topics[c.key], cells[5 + i])),
      ...META_COLS.map((c, i) => v(o.meta[c.key], cells[5 + TOPIC_COLS.length + i])),
      cells[cells.length - 1],
    ];
  });

  const quote = (s) => (/[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s);
  fs.mkdirSync(path.dirname(CSV), { recursive: true });
  fs.writeFileSync(CSV, '\uFEFF' + [HEADER_COLS.map(quote).join(','), ...rows.map((r) => r.map(quote).join(','))].join('\r\n'));
  fs.writeFileSync(
    TXT,
    [
      '# 选手全属性对照表（文本版；Excel 用 data/属性对照表.csv）',
      '# Tab 分隔；除姓名外留空 = 沿用当前值。属性 0–100；天赋 0.85–1.15；年级写 初一…高三',
      `# 基于 seed ${SEED} + 当前天赋表生成；改完跑 node scripts/profile.mjs`,
      '# ' + HEADER_COLS.join('\t'),
      ...rows.map((r) => r.join('\t')),
    ].join('\n') + '\n',
  );
  console.log(`✅ 已生成 ${path.relative(ROOT, CSV)}（Excel / WPS 直接打开）和 ${path.relative(ROOT, TXT)}，共 ${rows.length} 人`);
}

function show(text) {
  const { rows, errors } = parse(text);
  const s = (v) => (v != null ? String(Math.round(v * 100)) : '');
  const table = [HEADER_COLS, ...rows.map((r) => {
    const o = r.o;
    return [
      r.name,
      o.grade != null ? GRADE_NAMES[o.grade] : '',
      o.arch ? ARCHETYPE_NAMES[o.arch] : '',
      o.talent != null ? o.talent.toFixed(3) : '',
      s(o.strength),
      ...TOPIC_COLS.map((c) => s(o.topics[c.key])),
      ...META_COLS.map((c) => s(o.meta[c.key])),
      '',
    ];
  })];
  const widths = HEADER_COLS.map((h, i) => Math.max(width(h), ...table.map((r) => width(r[i] ?? ''))));
  for (const [i, r] of table.entries()) {
    console.log(r.map((c, j) => pad(c ?? '', widths[j])).join('  ').trimEnd());
    if (i === 0) console.log(widths.map((w) => '─'.repeat(w)).join('  '));
  }
  if (errors.length) {
    console.log();
    for (const e of errors) console.error('❌ ' + e);
  }
}

function write(rows, errors, checkOnly) {
  const known = new Set(createSeason(SEED, 1).students.map((s) => s.name));
  for (const r of rows) if (!known.has(r.name)) errors.push(`${r.name} 不在名单里（拼写？）`);

  const filled = rows.filter((r) =>
    r.o.grade != null || r.o.arch || r.o.talent != null || r.o.strength != null
    || Object.keys(r.o.topics).length || Object.keys(r.o.meta).length);
  if (errors.length) {
    for (const e of errors) console.error('❌ ' + e);
    console.error(`共 ${errors.length} 处错误，先改表再生成`);
    process.exitCode = 1;
    if (checkOnly) return;
  }

  const body = [
    '// 由 scripts/profile.mjs 从 data/属性对照表.csv 生成，请勿手改',
    "import type { Archetype, Skills, Topic } from './types.ts';",
    '',
    'export interface ProfileOverride {',
    '  grade?: 1 | 2 | 3 | 4 | 5 | 6;',
    '  archetype?: Archetype;',
    '  talent?: number;',
    '  strength?: number;',
    '  topics?: Partial<Record<Topic, number>>;',
    "  meta?: Partial<Pick<Skills, 'coding' | 'reading' | 'debug' | 'selfAwareness' | 'mental' | 'patience' | 'risk'>>;",
    '}',
    '',
    '/** 手填的全属性覆盖；没填的人沿用引擎生成值 */',
    'export const PROFILE_BY_NAME: Record<string, ProfileOverride> = {',
  ];
  for (const r of filled) {
    const parts = [];
    if (r.o.grade != null) parts.push(`grade: ${r.o.grade}`);
    if (r.o.arch) parts.push(`archetype: '${r.o.arch}'`);
    if (r.o.talent != null) parts.push(`talent: ${r.o.talent}`);
    if (r.o.strength != null) parts.push(`strength: ${r.o.strength}`);
    const topics = Object.entries(r.o.topics);
    if (topics.length) parts.push(`topics: { ${topics.map(([k, v]) => `${k}: ${v}`).join(', ')} }`);
    const meta = Object.entries(r.o.meta);
    if (meta.length) parts.push(`meta: { ${meta.map(([k, v]) => `${k}: ${v}`).join(', ')} }`);
    body.push(`  ${JSON.stringify(r.name)}: { ${parts.join(', ')} },`);
  }
  body.push('};', '', `export const PROFILE_FILLED = ${filled.length};`, '');

  console.log(`已填 ${filled.length} / ${rows.length} 人（其余沿用引擎值）`);
  if (checkOnly) {
    console.log('（--check：不写文件）');
    return;
  }
  fs.writeFileSync(OUT, body.join('\n'));
  console.log(`✅ 已写入 ${path.relative(ROOT, OUT)}`);
}

const arg = process.argv[2];
if (arg === '--init') {
  init();
} else {
  const table = readTable();
  if (!table) {
    console.error('没有找到 data/属性对照表.csv 或 .txt，先跑 node scripts/profile.mjs --init');
    process.exit(1);
  }
  if (arg === '--show') {
    show(table.text);
  } else {
    const { rows, errors } = parse(table.text);
    write(rows, errors, arg === '--check');
  }
}
