# 变更日志（CHANGELOG）

记录每一次大改动的「改了什么 / 为什么 / 怎么验证的」。细颗粒的实现笔记在 `PROGRESS.md`，
每次自动校验的原始数字在 `logs/verify.log`。

---

## 2026-11-15 · UI 重构：SIGNAL 设计系统 + 静帧 / 满血双版本

- 用户要求：统一 Lucide 图标、界面全程禁止表情符号、对标 Awwwards / FWA / CSS DesignAwards
  的先锋视觉与实验性排版，同时必须「在 GPU 堪比没有的机子上流畅运行」；追加要求
  「可以分两个版本：一个没动画，一个满血」。
- **一次换肤**：`src/index.css` 用 Tailwind v4 的 `@theme` 覆盖全套 `--color-*` 变量
  （墨水 `#060709` → 骨白 `#f6f8fb`，主信号酸绿 `#c8f135`，冷辅电青 `#4ad9e3`，
  薄荷 / 琥珀 / 珊瑚 / 天青状态色），`bg-* / text-* / border-* / accent-*` 全部自动跟着走；
  再用无 layer 的工具类覆写统一方角 2px、去掉所有模糊阴影、把 `transition-all`
  收窄到 color/background/border/opacity/transform。硬编码深蓝底与满分绿由 codemod 同步换色。
- **实验性排版**：`src/App.tsx` 新增 `Masthead` / `SiteFooter`——`01 / CONFIGURE` 编号眉标、
  `OI` 实心 + `模拟赛` 描边双行超大紧排标题（clamp 3.2–8.5rem / -0.085em）、
  右侧元信息列与竖排标签、发丝规则线、等宽 kicker、72px 技术网格与顶部 3px 信号线。
  所有绘制都是静态背景 / 1px 边框，零合成层。
- **统一图标**：新建 `src/ui.tsx`（56 个 Lucide 图标 → 短键映射 + `Ic` 组件 + `motionFull()` +
  `plainText()`）。`scripts/_ui-skin.mjs` 一次性 codemod 把 5 个 TSX / `season.ts` / `quotes.ts`
  里的 **全部 emoji 与装饰字形** 换成 Lucide 或纯文本，并删掉 `backdrop-blur` / `animate-pulse`；
  `quotes.ts` 数据里的表情也直接清干净，`easter` 语录在渲染处再过一遍 `plainText()` 兜底。
  奖励牌改成 `.ui-rank` 编号徽章，`✓ / ✕ / ◆ / ◇ / × / +` 全部图标化。
  `index.html` 移除 Font Awesome CDN，单文件完全离线。
- **两个版本**：动效开关写在 `<html data-motion="...">`，CSS 与运行时都读它——
  同一次 `OPV=1 vite build` 即可由 `scripts/inline-opv.mjs` 产出两个独立 HTML，
  不需要跑两遍构建、也不会出现功能分叉：
  | 文件 | 开关 | 表现 |
  |---|---|---|
  | `OI模拟赛-OPv-静帧.html` | `static` | `animation/transition/scroll-behavior` 全部 `none !important`，不撒纸屑 |
  | `OI模拟赛-OPv-满血.html` | `full` | 错峰入场（`ui-rise`）、活体指示、评测齿轮旋转、进度扫光、按钮悬浮位移、轻量纸屑 |
  | `OI模拟赛-OPv.html` | `full` | 旧文件名别名，保留旧书签与验证脚本 |
  `vite.config.js` 另加 `MOTION=0/1` 构建开关写死默认动效档；`prefers-reduced-motion` 仍优先。
  满血动效只用 `transform / opacity`，纸屑从 140 粒降到 70 粒且仅满血触发。
- **验证**：`tsc --noEmit` 0；`OPV=1 vite build` → CSS 72.14 KB / JS 424.60 KB，三个 HTML 各 488 KB。
  `scripts/_motion-verify.mjs` 运行时探针：静帧 `animationName=none`、`transitionDuration=0s`；
  满血 `ui-live-pulse` / `ui-rise` / `0.16s`，两版 `emojiInUI=[]`、各 11 个 `svg.ui-ic`、
  面板圆角 2px、底色 `rgb(6,7,9)`——**PASS**。
  `scripts/_opv-verify.mjs` 四组回归全部 ok（编辑器 / 观战 / 完整一局 / 周康阳预设），
  静帧版编辑器回归也 ok；完整一局战报仍是「此刻的我 以 290 分拿下第一」。
  生成脚本新增「产物内不得出现任何已知表情符号」硬校验。
  **`OI模拟赛.html` 与 `site/index.html` 哈希仍是 `50daf33c…`，一个字节没动。**

## 2026-11-15 · OPv 第二轮：天花板校准（周康阳标尺）

- 用户实测「知识点全满、天赋 3，WC 只有 98 分」，并给出周康阳（IOI2024 600/600、CSP 400/400、
  NOI2023 669/705、WC 金牌 180/300）的真实战绩作参照。
- **复现**：`scripts/_ceiling-probe.mjs` 30 seed 下，旧上限 0.998 的全满选手 WC 均值 **204/300、最低 98**。
  病根不是挂分而是标定：0–150 知识点被线性压进 0–1 且引擎/赛季都 clamp 到 0.998（=100 能力点），
  可正赛黑题 `think` 能到 117–130，天花板选手天然差 −20 分，得分率曲线再把低原始分率放大一次。
  天赋只影响训练成长，当场一分不加（UI 已写得更明确）。
- **修复**：`src/opv.ts` 新增「超频区」——120 知识点以上能力继续涨，150 → **1.35**（135 能力点）、
  145 → 1.258（IOI AKer 口径），120 及以下完全沿用原版换算；元能力不超频。
  `src/season.ts` 的 6 处 clamp 上限改用 `ABILITY_CEIL`（OPv 1.35 / 普通构建 0.998），
  否则 `contestSkills` 与训练成长会把超频值压回去；**普通选手和原版构建一分不变**。
- **周康阳标尺**：编辑器新增「🏅 周康阳 · IOI AKer」预设、初二/初三/高一/高二四档成长轨迹
  （95 / 115 / 135 / 145 知识点，按真实战绩估的刻度）、15 条真实获奖表的可折叠对照；
  综合分在超频后会破百（全满 128.0），UI 口径已注明。
- **验证**：`tsc --noEmit` 0。观战模式 10–20 seed 单日官方分，全满 150 → CSP **400/400**、NOIP 389/400、
  WC **292/300**、APIO 274/300、NOI 299/300（两试 + 笔试 ≈ 698/700）、IOI **298/300**（两试 ≈ 596/600）；
  145 → WC 273；旧上限 → WC 206（min 129 / 30 seed 时 98）；120 不超频 → 与旧版一致。
  教练模式 WC 结算（4 seed、只打正赛周）：全满 **300 / 295 / 296 / 300（均值 298）**，145 → 均值 247。
  探针里个别「未参赛」是 W14「赛前发烧」事件禁赛一场，与本次改动无关（避开该选项后全部正常参赛）。

## 2026-11-15 · OPv 自定义开局版（新开 HTML，不覆盖原版）

- 起因：同志们试玩后反馈「我咋这么菜 / 尽力扶植无力回天 / 数据爬得太早，根本无法证明我现在的实力」。
  做一个能自己填数值的版本：**新文件 `OI模拟赛-OPv.html`，原 `OI模拟赛.html` 和 `site/index.html` 一个字节都没动**。
- 版本开关：`vite.config.js` 用 `OPV=1` 注入 `__OPV__`（普通构建恒 false，dev server 也是原版行为）；
  `scripts/inline-opv.mjs` 只输出新 HTML，生成前后校验原版 / Pages 哈希，并要求 dist 带 `OPV_BUILD_MARKER`。
  重建命令：`OPV=1 npx vite build && node scripts/inline-opv.mjs`。
- 新增 `src/opv.ts`（配置结构 / 脏数据校验 / 0–150 换算 / 独立 localStorage key）与 `src/OpvEditor.tsx`：
  带学年以前可「改写名单里的人」或「新加一个人」，设年龄 10–20 + 年级（初一~高三）、8 个知识点 0–150、
  代码/阅读/调试 0–100、天赋 0.5–3、疲劳、作业/互测、学校声望；四个一键预设（含「我其实是神」）+ 实时综合分。
- 引擎接入：`createSeason` 末尾 `applyOpvToSeason`（只在开档写一次，之后照常成长 / 升级 / 毕业）；
  观战模式 `createStudents` 按名字覆盖技能、没抽到就顶掉最后一位——`cfg.cohort`（教练模式）不走这条，
  否则每周重放比赛会把选手成长抹回开局值；`SeasonStudent.age?` 在详情卡 / 选队页显示岁数，升学 +1。
  选队页默认把 TA 和综合前 5 一起勾成主力，直接能点「开始第 1 学年」。
- 数据隔离：OPv 教练档 `oi-sim-coach-opv-v1`、观战成长档 `oi-sim-growth-opv-v1`、
  配置 `oi-sim-opv-config-v1`；原版三个 key 一律不碰（普通构建里 OPv key 已被 tree-shake）。
- 验证：`tsc --noEmit` 0；无头 Chrome 三组回归（`scripts/_opv-verify.mjs`，默认 / `--watch` / `--full`）：
  编辑器拉满 → 保存 → 教练档显示「此刻的我 高一 · 15 岁 · 综合 99.8」、6 人主力已备好；
  观战榜出现该选手；跑完整场战报「此刻的我 以 290 分拿下第一」；
  OPv 存档存在、原版教练档与成长档都不存在。原版 HTML / site/index.html 哈希前后一致
  （`50daf33c…`），新单文件 449 KB。

## 2026-10-23 · 第二版数值：0–150 知识点 / 中等成长 / 梯队 / 任意多年 / 完整晋级链

- **知识点 0–150**：8 个专题改 0–150；`data/属性对照表.csv` 的专题列 ×1.246（顶尖 96.4 → 120），`profile.mjs` 按 0–150 解析；UI 全部改为 `kpOf = round(v×150)`，`综合` 仍是 0–100。
- **成长中等化**：`TRAIN_BASE` 0.18 → 0.05、边际指数 `(1-cur)^0.55`、疲劳乘数 `1−0.55×f²`；校内模拟赛 0.0005、正赛 0.0012×天数。balance-check 实测一学年：顶尖 +7.7（常规）/ +10.1（加练×3+休息），中游 +9.5 / +12.8，偏弱 +11.7 / +15.6。
- **疲劳只减缓训练效率**：删掉 `contestSkills` 的 18% 实力惩罚、初赛最多 4 分惩罚、比赛 cohort 的疲劳注入；休息改为 `−(16+0.22×疲劳)`。
- **梯队**：`SeasonState.reserve / prestige / lastReserve`、`SeasonStudent.onReserve`、`WeekPlan.focus`；`setSquad`、`reserveStudents`；选队页主力/梯队双选，排训练页三档精力分配；声望影响新生质量。
- **任意多年 + 退休**：`MAX_YEARS=99`、`phase='yearEnd'`、`continueCareer` / `retireCareer`；`advanceWeek` 学年末不再自动进下一年；评分分母至少 3 年 + 生涯高光（封顶 15）。
- **晋级链**：NOI 前 50 → `noi.selected/baosong`，CTT 门槛改 `selected`；CTT 三场 + 作业/互测 10% + 三场 54% 积分；CTS 两场 36% + 前 6 答辩（作业 40% + NOI 25% + 阅读表达 20% + CTS 15%）→ 前 4；CSP 初赛锚点改为「37 分 = 前 20%」；NOI 分数池锚点 430/390/350，省选分数池 90/78/55/5。
- **事件库 7 → 17**：新增发烧、期中、宣讲、学长、经费、转学、崩状态、媒体、联合训练、家长转文化课；新增 `EventPatch.prestige`、`StudentPatch.homework/sitOut`；`sitOut` 让学生缺席 1–2 周正式比赛。
- **语录进教练模式**：`easter.quoteFor(name, seed)`，训练报告 / 事件卡 / 赛后 / 学年末 / 退役各一条；无专属语录不显示，不新增文案。
- **验证**：`tsc --noEmit` 0；`vite build` + `inline.mjs` → `OI模拟赛.html` 416 KB；`event-check` 17/17 覆盖、可复现；`peak-check` 145 分高中生走通 NOI 金 #40 → CTT #1 → CTS #1/答辩 #1 → IOI 金；`career-check` 跑完 3 年 best/mid/worst（强队仍偏强，见 README 标定残留）。

## 2026-10-20 · 训练提速 + 省队 17 + CTT/CTS/IOI + NOI 笔试

- 按用户 m01684 要求：训练/模拟赛成长提高（`TRAIN_BASE` 0.10→0.18、模拟赛 scale 0.007→0.016）；省队扩到 A5+B12=17、单校上限 5；NOI 后新增 W34 CTT、W37 CTS、W40 IOI。
- 按用户 m02155 补上 **NOI 100 分笔试**：NOI 满分 705（本作 700），笔试按阅读/代码/年级经验独立出分，`StudentResult.written` 记录并计入真分/估分/排名；结算页显示「满分 700」「总分含 100 分笔试」。
- 校准：省选 `FIELDS.prov` 锚点 62/55/40/5，NOI 300/270/230/175，CTT/CTS/IOI 难度区间 65–102；探针跑通 NOI 金 #39 → CTT 前 30 → CTS 前 4 → IOI 铜。
- 验证：`tsc --noEmit` 0；`vite build` + `inline.mjs` → `OI模拟赛.html` **399,804 B**；`e2e-check` 20.5s / 16 徽章；`coach-smoke` 一届 40 周通过（S · 传奇教练）。`career-check` 仍是六属性删除前基线。

## 2026-10-20 · 六属性彻底删除 + 战报彩蛋

- 按用户要求删除 **性格 / 实力 / 自我认知 / 抗压 / 耐心 / 冒险**，不是只删表列：`Skills` 只剩 8 知识点 + 代码/阅读/调试，`Student/SeasonStudent/StudentResult` 去掉 archetype，`ARCHETYPES/ARCH_TUNE/topicAffinity/ARCHETYPE_BY_NAME` 全部移除；`data/天赋对照表.txt` 改成 姓名/天赋/备注 三列。
- 依赖行为改成固定中性规则，不保留隐藏属性：估分噪声 `gauss*3.0`、交题 `cautious=.55` / `wantMore=.55`、初赛 `0.53*阅读 + 0.37*代码 + 0.10*年级经验`、事件只改疲劳/专题/成长。
- 用户最后在 `data/属性对照表-综合预览.xlsx` 改值，已按**姓名**导回 `data/属性对照表.csv`（15 列、54 行；备份 `.bak-sync`）；`profile.mjs --verify` **54 人 / 756 字段**，Excel UsedRange 55×15；CSV↔xlsx 按姓名逐格比对 **0 处不一致**。
- 新增 `src/quotes.ts`（201 条“唐话”，原文、说话人、标签）和 `src/easter.ts`（每场 1 条今日语录 + 最大挂分/最大反挂/估分最准 3 个高亮位，按 contest seed 确定、不重复、不改分），接入观战赛后页。
- 同步更新 `docs/属性与比赛影响.md`、`docs/选手属性全表.md`、`README.md`、`PROGRESS.md`。
- 验证：`tsc --noEmit` 0；`vite build` + `inline.mjs` → `OI模拟赛.html` **395,033 B**；`e2e-check` 20.3s / 16 徽章；`coach-smoke` 通过。`event-check` / `career-check` 删除六属性后待重跑。

## 2026-10-19 · M6.5 全属性编辑器

- 新增 `data/属性对照表.csv` + `.txt`（54 人 × 21 列）、`scripts/profile.mjs`、`src/profile.ts`；
  `createSeason` 里按姓名套用覆盖值（年级/性格/天赋/实力/8 知识点/7 元能力）。
- 加 `--show` 终端对齐打印（Tab + 中文字宽问题不再错位）。
- 校验：`tsc` 0；把当前值原样回填后跑 `coach-smoke --full`，结果与回填前一致；单文件 370 KB。

## 2026-10-19 · M6 按真实分数校准 + 删 J 组 + 选手详情

- 新增每题「得分率曲线」`ContestConfig.scoreCurve`，把引擎原始分映射到真实赛事得分区间；
  八场正赛各一条曲线。
- 删掉 CSP-J 赛道（用户：「J组没必要」）：初赛全校一张 S 卷、直接出分；复赛单组；
  生涯评分去掉 J 省一。
- 选手详情面板 `src/StudentDetail.tsx`：全部属性、性格天赋、本学期每场成绩。
- 修 bug：`runStage` 一直漏传 `ranges`（NOIP 起的题目难度区间从 M4 起没生效）。
- 校准：`career-check` 91 S / 36 B / 20 C（强-弱差 71）；阈值 S85/A55/B34/C19/D0。
- 校验：`tsc` 0、`e2e-check` 20s、`trace-check` 25 场 0 不一致；单文件 348 KB。

## 2026-10-19 · M5 正赛改成实时观战 + 虚构外校选手

- 教练模式的正赛/模拟赛复用观战的 `ContestScreen`：实时榜单、暂停、1x–4x、+10 分钟、
  到收卷、估分榜、公布真实成绩；默认观看，可「跳过观看」。
- `runWeeklyContest(s, trace)` 记录每场 `ContestConfig`，前端用同一份 cfg 重建 → 同 seed 逐分一致
  （`scripts/trace-check.mjs` 校验）。
- 新增 `src/field.ts`：用「官方名额 + 分数线」反推整条分数分布，虚构外校选手，
  给出省内排名/分位/奖项；`NATIONAL_QUOTAS` 供 NOI/APIO/WC 发牌。
- 队伍人数不设上限（`TEAM_MAX` 移除），用 `sizePenalty` 做注意力稀释。
- 官方 2025 数据全量替换（CSP-S 陕西 157 人/100 线、J 162/230、NOIP 128/95/86、
  NOI 705 分 金 50 银 152 铜 85、APIO 193/130/80 …）。
- 校验：`career-check` 78 A / 47 B / 34 C；`e2e-check` 20.1s；`trace-check` 25 场 0 不一致；单文件 352 KB。

## 2026-10-19 · M4 初赛笔试 / 报名制 / 比赛成长 / 省线判奖

- 初赛改成「100 分笔试直接出分」，不再套比赛引擎；`prelimPaperScore` 按能力 + 噪声 + 疲劳算分。
- 报名：只有 CSP 初赛可选报名（勾选名单），其余比赛晋级即自动报名。
- 比赛成长：`growFromContest`，难度与水平越匹配涨得越多，参赛同时加疲劳；比赛周仍可训练。
- 模拟赛可调难度档/题数/时长（`MOCK_PRESETS`）。
- 奖项改按「官方省线 + 省内名额」判（`bandOfLines`），修掉「省一按百分比发」的失真。
- 省选总分改为标准分：`NOIP 标准分 × 0.3 + 省选标准分 × 0.7`（标准分 = 本人 ÷ 全省最高 × 100）。
- 校验：`career-check` 三年 97 S / 47 B / 34 C；`coach-smoke --full` B 55；单文件 348 KB。

## 2026-10-19 · M3 三年生涯 + 真实赛历

- 一学年 32 周、3 学年；7 场正式比赛按 2026–27 真实日程：CSP 初赛 9/19 → 复赛 10/31 →
  NOIP 11/29 → WC 次年 2 月 → 省选 3 月（两试）→ APIO 5 月 → NOI 7 月（两试）。
- 年级系统（初一~高三）、每年升学/毕业/补新生（6 初一 + 4 高一）、生涯结算与等级。
- 全国排名：官方分数线锚点插值 → 全国分位 → 官方奖档。
- 校验：`career-check` 首次跑通 3 年；单文件 340 KB。

## 2026-10-19 · M2 教练模式 + 随机事件

- 教练模式：选队（6–8 人）、每周排训练专题/强度、处理随机事件（7 模板、约 62%/周）、
  跑比赛、赛季结算。
- 观战模式 e2e 从「路径断言」改为「`data-testid` 契约」，改文案不再静默失效。
- 校验：`coach-smoke.mjs`、`event-check.mjs`、`event-choice-check.mjs`。

## 2026-10-17 · M1 单文件游戏

- Vite + React + TS 起步；`scripts/inline.mjs` 把 `dist/` 内联成 300 KB 单文件 `OI模拟赛.html`，
  双击即玩（用户核心诉求：不装环境、能直接发同学）。



