import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

const isOpv = process.env.OPV === "1";
// MOTION=0 → 静帧版（零动画）；默认 / MOTION=1 → 满血版（完整动效）。
// 真正的开关写在 <html data-motion="..."> 上，CSS 与运行时都读它，
// 因此 scripts/inline-opv.mjs 可以用同一次构建产出两个独立 HTML。
const motion = process.env.MOTION === "0" ? "static" : "full";

export default defineConfig({
  plugins: [
    react(),
    tailwindcss(),
    // 把动效开关写死进 <html>，并在 head 留标记供内联脚本自检
    {
      name: "motion-build-marker",
      transformIndexHtml(html) {
        return html
          .replace(/<html([^>]*)>/, (_m, attrs) =>
            `<html${attrs.replace(/\s*data-motion="[^"]*"/, "")} data-motion="${motion}">`)
          .replace("</head>", `  <!-- MOTION_BUILD:${motion} -->\n  </head>`);
      },
    },
    // OPv 构建在 dist/index.html 里留一个标记，供 scripts/inline-opv.mjs 校验，
    // 免得误把普通构建的产物当成 OPv 版发出去。
    isOpv && {
      name: "opv-build-marker",
      transformIndexHtml(html) {
        return html.replace("</head>", "  <!-- OPV_BUILD_MARKER -->\n  </head>");
      },
    },
  ].filter(Boolean),
  // 构建期版本开关：只有 `OPV=1 vite build` 才会打开自定义开局（OPv 版）。
  // 普通构建 / dev server 里 __OPV__ 恒为 false，行为与原版完全一致。
  define: {
    __OPV__: JSON.stringify(isOpv),
  },
  server: {
    host: "0.0.0.0",
    port: 3000,
    strictPort: true,
    hmr: {
      port: 3000,
    },
    watch: {
      // 编辑器/工具写文件时产生的临时目录会让 Windows 的文件监听报 EBUSY
      ignored: ["**/*.tmpdir", "**/*.tmpdir/**", "**/.*.tmp", "**/.git/**"],
    },
  },
});
