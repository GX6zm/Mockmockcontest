// 诊断：按「最后一题的挂分原因」拆解 delta 分布，并打印极端样本。
import { ROSTER } from '../src/roster.ts';
import { createContest, tick, finalize } from '../src/game.ts';

const LEVELS = (process.env.LEVELS || '3,4,5').split(',').map(Number);
const RUNS = Number(process.env.RUNS || 16);
const rows = [];

for (let s = 1; s <= RUNS; s++) {
  const c = createContest({
    preset: 'school', problemCount: LEVELS.length, levels: LEVELS,
    studentCount: ROSTER.length, minutes: 180, seed: 20261018 + s,
  });
  let guard = 0;
  while (!c.isFinished && guard++ < 100000) tick(c, 30);
  for (const r of finalize(c)) rows.push({ run: s, ...r });
}

const mean = rows.reduce((a, b) => a + b.delta, 0) / rows.length;
const sorted = rows.slice().sort((a, b) => a.delta - b.delta);
console.log(`平均挂分 ${mean.toFixed(1)}  样本 ${rows.length}`);

// 按每题最后一版的原因聚合 delta
const byReason = new Map();
for (const r of rows) {
  for (const p of r.perProblem) {
    const key = p.reason || '(空)';
    let b = byReason.get(key);
    if (!b) { b = { n: 0, sum: 0, big: 0 }; byReason.set(key, b); }
    b.n++; b.sum += p.delta;
    if (p.delta <= -30) b.big++;
  }
}
console.log('\n原因分布（按题）：');
[...byReason.entries()].sort((a, b) => b[1].n - a[1].n).forEach(([k, v]) => {
  console.log(`  ${k.padEnd(26)} n=${String(v.n).padStart(4)} 平均 ${(v.sum / v.n).toFixed(1).padStart(6)}  ≤-30 ${(v.big / v.n * 100).toFixed(1)}%`);
});

console.log('\n最大挂分 8 例：');
for (const r of sorted.slice(0, 8)) {
  console.log(`  ${r.name} delta=${r.delta} real=${r.real} est=${r.est}`);
  for (const p of r.perProblem) console.log(`     P${p.problemId + 1} real=${p.real} est=${p.est} d=${p.delta} [${p.reason}] n=${p.attempts}`);
}
console.log('\n最大反挂 8 例：');
for (const r of sorted.slice(-8).reverse()) {
  console.log(`  ${r.name} delta=${r.delta} real=${r.real} est=${r.est}`);
  for (const p of r.perProblem) console.log(`     P${p.problemId + 1} real=${p.real} est=${p.est} d=${p.delta} [${p.reason}] n=${p.attempts}`);
}

// 分布：挂分与反挂幅度
const bucket = (d) => {
  const a = Math.abs(d);
  if (a <= 10) return '0-10';
  if (a <= 20) return '11-20';
  if (a <= 30) return '21-30';
  if (a <= 40) return '31-40';
  if (a <= 60) return '41-60';
  if (a <= 80) return '61-80';
  if (a <= 100) return '81-100';
  return '>100';
};
const order = ['0-10', '11-20', '21-30', '31-40', '41-60', '61-80', '81-100', '>100'];
const neg = new Map(), pos = new Map();
for (const d of order) { neg.set(d, 0); pos.set(d, 0); }
for (const r of rows) {
  if (r.delta < 0) neg.set(bucket(r.delta), neg.get(bucket(r.delta)) + 1);
  else if (r.delta > 0) pos.set(bucket(r.delta), pos.get(bucket(r.delta)) + 1);
}
console.log('\n幅度分布（%）:');
console.log('  区间     挂分    反挂');
for (const d of order) {
  console.log(`  ${d.padEnd(8)} ${(neg.get(d) / rows.length * 100).toFixed(1).padStart(6)} ${(pos.get(d) / rows.length * 100).toFixed(1).padStart(6)}`);
}
