/**
 * 教练模式赛季自检：跑若干季，看训练曲线、期末赛成绩、省一人数、教练评价。
 * 用法：node scripts/season-check.mjs [seeds=1]
 */
import { createSeason, setTeam, planWeek, runWeeklyContest, seasonReport, SEASON_WEEKS, teamStudents } from '../src/season.ts';
import { TOPIC_LIST, TOPIC_NAMES } from '../src/game.ts';

const SEEDS = Math.max(1, Number(process.argv[2] || 1));

const avg = (a) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0);

function pickTeam(season, mode) {
  const ranked = season.students.slice().sort((a, b) => b.startOverall - a.startOverall);
  if (mode === 'best') return ranked.slice(0, 6).map((s) => s.name);
  if (mode === 'worst') return ranked.slice(-6).map((s) => s.name);
  const mid = Math.floor((ranked.length - 6) / 2);
  return ranked.slice(mid, mid + 6).map((s) => s.name);
}

/** 简单教练策略：平均疲劳高就休息，否则补最弱专题 */
function planFor(season) {
  const team = teamStudents(season);
  const fatigue = avg(team.map((s) => s.fatigue));
  if (fatigue > 68) return { topic: null, intensity: 'rest' };
  let worst = null;
  let worstVal = 2;
  for (const t of TOPIC_LIST) {
    const v = avg(team.map((s) => s.skills.topics[t]));
    if (v < worstVal) { worstVal = v; worst = t; }
  }
  return { topic: worst, intensity: fatigue > 45 ? 'normal' : 'extra' };
}

function runSeason(seed, mode) {
  let s = createSeason(seed);
  const teamNames = pickTeam(s, mode);
  s = setTeam(s, teamNames);
  const log = [];
  for (let w = 0; w < SEASON_WEEKS; w++) {
    const plan = planFor(s);
    s = planWeek(s, plan);
    s = runWeeklyContest(s);
    log.push({ week: w + 1, plan, recap: s.lastContest });
  }
  return { s, log, teamNames };
}

const rows = [];
let midLog = null;
for (let k = 0; k < SEEDS; k++) {
  const seed = 20260000 + k;
  for (const mode of ['best', 'mid', 'worst']) {
    const { s, log, teamNames } = runSeason(seed, mode);
    const rep = seasonReport(s);
    if (k === 0 && mode === 'mid') midLog = { log, teamNames };
    const t = rep.team;
    rows.push({
      seed, mode,
      team: t.map((x) => x.name).join(','),
      startOverall: avg(t.map((x) => x.startOverall)).toFixed(1),
      endOverall: avg(t.map((x) => x.endOverall)).toFixed(1),
      gain: avg(t.map((x) => x.overallGain)).toFixed(1),
      rankStart: avg(t.map((x) => x.startRank)).toFixed(1),
      rankEnd: avg(t.map((x) => x.finalRank)).toFixed(1),
      rankGain: avg(t.map((x) => x.rankGain)).toFixed(1),
      sheng1: rep.provinceFirstCount,
      shengd: rep.provinceTeamCount,
      score: rep.coachScore,
      grade: rep.grade.split(' ')[0],
      top: rep.final.rows[0]?.real ?? 0,
      med: [...rep.final.rows].sort((a, b) => a.real - b.real)[Math.floor(rep.final.rows.length / 2)]?.real ?? 0,
      fatigue: Math.round(avg(teamStudents(s).map((x) => x.fatigue))),
    });
  }
}
console.table(rows);

if (midLog) {
  console.log('\n训练曲线（mid 队）：');
  for (const l of midLog.log) {
    const c = l.recap;
    const names = midLog.teamNames;
    const ranks = c.rows.filter((r) => names.includes(r.name)).map((r) => r.rank).sort((a, b) => a - b);
    const scoreSum = c.rows.filter((r) => names.includes(r.name)).reduce((a, r) => a + r.real, 0);
    console.log(
      `第${String(l.week).padStart(2)}周 ${l.plan.intensity.padEnd(6)} ${l.plan.topic ? TOPIC_NAMES[l.plan.topic].padEnd(4) : '休息 '}  ` +
      `队伍 ${scoreSum}/${c.fullScore * names.length}  名次 ${ranks.join(',')}  第一 ${c.rows[0]?.name} ${c.rows[0]?.real}`,
    );
  }
}
