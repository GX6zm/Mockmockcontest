// 用 CDP + 虚拟时间驱动无头 Edge 跑完一整场校赛，截图并检查战报徽章。
// 用法：node scripts/e2e-check.mjs [输出前缀]
import { spawn } from 'node:child_process';
import { mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const EDGE = 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const FILE = 'file:///C:/Users/%E9%AB%98%E6%96%B0%E4%B8%80%E4%B8%AD/Desktop/workspace/OI%E6%A8%A1%E6%8B%9F%E8%B5%9B.html';
const PORT = 9334;
const prefix = process.argv[2] || 'e2e';

// 注入到页面的自动驾驶脚本：开局点「开始比赛」→ 点 4x → 结束后点「公布真实成绩」
const DRIVER = `
(() => {
  const log = [];
  window.__driverLog = log;
  const clickText = (t) => {
    const b = [...document.querySelectorAll('button')].find((x) => x.textContent.trim().includes(t));
    if (b) { b.click(); return true; }
    return false;
  };
  let step = 0;
  const timer = setInterval(() => {
    if (step === 0) {
      // 把比赛时长调到最短（120 分钟），让整场跑得快一些
      const ranges = [...document.querySelectorAll('input[type=range]')];
      const dur = ranges[2];
      if (dur) {
        const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
        setter.call(dur, '120');
        dur.dispatchEvent(new Event('input', { bubbles: true }));
        log.push('duration@' + Math.round(performance.now()));
      }
      if (clickText('开始比赛')) { log.push('start@' + Math.round(performance.now())); step = 1; }
    }
    else if (step === 1) {
      // 停 2.6 秒让外部截一张赛中图，然后点「⏭ 到收卷」验快进
      if (!window.__t0) window.__t0 = performance.now();
      if (performance.now() - window.__t0 > 2600) {
        if (clickText('到收卷')) { log.push('ff@' + Math.round(performance.now())); step = 2; }
      }
    }
    else if (step === 2 && clickText('公布真实成绩')) { log.push('reveal@' + Math.round(performance.now())); step = 3; clearInterval(timer); }
    if (step >= 3 && document.body.innerText.includes('最终成绩')) clearInterval(timer);
  }, 50);
})();
`;

const profile = mkdtempSync(join(tmpdir(), 'edge-e2e-'));
const edge = spawn(EDGE, [
  '--headless=new',
  '--disable-gpu',
  '--no-first-run',
  '--no-default-browser-check',
  `--remote-debugging-port=${PORT}`,
  `--user-data-dir=${profile}`,
  '--window-size=1600,1000',
  'about:blank',
], { stdio: 'ignore' });

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function waitJson(url, tries = 80) {
  for (let i = 0; i < tries; i++) {
    try {
      const res = await fetch(url);
      if (res.ok) return await res.json();
    } catch { /* 还没起来 */ }
    await sleep(250);
  }
  throw new Error(`无法连接 ${url}`);
}

class Cdp {
  constructor(ws) {
    this.ws = ws;
    this.id = 0;
    this.pending = new Map();
    ws.addEventListener('message', (e) => {
      const msg = JSON.parse(e.data);
      if (msg.id && this.pending.has(msg.id)) {
        const { resolve, reject } = this.pending.get(msg.id);
        this.pending.delete(msg.id);
        msg.error ? reject(new Error(JSON.stringify(msg.error))) : resolve(msg.result);
      }
    });
  }
  send(method, params = {}) {
    const id = ++this.id;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.ws.send(JSON.stringify({ id, method, params }));
    });
  }
  async eval(expr) {
    const r = await this.send('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true });
    if (r.exceptionDetails) throw new Error(r.exceptionDetails.text + ' ' + JSON.stringify(r.exceptionDetails.exception?.description ?? ''));
    return r.result.value;
  }
}

const connect = async (wsUrl) => {
  const ws = new WebSocket(wsUrl);
  await new Promise((resolve, reject) => {
    ws.addEventListener('open', resolve, { once: true });
    ws.addEventListener('error', reject, { once: true });
  });
  return new Cdp(ws);
};

try {
  await waitJson(`http://127.0.0.1:${PORT}/json/version`);
  const target = await fetch(`http://127.0.0.1:${PORT}/json/new?about:blank`, { method: 'PUT' }).then((r) => r.json());
  const cdp = await connect(target.webSocketDebuggerUrl);
  await cdp.send('Page.enable');
  await cdp.send('Runtime.enable');
  await cdp.send('Page.addScriptToEvaluateOnNewDocument', { source: DRIVER });

  await cdp.send('Page.navigate', { url: FILE });

  let doneAt = 0;
  let contestShot = false;
  const started = Date.now();
  for (let i = 0; i < 180; i++) {
    await sleep(1000);
    const txt = await cdp.eval("document.body ? document.body.innerText : ''");
    if (!contestShot && txt.includes('估分榜') && !txt.includes('最终成绩')) {
      contestShot = true;
      const shot = await cdp.send('Page.captureScreenshot', { format: 'png' });
      writeFileSync(`${prefix}-contest.png`, Buffer.from(shot.data, 'base64'));
    }
    if (txt.includes('最终成绩')) { doneAt = Date.now(); break; }
  }
  if (!doneAt) {
    const txt = await cdp.eval("document.body ? document.body.innerText : ''");
    console.log('未完成。页面片段：', txt.slice(0, 300).replace(/\n/g, ' | '));
    const shot = await cdp.send('Page.captureScreenshot', { format: 'png' });
    writeFileSync(`${prefix}-stuck.png`, Buffer.from(shot.data, 'base64'));
    throw new Error('比赛没跑完');
  }
  console.log(`比赛跑完，真实耗时 ${((doneAt - started) / 1000).toFixed(1)}s`);
  console.log('驱动日志:', await cdp.eval('JSON.stringify(window.__driverLog)'));

  const shot = await cdp.send('Page.captureScreenshot', { format: 'png' });
  writeFileSync(`${prefix}-final.png`, Buffer.from(shot.data, 'base64'));

  const info = await cdp.eval(`(() => {
    const txt = document.body.innerText;
    return {
      header: (txt.split('\\n').find((l) => l.includes('题 ·')) || ''),
      badges: [...new Set(txt.match(/\\b[JS][123]\\b/g) || [])].slice(0, 12),
      badgeCount: (txt.match(/\\b[JS][123]\\b/g) || []).length,
    };
  })()`);
  console.log('标头:', info.header);
  console.log(`战报徽章 ${info.badgeCount} 个：`, info.badges.join(' '));
  process.exit(0);
} catch (err) {
  console.error('失败:', err.message);
  process.exit(1);
} finally {
  edge.kill();
  setTimeout(() => {
    try { rmSync(profile, { recursive: true, force: true }); } catch { /* 忽略 */ }
  }, 800);
}
