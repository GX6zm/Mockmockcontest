import { useState } from 'react';
import {
  ARCHETYPE_EMOJI, ARCHETYPE_NAMES, TOPIC_COLORS, TOPIC_LIST, TOPIC_NAMES, levelInfo, randomSeed,
} from './game.ts';
import {
  INTENSITY_INFO, SEASON_WEEKS, TEAM_MAX, TEAM_MIN, createSeason, planWeek, rosterSorted,
  runWeeklyContest, seasonReport, setTeam, strengthOf, teamStudents,
} from './season.ts';
import type {
  ContestRecap, SeasonReport, SeasonState, SeasonStudent, TrainingLine, TrainingReport, WeekIntensity,
} from './season.ts';
import type { Topic } from './types.ts';

const pct = (v: number) => Math.round(v * 100);

const TONE: Record<TrainingLine['tone'], { text: string; ring: string; emoji: string }> = {
  good: { text: 'text-emerald-300', ring: 'border-emerald-500/30', emoji: '📈' },
  ok: { text: 'text-sky-300', ring: 'border-sky-500/25', emoji: '🙂' },
  flat: { text: 'text-slate-400', ring: 'border-slate-600/50', emoji: '😐' },
  bad: { text: 'text-rose-300', ring: 'border-rose-500/30', emoji: '😵' },
};

export default function CoachScreen({ onExit }: { onExit: () => void }) {
  const [season, setSeason] = useState<SeasonState>(() => createSeason(randomSeed()));
  const [picked, setPicked] = useState<string[]>([]);

  const newSeason = () => {
    setPicked([]);
    setSeason(createSeason(randomSeed()));
  };

  const team = teamStudents(season);

  return (
    <div className="min-h-screen bg-[#0b0f19] text-slate-200">
      <Header season={season} team={team} onExit={onExit} onNew={newSeason} />
      <div className="max-w-6xl mx-auto px-4 pb-16">
        {season.phase === 'team' && (
          <PickTeam
            season={season}
            picked={picked}
            setPicked={setPicked}
            onStart={() => setSeason(setTeam(season, picked))}
          />
        )}
        {season.phase === 'plan' && (
          <PlanWeek season={season} onPlan={(plan) => setSeason(planWeek(season, plan))} />
        )}
        {season.phase === 'report' && season.report && (
          <ReportView
            season={season}
            report={season.report}
            onRun={() => setSeason(runWeeklyContest(season))}
          />
        )}
        {season.phase === 'result' && season.lastContest && (
          <ResultView
            season={season}
            recap={season.lastContest}
            onNext={() => setSeason({ ...season, phase: 'plan', report: null, plan: null })}
          />
        )}
        {season.phase === 'finished' && <Finale season={season} onNew={newSeason} onExit={onExit} />}
      </div>
    </div>
  );
}

// ===== 顶栏 =====
function Header({
  season, team, onExit, onNew,
}: {
  season: SeasonState; team: SeasonStudent[]; onExit: () => void; onNew: () => void;
}) {
  const week = Math.min(season.week, SEASON_WEEKS);
  const avgOverall = team.length ? team.reduce((a, s) => a + strengthOf(s), 0) / team.length : 0;
  const avgFatigue = team.length ? team.reduce((a, s) => a + s.fatigue, 0) / team.length : 0;
  return (
    <div className="sticky top-0 z-20 backdrop-blur bg-[#0b0f19]/85 border-b border-slate-800">
      <div className="max-w-6xl mx-auto px-4 py-3 flex flex-wrap items-center gap-3">
        <div className="flex items-baseline gap-2">
          <h1 className="text-lg font-black text-white">🎓 教练模式</h1>
          <span className="text-[11px] px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-300 font-bold">M1 · 赛季骨架</span>
        </div>
        <div className="text-[11px] text-slate-400 font-mono">第 <b className="text-white">{week}</b>/{SEASON_WEEKS} 周</div>
        {team.length > 0 && (
          <>
            <div className="text-[11px] text-slate-400">队伍 <b className="text-white">{team.length}</b> 人</div>
            <div className="text-[11px] text-slate-400">综合 <b className="text-white">{avgOverall.toFixed(1)}</b></div>
            <div className="text-[11px] text-slate-400">
              疲劳 <b className={avgFatigue > 65 ? 'text-rose-300' : avgFatigue > 40 ? 'text-amber-300' : 'text-emerald-300'}>{Math.round(avgFatigue)}</b>
            </div>
          </>
        )}
        <div className="flex-1" />
        <button onClick={onNew} className="text-[11px] px-2.5 py-1.5 rounded-lg border border-slate-700 text-slate-300 hover:border-indigo-400/60">
          🔄 新赛季
        </button>
        <button onClick={onExit} className="text-[11px] px-2.5 py-1.5 rounded-lg border border-slate-700 text-slate-300 hover:border-indigo-400/60">
          ← 返回观战模式
        </button>
      </div>
      <ProgressBar season={season} />
    </div>
  );
}

/** 16 周进度：每格是那周全队得分占比 */
function ProgressBar({ season }: { season: SeasonState }) {
  const byWeek = new Map<number, ContestRecap>();
  for (const c of season.contests) byWeek.set(c.week, c);
  return (
    <div className="max-w-6xl mx-auto px-4 pb-2 flex items-center gap-1">
      {Array.from({ length: SEASON_WEEKS }, (_, i) => {
        const w = i + 1;
        const c = byWeek.get(w);
        const team = c ? c.rows.filter((r) => season.team.includes(r.name)) : [];
        const frac = c && team.length ? team.reduce((a, r) => a + r.real, 0) / (c.fullScore * team.length) : 0;
        const active = season.week === w && season.phase !== 'finished';
        return (
          <div
            key={w}
            title={c ? `第 ${w} 周 · 全队均分 ${Math.round(frac * 100)}%` : `第 ${w} 周`}
            className={`h-1.5 flex-1 rounded-sm transition-all ${
              c ? 'bg-indigo-400/70' : active ? 'bg-indigo-500/40 animate-pulse' : 'bg-slate-800'
            }`}
            style={c ? { opacity: 0.35 + frac * 0.65 } : undefined}
          />
        );
      })}
    </div>
  );
}

// ===== 阶段一：选队 =====
function PickTeam({
  season, picked, setPicked, onStart,
}: {
  season: SeasonState; picked: string[]; setPicked: (v: string[]) => void; onStart: () => void;
}) {
  const ranked = rosterSorted(season);
  const toggle = (name: string) => {
    if (picked.includes(name)) setPicked(picked.filter((n) => n !== name));
    else if (picked.length < TEAM_MAX) setPicked([...picked, name]);
  };
  const ready = picked.length >= TEAM_MIN && picked.length <= TEAM_MAX;
  const avg = picked.length
    ? picked.map((n) => season.students.find((s) => s.name === n)!).reduce((a, s) => a + strengthOf(s), 0) / picked.length
    : 0;

  return (
    <div className="pt-5">
      <div className="rounded-2xl border border-slate-700/60 bg-[#111827]/80 p-5 mb-4">
        <div className="flex flex-wrap items-baseline gap-2 mb-1">
          <h2 className="text-base font-bold text-white">建队：从 {season.students.length} 人里挑 {TEAM_MIN}–{TEAM_MAX} 个</h2>
          <span className="text-[11px] text-slate-500">一赛季 16 周，每周一个专题 + 一场自动校赛</span>
        </div>
        <p className="text-[12px] text-slate-400 leading-relaxed">
          每个学生有固定性格和初始专题水平。训练按 <b className="text-slate-200">(1 − 当前水平)</b> 边际递减：
          尖子生练一周也涨不了几点，中游学生补短板反而涨得快。选谁、练什么，是这一季仅有的几个决定。
        </p>
      </div>

      <div className="grid lg:grid-cols-[1fr_280px] gap-4 items-start">
        <div className="rounded-2xl border border-slate-700/60 bg-[#111827]/70 overflow-hidden">
          <div className="max-h-[560px] overflow-y-auto">
            <table className="w-full text-[12px]">
              <thead className="sticky top-0 bg-[#0f1524] text-slate-400">
                <tr>
                  <th className="text-left px-3 py-2 font-medium w-10">#</th>
                  <th className="text-left px-2 py-2 font-medium">选手</th>
                  <th className="text-left px-2 py-2 font-medium">性格</th>
                  <th className="text-right px-2 py-2 font-medium">综合</th>
                  <th className="text-left px-3 py-2 font-medium">最擅长 / 最怕</th>
                  <th className="w-8" />
                </tr>
              </thead>
              <tbody>
                {ranked.map((st, i) => {
                  const on = picked.includes(st.name);
                  const [best, worst] = topTopics(st);
                  return (
                    <tr
                      key={st.name}
                      onClick={() => toggle(st.name)}
                      className={`cursor-pointer border-t border-slate-800/60 transition-colors ${
                        on ? 'bg-indigo-600/15' : 'hover:bg-slate-800/40'
                      }`}
                    >
                      <td className="px-3 py-1.5 text-slate-500 font-mono">{i + 1}</td>
                      <td className="px-2 py-1.5 font-bold text-slate-100">{st.name}</td>
                      <td className="px-2 py-1.5 text-slate-400">{ARCHETYPE_EMOJI[st.archetype]} {ARCHETYPE_NAMES[st.archetype]}</td>
                      <td className="px-2 py-1.5 text-right font-mono text-slate-200">{strengthOf(st).toFixed(1)}</td>
                      <td className="px-3 py-1.5 text-slate-400 whitespace-nowrap">
                        <span style={{ color: TOPIC_COLORS[best.t] }}>{TOPIC_NAMES[best.t]} {pct(best.v)}</span>
                        <span className="text-slate-600"> · </span>
                        <span className="text-rose-300/80">{TOPIC_NAMES[worst.t]} {pct(worst.v)}</span>
                      </td>
                      <td className="px-1 text-center">
                        {on ? <span className="text-indigo-300 font-bold">✓</span> : <span className="text-slate-700">+</span>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        <div className="rounded-2xl border border-indigo-500/25 bg-[#111827]/90 p-4 lg:sticky lg:top-24">
          <div className="text-[11px] text-slate-400 mb-2">已选 <b className="text-white text-sm">{picked.length}</b> / {TEAM_MAX} 人</div>
          <div className="space-y-1.5 mb-3 min-h-[120px]">
            {picked.length === 0 && <div className="text-[11px] text-slate-600 py-8 text-center">点左边的选手加入队伍</div>}
            {picked.map((n) => {
              const st = season.students.find((s) => s.name === n)!;
              return (
                <div key={n} className="flex items-center gap-2 text-[12px] bg-slate-800/60 rounded-lg px-2 py-1.5">
                  <span className="text-slate-200 font-bold truncate">{n}</span>
                  <span className="text-[10px] text-slate-500">{ARCHETYPE_NAMES[st.archetype]}</span>
                  <span className="ml-auto font-mono text-slate-400">{strengthOf(st).toFixed(1)}</span>
                  <button onClick={() => toggle(n)} className="text-slate-500 hover:text-rose-300">×</button>
                </div>
              );
            })}
          </div>
          <div className="text-[11px] text-slate-400 mb-2">
            队伍平均综合 <b className="text-white">{picked.length ? avg.toFixed(1) : '—'}</b>
          </div>
          <div className="flex gap-1.5 mb-2">
            <button
              onClick={() => setPicked(rosterSorted(season).slice(0, TEAM_MIN).map((s) => s.name))}
              className="flex-1 text-[11px] py-1.5 rounded-lg border border-slate-700 text-slate-300 hover:border-indigo-400/50"
            >
              推荐阵容
            </button>
            <button
              onClick={() => setPicked([])}
              className="flex-1 text-[11px] py-1.5 rounded-lg border border-slate-700 text-slate-300 hover:border-rose-400/50"
            >
              清空
            </button>
          </div>
          <button
            disabled={!ready}
            onClick={onStart}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 disabled:opacity-35 disabled:cursor-not-allowed text-white font-bold text-sm shadow-lg shadow-emerald-900/30 transition-all"
          >
            {ready ? '🎓 开始这个赛季' : `至少选 ${TEAM_MIN} 人`}
          </button>
        </div>
      </div>
    </div>
  );
}

function topTopics(st: SeasonStudent): [{ t: Topic; v: number }, { t: Topic; v: number }] {
  const arr = TOPIC_LIST.map((t) => ({ t, v: st.skills.topics[t] })).sort((a, b) => b.v - a.v);
  return [arr[0], arr[arr.length - 1]];
}

// ===== 阶段二：排本周训练 =====
function PlanWeek({ season, onPlan }: { season: SeasonState; onPlan: (p: { topic: Topic | null; intensity: WeekIntensity }) => void }) {
  const [topic, setTopic] = useState<Topic | null>(null);
  const [intensity, setIntensity] = useState<WeekIntensity>('normal');
  const team = teamStudents(season);
  const teamAvg = (t: Topic) => team.reduce((a, s) => a + s.skills.topics[t], 0) / Math.max(1, team.length);
  const avgFatigue = team.reduce((a, s) => a + s.fatigue, 0) / Math.max(1, team.length);
  const weakest = TOPIC_LIST.slice().sort((a, b) => teamAvg(a) - teamAvg(b))[0];
  const canGo = intensity === 'rest' || topic !== null;

  return (
    <div className="pt-5">
      <div className="rounded-2xl border border-slate-700/60 bg-[#111827]/80 p-5 mb-4 flex flex-wrap items-end gap-3">
        <div className="flex-1 min-w-[260px]">
          <h2 className="text-base font-bold text-white mb-1">第 {season.week} 周 · 排训练</h2>
          <p className="text-[12px] text-slate-400">
            全队这周只练一个专题。队伍 <b className="text-white">{team.length}</b> 人，平均疲劳 <b className={avgFatigue > 65 ? 'text-rose-300' : 'text-slate-200'}>{Math.round(avgFatigue)}</b>。
          </p>
        </div>
        <div className="text-[11px] text-amber-300/90 bg-amber-500/10 border border-amber-500/20 rounded-lg px-2.5 py-1.5">
          最弱专题：{TOPIC_NAMES[weakest]}（{pct(teamAvg(weakest))}）— 补短板通常比拔尖划算
        </div>
      </div>

      <div className="grid lg:grid-cols-[1fr_280px] gap-4 items-start">
        <div className="space-y-4">
          <div className="rounded-2xl border border-slate-700/60 bg-[#111827]/70 p-4">
            <div className="text-[11px] text-slate-400 mb-2">专题（队伍当前水平）</div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {TOPIC_LIST.map((t) => {
                const v = teamAvg(t);
                const active = topic === t;
                return (
                  <button
                    key={t}
                    disabled={intensity === 'rest'}
                    onClick={() => setTopic(t)}
                    className={`text-left rounded-lg px-2.5 py-2 border transition-all disabled:opacity-40 ${
                      active ? 'border-indigo-400/70 bg-indigo-600/20' : 'border-slate-700/70 bg-slate-800/50 hover:border-indigo-400/40'
                    }`}
                  >
                    <div className="text-[12px] font-bold text-slate-100">{TOPIC_NAMES[t]}</div>
                    <div className="flex items-center gap-1.5 mt-1">
                      <div className="h-1.5 flex-1 bg-slate-700/70 rounded overflow-hidden">
                        <div className="h-full rounded" style={{ width: `${Math.min(100, pct(v))}%`, backgroundColor: TOPIC_COLORS[t] }} />
                      </div>
                      <span className="text-[10px] font-mono text-slate-400">{pct(v)}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="rounded-2xl border border-slate-700/60 bg-[#111827]/70 p-4">
            <div className="text-[11px] text-slate-400 mb-2">强度</div>
            <div className="grid sm:grid-cols-3 gap-2">
              {(Object.keys(INTENSITY_INFO) as WeekIntensity[]).map((k) => {
                const info = INTENSITY_INFO[k];
                const active = intensity === k;
                return (
                  <button
                    key={k}
                    onClick={() => setIntensity(k)}
                    className={`text-left rounded-lg px-3 py-2.5 border transition-all ${
                      active ? 'border-emerald-400/70 bg-emerald-600/15' : 'border-slate-700/70 bg-slate-800/50 hover:border-emerald-400/40'
                    }`}
                  >
                    <div className="text-[12px] font-bold text-slate-100">{info.emoji} {info.name}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5 leading-snug">{info.note}</div>
                  </button>
                );
              })}
            </div>
            {intensity === 'extra' && avgFatigue > 40 && (
              <div className="mt-2 text-[11px] text-rose-300/90">队伍已经偏累了，继续加练周末比赛容易崩。</div>
            )}
          </div>

          <button
            disabled={!canGo}
            onClick={() => onPlan({ topic: intensity === 'rest' ? null : topic, intensity })}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 disabled:opacity-35 text-white font-bold text-sm shadow-lg shadow-indigo-900/30"
          >
            {intensity === 'rest' ? '☕ 本周休息，进入周末' : '📘 排入本周训练'}
          </button>
        </div>

        <TeamPanel season={season} />
      </div>
    </div>
  );
}

// ===== 阶段三：训练报告 =====
function ReportView({ season, report, onRun }: { season: SeasonState; report: TrainingReport; onRun: () => void }) {
  const plan = report.plan;
  const tone = { good: 0, ok: 0, flat: 0, bad: 0 } as Record<TrainingLine['tone'], number>;
  report.lines.forEach((l) => { tone[l.tone] += 1; });
  return (
    <div className="pt-5">
      <div className="rounded-2xl border border-slate-700/60 bg-[#111827]/80 p-5 mb-4">
        <div className="flex flex-wrap items-baseline gap-2">
          <h2 className="text-base font-bold text-white">
            第 {report.week} 周 · {plan.intensity === 'rest' ? '休息' : `练 ${plan.topic ? TOPIC_NAMES[plan.topic] : '自由训练'}`}
          </h2>
          <span className="text-[11px] text-slate-500">周中 · 教练的模糊观察（没有精确数字）</span>
        </div>
        <div className="flex gap-3 mt-2 text-[11px]">
          <span className="text-emerald-300">📈 状态好 {tone.good}</span>
          <span className="text-sky-300">🙂 还行 {tone.ok}</span>
          <span className="text-slate-400">😐 一般 {tone.flat}</span>
          <span className="text-rose-300">😵 白练 {tone.bad}</span>
        </div>
      </div>

      <div className="grid lg:grid-cols-[1fr_280px] gap-4 items-start">
        <div className="space-y-2">
          {report.lines.map((l) => {
            const t = TONE[l.tone];
            return (
              <div key={l.name} className={`rounded-xl border ${t.ring} bg-[#111827]/70 px-3.5 py-2.5 flex items-center gap-3`}>
                <div className="text-lg">{t.emoji}</div>
                <div className="min-w-0 flex-1">
                  <div className="text-[12px] font-bold text-slate-100">
                    {l.name}
                    <span className="text-[10px] text-slate-500 font-normal ml-1.5">{ARCHETYPE_EMOJI[l.archetype]} {ARCHETYPE_NAMES[l.archetype]}</span>
                  </div>
                  <div className={`text-[11px] ${t.text}`}>{l.text}</div>
                </div>
                <div className="w-20 shrink-0">
                  <div className="text-[9px] text-slate-500 mb-0.5">疲劳</div>
                  <div className="h-1.5 bg-slate-700/70 rounded overflow-hidden">
                    <div className={`h-full ${l.fatigue > 65 ? 'bg-rose-400' : l.fatigue > 40 ? 'bg-amber-400' : 'bg-emerald-400'}`} style={{ width: `${l.fatigue}%` }} />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div className="space-y-3 lg:sticky lg:top-24">
          <div className="rounded-2xl border border-slate-700/60 bg-[#111827]/70 p-4">
            <div className="text-[11px] text-slate-400 mb-2">周末安排</div>
            {season.week >= SEASON_WEEKS ? (
              <p className="text-[11px] leading-relaxed mb-3 text-amber-300/90">
                本周是 <b>CSP 报名赛</b>：两试，每试 4 题 · 4 小时（绿/青/蓝/紫），两天总分 800 一起排名；全校一张榜，前 15% 是省一、前三进省队。
              </p>
            ) : (
              <p className="text-[11px] text-slate-400 leading-relaxed mb-3">
                周六自动跑一场 3 题 · 3 小时的校赛（绿/青/蓝），赛后统一出分。
              </p>
            )}
            <button
              onClick={onRun}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-sm shadow-lg shadow-emerald-900/30"
            >
              {season.week >= SEASON_WEEKS ? '🏆 报名赛：开考' : '🏁 周末：模拟赛'}
            </button>
          </div>
          <TeamPanel season={season} />
        </div>
      </div>
    </div>
  );
}

// ===== 阶段四：赛后 =====
function ResultView({ season, recap, onNext }: { season: SeasonState; recap: ContestRecap; onNext: () => void }) {
  const [showAll, setShowAll] = useState(false);
  const isTeam = (n: string) => season.team.includes(n);
  const top = recap.rows.slice(0, 12);
  const teamRows = recap.rows.filter((r) => isTeam(r.name));
  const teamBest = Math.min(...teamRows.map((r) => r.rank));
  const last = recap.week >= SEASON_WEEKS;

  return (
    <div className="pt-5">
      <div className="rounded-2xl border border-slate-700/60 bg-[#111827]/80 p-5 mb-4">
        <div className="flex flex-wrap items-baseline gap-2">
          <h2 className="text-base font-bold text-white">{recap.title}</h2>
          <span className="text-[11px] text-slate-500">
            {recap.dayCount > 1 ? `两试 · 每试 ${recap.levels.length} 题 ` : ''}
            {recap.levels.map((lv) => levelInfo(lv).name).join(' / ')} · {recap.minutes} 分钟 · 满分 {recap.fullScore}
          </span>
        </div>
        <div className="flex flex-wrap gap-4 mt-2 text-[12px]">
          <span className="text-slate-400">全队得分 <b className="text-white">{teamRows.reduce((a, r) => a + r.real, 0)}</b></span>
          <span className="text-slate-400">最好名次 <b className="text-amber-300">#{teamBest}</b></span>
          <span className="text-slate-400">第一 <b className="text-slate-100">{recap.rows[0]?.name}</b> <span className="font-mono">{recap.rows[0]?.real}</span></span>
        </div>
      </div>

      <div className="grid lg:grid-cols-[1fr_280px] gap-4 items-start">
        <div className="rounded-2xl border border-slate-700/60 bg-[#111827]/70 p-4">
          <div className="flex items-center gap-2 mb-2">
            <div className="text-[11px] text-slate-400">榜单</div>
            <div className="flex-1" />
            <button onClick={() => setShowAll((v) => !v)} className="text-[11px] text-indigo-300 hover:text-indigo-200">
              {showAll ? '只看前 12' : '看完整榜单'}
            </button>
          </div>
          <table className="w-full text-[12px]">
            <thead className="text-slate-500">
              <tr>
                <th className="text-left px-2 py-1 font-medium w-12">#</th>
                <th className="text-left px-2 py-1 font-medium">选手</th>
                <th className="text-right px-2 py-1 font-medium">真分</th>
                <th className="text-right px-2 py-1 font-medium">自估</th>
                <th className="text-right px-2 py-1 font-medium">挂分</th>
                <th className="text-right px-2 py-1 font-medium">估准</th>
              </tr>
            </thead>
            <tbody>
              {(showAll ? recap.rows : top).map((r) => (
                <tr key={r.name} className={`border-t border-slate-800/60 ${isTeam(r.name) ? 'bg-indigo-600/10' : ''}`}>
                  <td className="px-2 py-1 text-slate-500 font-mono">{r.rank}</td>
                  <td className="px-2 py-1">
                    <span className="text-slate-100 font-medium">{r.name}</span>
                    {isTeam(r.name) && <span className="ml-1 text-[9px] text-indigo-300">🎓</span>}
                  </td>
                  <td className="px-2 py-1 text-right font-mono text-slate-100">{r.real}</td>
                  <td className="px-2 py-1 text-right font-mono text-slate-500">{r.est}</td>
                  <td className={`px-2 py-1 text-right font-mono ${r.delta < 0 ? 'text-rose-300' : r.delta > 0 ? 'text-emerald-300' : 'text-slate-500'}`}>
                    {r.delta > 0 ? `+${r.delta}` : r.delta}
                  </td>
                  <td className="px-2 py-1 text-right font-mono text-slate-500">{r.calibration}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {!showAll && teamRows.some((r) => r.rank > 12) && (
            <div className="mt-2 text-[10px] text-slate-500">
              队伍里还有 {teamRows.filter((r) => r.rank > 12).length} 人在 12 名开外：{teamRows.filter((r) => r.rank > 12).map((r) => `${r.name}#${r.rank}`).join('、')}
            </div>
          )}
        </div>

        <div className="space-y-3 lg:sticky lg:top-24">
          <div className="rounded-2xl border border-slate-700/60 bg-[#111827]/70 p-4">
            {last ? (
              <button onClick={onNext} className="w-full py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 text-white font-bold text-sm">
                🏆 查看赛季结算
              </button>
            ) : (
              <button onClick={onNext} className="w-full py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 text-white font-bold text-sm">
                → 进入第 {Math.min(season.week, SEASON_WEEKS)} 周
              </button>
            )}
          </div>
          <TeamPanel season={season} />
        </div>
      </div>
    </div>
  );
}

// ===== 阶段五：赛季结算 =====
function Finale({ season, onNew, onExit }: { season: SeasonState; onNew: () => void; onExit: () => void }) {
  const rep: SeasonReport = seasonReport(season);
  return (
    <div className="pt-5">
      <div className="rounded-2xl border border-indigo-500/30 bg-gradient-to-br from-[#141a2e] to-[#101827] p-6 mb-4 text-center">
        <div className="text-[11px] text-slate-400 mb-1">赛季结束 · 16 周</div>
        <div className="text-3xl font-black text-white mb-1">{rep.grade}</div>
        <div className="text-[13px] text-slate-300 max-w-xl mx-auto leading-relaxed">{rep.comment}</div>
        <div className="flex flex-wrap justify-center gap-6 mt-4 text-[12px]">
          <Stat label="教练评分" value={`${rep.coachScore}`} tone="text-indigo-300" />
          <Stat label="省一" value={`${rep.provinceFirstCount}`} tone="text-amber-300" />
          <Stat label="省队" value={`${rep.provinceTeamCount}`} tone="text-rose-300" />
          <Stat label="平均名次进步" value={`${rep.avgRankGain > 0 ? '+' : ''}${rep.avgRankGain.toFixed(1)}`} tone="text-emerald-300" />
          <Stat label="平均实力提升" value={`+${Math.max(0, rep.avgOverallGain).toFixed(1)}`} tone="text-sky-300" />
        </div>
      </div>

      <div className="grid lg:grid-cols-[1.2fr_1fr] gap-4 items-start">
        <div className="rounded-2xl border border-slate-700/60 bg-[#111827]/70 p-4">
          <div className="text-[11px] text-slate-400 mb-2">队伍成长（赛季初 → 报名赛）</div>
          <table className="w-full text-[12px]">
            <thead className="text-slate-500">
              <tr>
                <th className="text-left px-2 py-1 font-medium">选手</th>
                <th className="text-right px-2 py-1 font-medium">综合</th>
                <th className="text-right px-2 py-1 font-medium">名次</th>
                <th className="text-right px-2 py-1 font-medium">真分</th>
                <th className="text-right px-2 py-1 font-medium">结果</th>
              </tr>
            </thead>
            <tbody>
              {rep.team.slice().sort((a, b) => a.finalRank - b.finalRank).map((r) => (
                <tr key={r.name} className="border-t border-slate-800/60">
                  <td className="px-2 py-1.5 text-slate-100 font-medium">{r.name}</td>
                  <td className="px-2 py-1.5 text-right font-mono text-slate-400">
                    {r.startOverall.toFixed(0)} <span className="text-emerald-400">→ {r.endOverall.toFixed(0)}</span>
                  </td>
                  <td className="px-2 py-1.5 text-right font-mono text-slate-400">
                    #{r.startRank} <span className={r.rankGain > 0 ? 'text-emerald-400' : r.rankGain < 0 ? 'text-rose-400' : 'text-slate-500'}>→ #{r.finalRank}</span>
                  </td>
                  <td className="px-2 py-1.5 text-right font-mono text-slate-100">{r.finalReal}</td>
                  <td className="px-2 py-1.5 text-right">
                    {r.provinceTeam ? <span className="text-[10px] px-1.5 py-0.5 rounded bg-rose-500/15 text-rose-300">省队</span>
                      : r.provinceFirst ? <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-300">省一</span>
                        : <span className="text-[10px] text-slate-600">—</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="space-y-4">
          <div className="rounded-2xl border border-slate-700/60 bg-[#111827]/70 p-4">
            <div className="text-[11px] text-slate-400 mb-2">报名赛前十</div>
            <div className="space-y-1">
              {rep.final.rows.slice(0, 10).map((r) => (
                <div key={r.name} className={`flex items-center gap-2 text-[12px] px-2 py-1 rounded ${season.team.includes(r.name) ? 'bg-indigo-600/10' : ''}`}>
                  <span className="w-5 text-slate-500 font-mono">{r.rank}</span>
                  <span className="text-slate-200 truncate">{r.name}</span>
                  {season.team.includes(r.name) && <span className="text-[9px] text-indigo-300">🎓</span>}
                  <span className="ml-auto font-mono text-slate-300">{r.real}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={onNew} className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 text-white font-bold text-sm">
              🔄 再来一季
            </button>
            <button onClick={onExit} className="flex-1 py-2.5 rounded-xl border border-slate-700 text-slate-300 text-sm hover:border-indigo-400/50">
              ← 观战模式
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value, tone }: { label: string; value: string; tone: string }) {
  return (
    <div>
      <div className={`text-xl font-black ${tone}`}>{value}</div>
      <div className="text-[10px] text-slate-500">{label}</div>
    </div>
  );
}

// ===== 侧边：队伍状态 =====
function TeamPanel({ season }: { season: SeasonState }) {
  const team = teamStudents(season);
  return (
    <div className="rounded-2xl border border-slate-700/60 bg-[#111827]/70 p-3">
      <div className="text-[11px] text-slate-400 mb-2">队伍状态</div>
      <div className="space-y-1.5">
        {team.map((st) => (
          <div key={st.name} className="text-[11px]">
            <div className="flex items-center gap-1.5">
              <span className="text-slate-200 truncate">{ARCHETYPE_EMOJI[st.archetype]} {st.name}</span>
              <span className="ml-auto font-mono text-slate-400">{strengthOf(st).toFixed(1)}</span>
            </div>
            <div className="h-1 mt-0.5 bg-slate-700/60 rounded overflow-hidden">
              <div
                className={`h-full ${st.fatigue > 65 ? 'bg-rose-400' : st.fatigue > 40 ? 'bg-amber-400' : 'bg-emerald-400'}`}
                style={{ width: `${st.fatigue}%` }}
              />
            </div>
          </div>
        ))}
      </div>
      <div className="text-[9px] text-slate-600 mt-2">头像亮度 = 疲劳（越高越容易在比赛里崩）</div>
    </div>
  );
}
