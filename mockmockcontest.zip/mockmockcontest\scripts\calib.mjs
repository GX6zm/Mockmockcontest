// 估分/挂分校准：跑 N 场校赛，统计「自估 vs 真分」的偏差分布。
import { ROSTER } from '../src/roster.ts';
import { createContest, tick, finalize } from '../src/game.ts';

const LEVELS = (process.env.LEVELS || '3,4,5').split(',').map(Number);
const RUNS = Number(process.env.RUNS || 16);
const deltas = [];
let zeros = 0;
let total = 0;
let realSum = 0;
let estSum = 0;
let ak = 0;
const fullMark = LEVELS.length * 100;

for (let s = 1; s <= RUNS; s++) {
  const c = createContest({
    preset: 'school', problemCount: LEVELS.length, levels: LEVELS,
    studentCount: ROSTER.length, minutes: 180, seed: 20261018 + s,
  });
  let guard = 0;
  while (!c.isFinished && guard++ < 100000) tick(c, 30);
  for (const r of finalize(c)) {
    deltas.push(r.real - r.est);
    total++;
    realSum += r.real;
    estSum += r.est;
    if (r.real >= fullMark) ak++;
    if (r.real === 0 && r.est >= 60) zeros++;
  }
}

const mean = deltas.reduce((a, b) => a + b, 0) / deltas.length;
const sorted = [...deltas].sort((a, b) => a - b);
const pct = (f) => (deltas.filter(f).length / deltas.length * 100).toFixed(1);
const buckets = [0, 0, 0, 0, 0, 0, 0];
for (const d of deltas) {
  if (d >= 41) buckets[0]++;
  else if (d >= 11) buckets[1]++;
  else if (d >= -10) buckets[2]++;
  else if (d >= -40) buckets[3]++;
  else if (d >= -80) buckets[4]++;
  else if (d >= -120) buckets[5]++;
  else buckets[6]++;
}
console.log(`样本 ${total} 人·场（${RUNS} 场，难度 ${LEVELS.join('/')}）`);
console.log(`平均真分 ${(realSum / total).toFixed(1)} / ${fullMark}   平均估分 ${(estSum / total).toFixed(1)}   AK ${(ak / total * 100).toFixed(2)}%`);
console.log(`平均挂分 ${mean.toFixed(1)}   中位 ${sorted[Math.floor(sorted.length / 2)]}`);
console.log(`估得准（|差|≤20）  ${pct((d) => Math.abs(d) <= 20)}%`);
console.log(`挂分（真比估低 41+） ${pct((d) => d <= -41)}%`);
console.log(`反挂（真比估高 41+） ${pct((d) => d >= 41)}%`);
console.log(`挂穿（估≥60 却真 0 分） ${zeros} 人次 = ${(zeros / total * 100).toFixed(1)}%`);
console.log(`分布 ≥41:${buckets[0]} 11~40:${buckets[1]} ±10:${buckets[2]} -11~-40:${buckets[3]} -41~-80:${buckets[4]} -81~-120:${buckets[5]} <-120:${buckets[6]}`);
console.log(`最大挂分 ${sorted[0]}   最大反挂 ${sorted[sorted.length - 1]}`);
