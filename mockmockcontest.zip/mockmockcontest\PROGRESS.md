# 项目交接（PROGRESS · 给下一个 AGENT）

> 最后更新：2026-10-18 18:50（Asia/Shanghai）
> 项目：`C:\Users\高新一中\Desktop\workspace` —— OI 校赛模拟器（Vite 6 + React 18 + TS，产物是双击即玩的单文件 `OI模拟赛.html`）
> 用户偏好：干活时**每一步都要向他报告**（含轮内步骤）；喜欢「数值要经得起推导，别拍脑袋」；说话偏简洁、要中文。

---

## 0. 一句话现状

- **观战模式（模拟赛）已经稳定**：挂分模型按用户最新要求重做完（幅度递减、平均挂分 ≈ −11.8、反挂几乎不超 40），新增 **NOI** 模板。
- **教练模式 M1（赛季骨架）代码全部写完**，`tsc --noEmit` 通过，正在做最后的数值校准。
- **⚠️ 单文件产物 `OI模拟赛.html` 已在 18:32 重建（293 KB，含教练模式）**，构建流程见 §1。之后若再改 `src/` 需重新构建。

## 1. 环境与命令（关键：PATH 上没有 node / npm / git）

```powershell
$deps = "C:\Users\高新一中\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies"
& "$deps\node\bin\node.exe"            # node（v24.21.0，可直接 import .ts，不需要 ts-node）
& "$deps\node\bin\node.exe" node_modules/typescript/bin/tsc --noEmit     # 类型检查（注意是 node_modules，不是 .node_modules）
& "$deps\node\bin\node.exe" node_modules/vite/bin/vite.js build           # 构建到 dist/
& "$deps\node\bin\node.exe" scripts/inline.mjs                            # 把 dist 内联成单文件 OI模拟赛.html
```

- 没有 git，没有 npm；`package.json` 里的脚本只能手动等价执行。
- 单文件产物约 250 KB，双击即玩；`scripts/e2e-check.mjs` 用 CDP 驱动无头 Edge 打开这个产物跑完一整场校赛并截图。
- 沙箱里 `msedge --dump-dom` 输出 0 字节（不可用于静态验证）；e2e 走 CDP 是可行的。
- pwsh 控制台里中文可能显示成乱码（GBK），文件本身是 UTF-8，别被吓到。

## 2. 本轮完成的三块

### 2.1 挂分 / 估分模型重构（用户最关心，已完成）

用户原话要点：**"挂分幅度太大。幅度越大挂出的概率应该越低（代码 CE -100 的概率远小于精度 -10）；减少反挂，一般不可能反挂超过 40；平均挂分 10~20 即可。"**

核心思路改动：**估分不再是"期望值"，而是"选手自测知道的那份干净分"**。正赛发了大样例，选手自测完基本知道自己哪些子任务过了；暗病（赛后才知道的挂分）才不可知。于是 `估分误差 = 挂分 + 少量自我认知噪声`，尾部完全可控。

`src/game.ts` 现在的实现（行号会漂，函数名稳定）：

- `bugChance()` @646：挂分概率
  ```ts
  let bugP = (0.235 + (p.detail / 100) * 0.15) * clamp(0.55 + p.difficulty / 110, 0.65, 1.5)
    - st.skills.debug * 0.04 - (tested ? 0.05 : 0) - debugRounds * 0.025 - (mode === 'brute' ? 0.03 : 0);
  bugP *= 1 - 0.55 * fam;            // 顺手题手抖也少
  return clamp(bugP, 0.03, 0.5);
  ```
- `tleChance()` @659：只作为"原因风味"出现，不再是独立击杀机制。
- `expectedScore()` @671：确定性期望分，**只给 AI 决策用**（`decide`/`chooseRetry`），不展示。
- `beliefOf()` @683：估分 = `clean + (性格 bias − 全校均值) × 0.3 + gauss × (1.5 + 2.5×(1−selfAwareness))`，四舍五入到 10，clamp 0–100；另有 0.3% 概率严重低估（`clean − 30 − rng×30`）= **天神眷顾**。
- `applyDamage()` @695：**挂分梯子**，越狠越少见
  | 概率 | 打掉 | 理由文案 |
  |---|---|---|
  | 0.70 | 最小的一个子任务 | `WA · 精度写挂`（math/geometry/impl）或 `WA · 边界没处理好` |
  | 0.20 | 最大的一个 | `TLE · 常数被卡` / `WA · 多测没清空` |
  | 0.07 | 两个最大的 | 同上 |
  | 0.03 | 全灭 | `RE · 数组开小` / `CE · freopen 写错` / `WA · 算法有反例` |
- `submitAttempt()` @736：先按 `subtaskPass(gap, i, 0, p.level)` 抽 `passed[]` 得 `clean` → `est = beliefOf(clean)` → `truth = applyDamage(clean)`；最后 15 分钟内还有 `1.2% × (1 − debug×0.6)` 的**匆忙交卷忘写 freopen → CE 爆零**。
- `decide()` @777：用 `expectedScore` 决策，`doubt` 取刚记录的 `attempt.est`。

**校准结果（`scripts/calib.mjs`，40 场 × 54 人，校赛 3 题 levels [3,4,5] 180min，seed 20261018+s）**

| 指标 | 数值 |
|---|---|
| 平均真分 | 124.3 / 300 |
| 平均估分 | 136.2 |
| 平均挂分 | **−11.8**（中位 −10） |
| 估准（\|差\| ≤ 20） | 84.3% |
| 挂分 ≥ 41 | 6.3% |
| 反挂 ≥ 41 | **0.0%**（最大 +40） |
| 挂穿（估 ≥60 真 0） | 0.1% |
| AK 率 | 1.48% |

幅度递减（`scripts/calib-detail.mjs`）：0–10 分 **24.9%** → 11–20 12.2% → 21–30 4.6% → 31–40 4.3% → 41–60 3.3% → 61–80 2.4% → 81–100 0.8% → 100+ 0.5%。

### 2.2 NOI 模板（已完成）

`src/game.ts` `PRESETS`（@104）新增：

```ts
{ id: 'noi', name: 'NOI', note: '3 题 · 5 小时', levels: [5, 6, 7], minutes: 300, clock: '8:30–13:30' }
```

（NOI 正赛两天，每天 3 题 5 小时，这里跑其中一天。）设置页模板网格 `grid-cols-4` → `grid-cols-5`（`src/App.tsx:139`），README 模板表加了 NOI 行。跑 `scripts/sim-check.mjs`（12 场）确认难度合理：平均 AK 0%、平均分 33.4、最高 120–190、中位 10–40。

### 2.3 教练模式 M1：赛季骨架（代码完成，数值在收尾）

**玩法**：设置页「🎓 教练模式」→ 从 54 人里挑 6–8 人 → 16 周，每周只做一个决定（练哪个专题 × 强度 常规/加练/休息）→ 周中看**模糊**训练报告 → 周末自动跑一场 3 题 3 小时校赛 → 第 16 周是 **CSP 报名赛（两试，每试 4 题 4 小时，总分 800）** → 结算给 D/C/B/A/S 教练评分。

**新文件**

| 文件 | 行数 | 职责 |
|---|---|---|
| `src/season.ts` | ~413 | 赛季引擎：建队/排训练/跑周赛/两试合并/结算评分。**不动 `game.ts` 核心循环**，只通过 `CohortEntry[]` 把赛季技能带进比赛 |
| `src/CoachScreen.tsx` | ~593 | 全部界面：PickTeam / PlanWeek / ReportView / ResultView / Finale + Header/ProgressBar/TeamPanel |
| `scripts/season-check.mjs` | — | N seed × 3 种队伍（best/mid/worst）的赛季自检表 + 曲线 |
| `scripts/season-debug.mjs` | — | 单季逐题 dump（题目专题/等级、名次、每人 8 题的 real/est/reason/attempts） |

**`src/season.ts` 关键点**

- 常量：`SEASON_WEEKS=16`、`TEAM_MIN=6`、`TEAM_MAX=8`、`WEEKLY_LEVELS=[3,4,5]`、`WEEKLY_MINUTES=180`、`FINAL_LEVELS=[3,4,5,6]`、`FINAL_MINUTES=240`、`FINAL_DAYS=2`、`PROVINCE_FIRST_RATIO=0.15`、`PROVINCE_TEAM_SIZE=3`。
- 训练：`Δ = (1 − skill) × TRAIN_BASE(0.1) × INTENSITY_K（常规0.7 / 加练1.2）× 性格专题匹配 × talent(0.85–1.15)`；练专题顺带 `coding += Δ×0.12`、`debug += Δ×0.1`。背景 46 人 attention 0.35（只花三分之一精力），所以名次进步是真正跟同期选手比。
- 疲劳：0–100，`INTENSITY_GAIN = { normal:+5, extra:+14, rest:−38 }`；比赛加 `8×dayCount`（队员）/ `5×dayCount`（背景）。比赛内影响：`contestSkills()` 把 topics/coding/debug 乘 `1 − 0.18×f^1.3`，mental 减 `0.18f`。
- 报告 `reportOf()`：按涨幅阈值分 good/ok/flat/bad 出模糊文案（真实涨幅藏在噪声里）。
- `runOneDay()` + `mergeDays()`：两天赛各跑一场 `createContest` + `tick` 60s/步到结束，按姓名合并两天分数、`problemId` 用偏移量重编号（**坑，见 §5**），再重排名。
- 结算：`score = 30 + 12×省一 + 6×省队 + 1.2×clamp(平均实力提升,0,30)`；`GRADES` 阈值 S 88 / A 72 / B 56 / C 34 / D。**名次进步只展示不计分** —— 挑最强的人名次结构上只能往下掉，算分等于惩罚强队。
- `overallOf()` = 八专题均值×0.8 + coding×0.12 + debug×0.08。

**`src/App.tsx` 接入**：`screen` 联合类型加 `'coach'`（@48）、`if (screen === 'coach') return <CoachScreen onExit={...} />`（@58-59）、`SetupScreen` 加 `onCoach` prop（@78-80）、「🚀 开始比赛」下方加「🎓 教练模式」按钮（@238）。

**已做过的赛季校准（历史数字，供对照）**

- 第 1 轮（单场报名赛 4 题 240min）：best 队 3 省一 / 3 省队 / 69 B，mid 15 D，worst 21 D —— 但另一个 seed 的 best 只有 1 省一 / 26 D，rankGain −11.5。
- 诊断（`season-debug.mjs`）：根因是**引擎层面的每题噪声** —— `SUB_OFF = [34, 24, 2, -6]`、`LEVEL_PENALTY = 2.2`、`subtaskPass = clamp(sigmoid((gap + off + optimism)/13), 0.02, 0.985)`，即使专题 0.99、L3 的期望分也只有 ~83、sd ~17–25，前 10 名实力接近，单场 3–4 题排名近似抽奖。→ 对策：报名赛改**两试 800 分**（把噪声压下去）。
- 第 2 轮（两试 800、省一 10%）：seed A best 2 省一/1 省队/53 C、mid 32 D、worst 47 C；seed B best 1 省一/36 C。best 队名次 3,5,7,9,12,20 与 2,9,12,17,18,20，比单场稳。
- 第 3 轮（**当前**：省一改 15%≈8 人、评分去掉 rankGain、GRADES 阈值 88/72/56/34）：`scripts/season-check.mjs 3` 在写这份文档时**还在后台跑**（job `pwsh-27634bb76fc947b4`，3 seed × 3 队 ≈ 10 分钟）。**接手后第一件事就是收这个结果**。

## 3. 验证状态

| 项 | 状态 |
|---|---|
| `tsc --noEmit` | ✅ 通过（最后一次改动之后） |
| `vite build` + `inline.mjs` | ✅ 18:32 重建完成（34 modules，产物 293 KB） |
| 单文件 `OI模拟赛.html` | ✅ 最新（含 NOI + 教练模式） |
| `scripts/e2e-check.mjs` | 上次通过（20.5s，战报徽章 16 个），但跑的是旧产物，建议重跑一次 |
| `season-check 3` | ✅ 完成，结果见 §2.3 第 3 轮 |

**第 3 轮校准结果（省一 15%≈8 人、评分 30+12×省一+6×省队+1.2×实力提升、GRADES 88/72/56/34）**

| seed | 队伍 | 省一 | 省队 | 评分 | 档位 |
|---|---|---|---|---|---|
| 20260000 | best（前 6） | 3 | 1 | 74 | **A** |
| 20260000 | mid | 0 | 0 | 34 | C |
| 20260000 | worst | 0 | 0 | 41 | C |
| 20260001 | best | 1 | 1 | 50 | C |
| 20260001 | mid | 0 | 0 | 35 | C |
| 20260001 | worst | 0 | 0 | 41 | C |
| 20260002 | best | 1 | 0 | 43 | C |
| 20260002 | mid | 0 | 0 | 34 | C |
| 20260002 | worst | 0 | 0 | 41 | C |

**暴露出来的平衡问题（下一个 agent 优先处理）**：①best 队 3 个 seed 里 2 个只有 1 个省一 → 档位卡在 C，**S（88）实际不可达**；②mid/worst 队无论怎么练都是 34–41 分 C，**决策没有区分度**；③根因是引擎噪声（每题 sd ~20）+ 实力强的学生边际收益极小（`(1−skill)` 递减），背景 46 人却还在涨，所以「挑最强」结构上名次只会下滑（rankGain −5.8/−9.5/−14.2）。可行的修法（不要动 `game.ts`）：降低背景 attention（0.35→0.2，让队伍甩开大盘）；报名赛「押题」机制——最近 N 周练过的专题在期末题面里出现概率更高（让排训练真正影响考试）；或把省一权重提到 14–16 并下调 A/B 阈值。校准完再跑 `season-check 3` 复核。

## 4. 下一步 TODO（按优先级）

1. **按 §2.3 最后一段暴露的问题调平衡**：S 不可达、mid/worst 无区分度。优先试「背景 attention 降到 0.2」+「报名赛押题机制」（最近练过的专题更容易出现在期末题面），改完跑 `season-check 3` 复核；别指望靠调 GRADES 阈值糊过去（那只是把 C 换个名字）。
2. `scripts/season-debug.mjs` 再跑一季，肉眼确认：期末题目专题是否随训练变化、报告文案是否合理、Finale 数字对不对。
3. **构建**：`vite build` → `node scripts/inline.mjs`，确认 `OI模拟赛.html` 时间戳更新、约 250 KB。
4. `node scripts/e2e-check.mjs e2e` 回归观战模式；教练模式没有 e2e 脚本，可以照抄 `e2e-check.mjs` 的 CDP 驱动点进「教练模式 → 选 6 人 → 开始赛季」，至少确认不白屏。
5. README 数字复核（教练模式一节已按当前数值改写，构建后别忘再看一遍）。
6. 向用户汇报（含：NOI 已做进模拟赛、教练模式 M1 完成、挂分校准数据）。
7. 之后是 M2（比赛日观战 + 3 次干预）和 M3（赛季事件与取舍）。

## 5. 踩过的坑（别再踩）

1. **`edit` 不要吃掉行尾换行**：一次把 `// ===== 阶段四：赛后 =====\n` 的换行吃掉，下一行 `function ResultView(...)` 被注释吞掉，esbuild 报 `src/CoachScreen.tsx:508:0: ERROR: Unexpected "}"`。改多行时 new_string 要带着原来的换行。
2. **`mergeDays` 题号冲突**：两天的题都从 id 0 开始，合并后 `perProblem` 的 problemId 撞车，调试脚本报 `TypeError: Cannot read properties of undefined (reading 'topic')`（`problems.find()` 返回 undefined）。两处都要按累计偏移重编号：第二天的题 `id + pidOffset`，合并后的 perProblem 也加偏移。
3. **`node_modules` 不是 `.node_modules`**（旧记忆写错了）。
4. 校准脚本很慢：`season-check` 一个 seed × 3 队 ≈ 3–3.5 分钟，**放后台跑**，别在前台等。
5. 训练成长最初太小（base 0.06、常规 k=0.6）导致"教练决策不影响结果"——已提到 0.1/0.7，别再调回去。
6. 省一按"校内前 5"太像抽奖；现在前 15%（≈8 人），且用两天合分排名。
7. 赛季自检里的"队伍 710/300"是打印分母错（`fullScore` 没乘人数），不是引擎错。

## 6. 还没定的事

- 教练评分档位是否合理（S 88 是否真的可达）—— 等 3 seed 校准结果。
- 省一 15% 是否偏高（54 人 → 8 人）。
- 观战模式与教练模式共享 `game.ts`，任何对 `subtaskPass` / `SUB_OFF` / `LEVEL_PENALTY` 的改动会**同时**影响两边，动之前先跑 `calib.mjs`（挂分局）和 `season-check`（赛季局）两套校准。
