// ===== 领域类型 =====

export type Topic =
  | 'math' | 'dp' | 'graph' | 'greedy'
  | 'ds' | 'impl' | 'string' | 'geometry';

export type Archetype =
  | 'allrounder' | 'math_genius' | 'dp_master' | 'graph_expert' | 'brute_force'
  | 'steady' | 'explosive' | 'anxious' | 'greedy_solver' | 'impl_king';

/** 选手当前所处阶段 */
export type Phase =
  | 'idle'      // 选题
  | 'survey'    // 开场通读题面
  | 'reading'   // 读题
  | 'thinking'  // 思考
  | 'coding'    // 编码
  | 'testing'   // 对拍
  | 'deciding'  // 犹豫要不要交
  | 'restoring' // 补交暴力保底
  | 'checking'  // 没事做了：检查文件、复读题面，等收卷
  | 'done';     // 收工

export interface Subtask {
  label: string;
  points: number;
}

export interface Problem {
  id: number;
  title: string;
  topic: Topic;
  /** 洛谷难度档位 0-7：红橙黄绿青蓝紫黑 */
  level: number;
  difficulty: number; // 1-100 综合难度（由档位换算，用于内部能力对比）
  think: number;      // 思维难度
  impl: number;       // 实现难度
  detail: number;     // 细节（坑）难度
  subtasks: Subtask[];
  submitCount: number;
}

export interface Skills {
  strength: number;
  topics: Record<Topic, number>;
  coding: number;
  debug: number;
  reading: number;
  selfAwareness: number; // 估分准不准
  mental: number;
  patience: number;
  risk: number;
}

export interface Attempt {
  mode: 'brute' | 'full';
  score: number;   // 真实得分（赛中隐藏）
  est: number;     // 选手自估
  tested: boolean;
  time: number;
  reason: string;
  nth: number;
}

export interface ProblemState {
  status: 'queue' | 'active' | 'done';
  phase: Phase;
  progress: number;
  mode: 'brute' | 'full';
  tested: boolean;
  /** 对拍发现 bug、回去返工的次数 */
  debugRounds: number;
  attempts: Attempt[];
  submissions: number;
  timeSpent: number;
}

export interface Student {
  id: number;
  name: string;
  archetype: Archetype;
  skills: Skills;
  fatigue: number;
  focus: number;
  motivation: number;
  problems: ProblemState[];
  phase: Phase;
  phaseProgress: number;
  currentProblem: number | null;
  totalSubmissions: number;
  finished: boolean;
  /** 开场通读题面剩余秒数（读完全部题才开始做） */
  surveyLeft: number;
  surveyTotal: number;
}

export interface Submission {
  time: number;
  studentId: number;
  studentName: string;
  problemId: number;
  nth: number;
  mode: 'brute' | 'full';
}

export interface ContestConfig {
  preset: string;
  problemCount: number;
  /** 每题难度档位 0-7（洛谷颜色） */
  levels: number[];
  studentCount: number;
  minutes: number;
  seed: number;
  /**
   * 外部带入的阵容（教练模式用）：给了就按这份名单和技能生成选手，
   * 不再随机从校 OJ 名单里抽人。观战模式不传。
   */
  cohort?: CohortEntry[];
}

/** 教练模式里跨周保存的选手快照 */
export interface CohortEntry {
  name: string;
  archetype: Archetype;
  skills: Skills;
  /** 0-1 的疲劳（引擎内部口径，赛季的 0-100 除以 100） */
  fatigue?: number;
  focus?: number;
  motivation?: number;
}

export interface Contest {
  seed: number;
  rng: () => number;
  /** 尚未消费的模拟秒数（保证固定步长推进，与帧率无关） */
  pending: number;
  problems: Problem[];
  students: Student[];
  submissions: Submission[];
  timeElapsed: number;
  duration: number;
  isFinished: boolean;
  config: ContestConfig;
}

export interface ProblemResult {
  problemId: number;
  real: number;
  est: number;
  delta: number;
  attempts: number;
  reason: string;
  /** 历次提交的估分轨迹，用于战后复盘 */
  trail: { time: number; mode: 'brute' | 'full'; est: number; score: number }[];
}

export interface StudentResult {
  id: number;
  name: string;
  archetype: Archetype;
  real: number;
  est: number;
  delta: number;
  perProblem: ProblemResult[];
  rank: number;
  estRank: number;
  rankDelta: number; // >0 表示名次上升
  calibration: number; // 0-100 估分准确度
}
