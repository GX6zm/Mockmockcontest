﻿// 用新名单（含 CSP 混合实力）跑几场校赛，看看分数分布和 AK 率是否合理。
import { ROSTER } from '../src/roster.ts';
import { createContest, tick, finalize } from '../src/game.ts';

const N = ROSTER.length;
console.log(`名单 ${N} 人，实力范围 ${Math.min(...ROSTER.map((r) => r.strength)).toFixed(3)}–${Math.max(...ROSTER.map((r) => r.strength)).toFixed(3)}`);
console.log(`带 CSP 成绩 ${ROSTER.filter((r) => r.csp).length} 人`);

const tournamentMax = (process.env.LEVELS || '2,3,4').split(',').length;
const runs = [];
for (let seed = 1; seed <= 12; seed++) {
  const contest = createContest({
    preset: 'school',
    problemCount: (process.env.LEVELS || '2,3,4').split(',').length,
    levels: (process.env.LEVELS || '2,3,4').split(',').map(Number),
    studentCount: N,
    minutes: 180,
    seed: 20261018 + seed,
  });
  let guard = 0;
  while (!contest.isFinished && guard++ < 100000) tick(contest, 30);
  const res = finalize(contest);
  const scores = res.map((r) => r.real);
  const ak = scores.filter((s) => s >= 100 * tournamentMax).length;
  runs.push({ seed, scores, ak, avg: scores.reduce((a, b) => a + b, 0) / scores.length });
}

const akRate = runs.reduce((a, r) => a + r.ak, 0) / runs.length / N;
const avgScores = runs.map((r) => r.avg);
console.log(`\n${runs.length} 场：平均 AK 率 ${(akRate * 100).toFixed(1)}%，平均分 ${(avgScores.reduce((a, b) => a + b, 0) / runs.length).toFixed(1)}`);
for (const r of runs) {
  const s = r.scores;
  console.log(`  seed ${r.seed}: 最高 ${Math.max(...s)} 中位 ${s.slice().sort((a, b) => a - b)[Math.floor(s.length / 2)]} AK ${r.ak}`);
}

const last = runs[runs.length - 1];
console.log(`\n最后一场完整排名（前 12）：`);
const res = last.scores.map((s, i) => ({ s, i })).sort((a, b) => b.s - a.s);
for (const [k, x] of res.slice(0, 12).entries()) {
  console.log(`  ${String(k + 1).padStart(2)}. ${ROSTER[x.i].name.padEnd(12, '　')} ${String(x.s).padStart(3)} 分`);
}
