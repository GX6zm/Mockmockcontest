/**
 * 教练模式单季诊断：跑一季，dump 报名赛的题目构成与每位选手的专题实力，
 * 用来看「最强的 6 个人为什么守不住名次」。
 * 用法：node scripts/season-debug.mjs [seed=20260001] [mode=best]
 */
import { createSeason, setTeam, planWeek, runWeeklyContest, teamStudents, SEASON_WEEKS, overallOf } from '../src/season.ts';
import { TOPIC_LIST, TOPIC_NAMES } from '../src/game.ts';

const SEED = Number(process.argv[2] || 20260001);
const MODE = process.argv[3] || 'best';
const avg = (a) => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0);

let s = createSeason(SEED);
const ranked = s.students.slice().sort((a, b) => b.startOverall - a.startOverall);
const names = (MODE === 'worst' ? ranked.slice(-6) : ranked.slice(0, 6)).map((x) => x.name);
s = setTeam(s, names);

for (let w = 0; w < SEASON_WEEKS; w++) {
  const team = teamStudents(s);
  const fatigue = avg(team.map((x) => x.fatigue));
  let plan;
  if (fatigue > 68) plan = { topic: null, intensity: 'rest' };
  else {
    let worst = TOPIC_LIST[0];
    let v0 = 2;
    for (const t of TOPIC_LIST) {
      const v = avg(team.map((x) => x.skills.topics[t]));
      if (v < v0) { v0 = v; worst = t; }
    }
    plan = { topic: worst, intensity: fatigue > 45 ? 'normal' : 'extra' };
  }
  s = planWeek(s, plan);
  s = runWeeklyContest(s);
}

const final = s.lastContest;
console.log(`种子 ${SEED} · ${MODE} 队 · 报名赛 ${final.levels.join('/')} · 满分 ${final.fullScore}`);
console.log('题目：' + final.problems.map((p) => `${TOPIC_NAMES[p.topic]}(L${p.level},think=${Math.round(p.think)})`).join('  '));

const rows = final.rows.map((r) => {
  const st = s.students.find((x) => x.name === r.name);
  const topics = final.problems.map((p) => (st.skills.topics[p.topic] * 100).toFixed(0)).join('/');
  return {
    rank: r.rank, name: r.name, team: s.team.includes(r.name) ? 'Y' : '',
    real: r.real, est: r.est, start: st.startOverall.toFixed(1), end: overallOf(st.skills).toFixed(1),
    topicSkills: topics, mental: (st.skills.mental * 100).toFixed(0), arch: st.archetype,
  };
});
console.table(rows.slice(0, 20));
console.log('\n队伍成员名次：' + rows.filter((r) => r.team).map((r) => `#${r.rank} ${r.name}`).join('  '));

console.log('\n逐题明细（前 8 名 + 全体队员）：');
const show = new Set(rows.slice(0, 8).map((r) => r.name));
for (const r of final.rows.filter((x) => show.has(x.name) || s.team.includes(x.name))) {
  console.log(`#${r.rank} ${r.name}${s.team.includes(r.name) ? '（队）' : ''}  real=${r.real} est=${r.est}`);
  for (const pr of r.perProblem) {
    const p = final.problems.find((x) => x.id === pr.problemId);
    console.log(
      `   ${TOPIC_NAMES[p.topic].padEnd(4)}(L${p.level},think=${Math.round(p.think)}) ` +
      `real=${String(pr.real).padStart(3)} est=${String(pr.est).padStart(3)} attempts=${pr.attempts} ${pr.reason} trail=[${pr.trail.map((t) => t.score).join(',')}]`,
    );
  }
}
