/**
 * 教练模式 · 赛季引擎（M1：周推进 + 单专题训练 + 自动跑校赛 + 赛季结算）
 *
 * 一赛季 16 周 ≈ 一个学期：
 * - 每周排一次训练（8 个专题选 1 + 强度：常规 / 加练 / 休息）
 * - 训练报告只说"手感"，不给数字，真实变化藏在噪声里
 * - 周末自动跑一场校赛（3 题 · 3 小时 · 绿/青/蓝），期末是「CSP 报名赛」（两试，各 4 题 4 小时）
 * - 其余 46 人也在自己练，作为背景一起成长
 * - 结算看送进省一 / 省队的人数，以及队伍名次的进步
 *
 * 原则：不动 game.ts 的核心循环，只通过 cohort 把赛季里的技能带进比赛。
 */
import { ROSTER } from './roster.ts';
import {
  TOPIC_LIST, TOPIC_NAMES, buildCohort, createContest, finalize, makeRng, tick, topicAffinity,
} from './game.ts';
import type { Archetype, CohortEntry, Problem, Skills, StudentResult, Topic } from './types.ts';

export const SEASON_WEEKS = 16;
export const TEAM_MIN = 6;
export const TEAM_MAX = 8;
/** 平时周末校赛：绿 / 青 / 蓝 */
export const WEEKLY_LEVELS = [3, 4, 5];
/** 期末 CSP 报名赛：两试，每天 4 题 4 小时（绿/青/蓝/紫），按两天总分排省一 */
export const FINAL_LEVELS = [3, 4, 5, 6];
export const WEEKLY_MINUTES = 180;
export const FINAL_MINUTES = 240;
export const FINAL_DAYS = 2;
/** 省一名次线：全校前 15%（约 8 人） */
const PROVINCE_FIRST_RATIO = 0.15;
/** 省队名次线 */
const PROVINCE_TEAM_SIZE = 3;

export type WeekIntensity = 'normal' | 'extra' | 'rest';
export type SeasonPhase = 'team' | 'plan' | 'report' | 'result' | 'finished';

export interface SeasonStudent {
  name: string;
  archetype: Archetype;
  skills: Skills;
  startSkills: Skills;
  /** 赛季初综合实力（0-100） */
  startOverall: number;
  /** 赛季初综合实力排名 */
  startRank: number;
  /** 0-100 的疲劳 */
  fatigue: number;
  /** 个体天赋 0.85-1.15，决定同样训练涨多快 */
  talent: number;
  onTeam: boolean;
}

export interface WeekPlan {
  topic: Topic | null;
  intensity: WeekIntensity;
}

export interface TrainingLine {
  name: string;
  archetype: Archetype;
  text: string;
  /** 'good' | 'ok' | 'flat' | 'bad' */
  tone: 'good' | 'ok' | 'flat' | 'bad';
  fatigue: number;
}

export interface TrainingReport {
  week: number;
  plan: WeekPlan;
  lines: TrainingLine[];
}

export interface ContestRecap {
  week: number;
  title: string;
  levels: number[];
  minutes: number;
  rows: StudentResult[];
  fullScore: number;
  /** 本场题目（赛后可以回看考了哪些专题） */
  problems: Problem[];
  /** 考了几天（只有期末是两试） */
  dayCount: number;
}

export interface SeasonState {
  seed: number;
  /** 当前周 1..16；跑完期末赛后变 17 */
  week: number;
  phase: SeasonPhase;
  students: SeasonStudent[];
  team: string[];
  plan: WeekPlan | null;
  report: TrainingReport | null;
  lastContest: ContestRecap | null;
  contests: ContestRecap[];
}

// ===== 小工具 =====
const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

const cloneSkills = (s: Skills): Skills => JSON.parse(JSON.stringify(s)) as Skills;

/** 综合实力 0-100：八专题为主，coding / debug 加权两成 */
export function overallOf(s: Skills): number {
  const topicAvg = TOPIC_LIST.reduce((a, t) => a + s.topics[t], 0) / TOPIC_LIST.length;
  return Math.round((topicAvg * 0.8 + s.coding * 0.12 + s.debug * 0.08) * 1000) / 10;
}

export function strengthOf(st: SeasonStudent): number {
  return overallOf(st.skills);
}

function contestSkills(st: SeasonStudent): Skills {
  const f = st.fatigue / 100;
  const k = 1 - 0.18 * Math.pow(f, 1.3);
  const topics = {} as Record<Topic, number>;
  for (const t of TOPIC_LIST) topics[t] = clamp(st.skills.topics[t] * k, 0.03, 0.99);
  return {
    ...st.skills,
    topics,
    coding: clamp(st.skills.coding * k, 0.03, 0.99),
    debug: clamp(st.skills.debug * k, 0.03, 0.99),
    mental: clamp(st.skills.mental - 0.18 * f, 0.05, 1),
  };
}

// ===== 开局：整份名单 + 选队 =====
export function createSeason(seed: number): SeasonState {
  const cohort = buildCohort(seed >>> 0);
  const rng = makeRng((seed * 7919 + 17) >>> 0);
  const students: SeasonStudent[] = cohort.map((e) => {
    const skills = cloneSkills(e.skills);
    return {
      name: e.name,
      archetype: e.archetype,
      skills,
      startSkills: cloneSkills(e.skills),
      startOverall: overallOf(skills),
      startRank: 0,
      fatigue: 0,
      talent: 0.85 + rng() * 0.3,
      onTeam: false,
    };
  });
  // 赛季初实力排名
  students
    .slice()
    .sort((a, b) => b.startOverall - a.startOverall)
    .forEach((st, i) => { st.startRank = i + 1; });
  return {
    seed: seed >>> 0,
    week: 1,
    phase: 'team',
    students,
    team: [],
    plan: null,
    report: null,
    lastContest: null,
    contests: [],
  };
}

export function setTeam(s: SeasonState, names: string[]): SeasonState {
  const team = names.filter((n) => s.students.some((st) => st.name === n)).slice(0, TEAM_MAX);
  return {
    ...s,
    team,
    phase: 'plan',
    students: s.students.map((st) => ({ ...st, onTeam: team.includes(st.name) })),
  };
}

export function teamStudents(s: SeasonState): SeasonStudent[] {
  return s.team
    .map((n) => s.students.find((st) => st.name === n))
    .filter((x): x is SeasonStudent => Boolean(x));
}

// ===== 一周训练 =====
const INTENSITY_GAIN: Record<WeekIntensity, number> = { normal: 5, extra: 14, rest: -38 };
const INTENSITY_K: Record<WeekIntensity, number> = { normal: 0.7, extra: 1.2, rest: 0 };
/** 训练基础效率：同专题一周能吃掉多少"剩余空间" */
const TRAIN_BASE = 0.1;

function reportOf(growth: number, fatigue: number, intensity: WeekIntensity): { text: string; tone: TrainingLine['tone'] } {
  if (intensity === 'rest') {
    return { text: fatigue > 55 ? '休息了一周，缓过来一些' : '这周放松，状态拉满', tone: 'ok' };
  }
  let base: string;
  let tone: TrainingLine['tone'];
  if (growth >= 0.05) { base = '这周练透了，专题明显上了一个台阶'; tone = 'good'; }
  else if (growth >= 0.026) { base = '稳步在涨，手感不错'; tone = 'good'; }
  else if (growth >= 0.011) { base = '有点进步，但不算多'; tone = 'ok'; }
  else if (growth >= 0.004) { base = '基本原地踏步'; tone = 'flat'; }
  else { base = '几乎没吸收进去，像白练了一周'; tone = 'bad'; }
  if (fatigue >= 78) base += '，不过人已经很疲惫了';
  else if (fatigue >= 58) base += '，人有点累';
  return { text: base, tone };
}

export function planWeek(s: SeasonState, plan: WeekPlan): SeasonState {
  const rng = makeRng((s.seed * 131 + s.week * 977 + 1) >>> 0);
  const k = INTENSITY_K[plan.intensity];
  const gain = INTENSITY_GAIN[plan.intensity];
  const lines: TrainingLine[] = [];

  const students = s.students.map((st) => {
    const skills = cloneSkills(st.skills);
    let growth = 0;
    let trainedTopic: Topic | null = null;
    if (k > 0) {
      // 队员按教练安排的专题练；背景选手自己瞎练（随机专题），教练管不到
      trainedTopic = st.onTeam && plan.topic ? plan.topic : TOPIC_LIST[Math.floor(rng() * TOPIC_LIST.length)] ?? null;
      if (trainedTopic) {
        const cur = skills.topics[trainedTopic];
        const attention = st.onTeam ? 1 : 0.35;
        growth = (1 - cur) * TRAIN_BASE * k * attention * topicAffinity(st.archetype, trainedTopic) * st.talent;
        growth *= 0.6 + rng() * 0.8;
        skills.topics[trainedTopic] = clamp(cur + growth, 0.05, 0.99);
        // 练专题顺带磨出来的一点实现 / 调试手感
        skills.coding = clamp(skills.coding + growth * 0.12, 0.05, 0.99);
        skills.debug = clamp(skills.debug + growth * 0.1, 0.05, 0.99);
      }
    }
    const fatigue = clamp(st.fatigue + gain, 0, 100);
    if (st.onTeam) {
      const r = reportOf(growth, fatigue, plan.intensity);
      lines.push({ name: st.name, archetype: st.archetype, text: r.text, tone: r.tone, fatigue });
    }
    return { ...st, skills, fatigue };
  });

  return {
    ...s,
    students,
    plan,
    report: { week: s.week, plan, lines },
    phase: 'report',
  };
}

// ===== 周末自动跑一场 =====
/** 跑一天：回来一天的榜单和题目 */
function runOneDay(cohort: CohortEntry[], levels: number[], minutes: number, seed: number) {
  const cfg = {
    preset: 'season-week',
    problemCount: levels.length,
    levels,
    studentCount: cohort.length,
    minutes,
    seed,
    cohort,
  };
  const contest = createContest(cfg);
  let guard = 0;
  while (!contest.isFinished && guard++ < 20000) tick(contest, 60);
  return { rows: finalize(contest), problems: contest.problems as Problem[] };
}

/**
 * 两试合并：两天各考一次，按两天总分重排
 * （单场 4 题的噪声太大，一场定省一名额太看运气）
 */
function mergeDays(runs: { rows: StudentResult[]; problems: Problem[] }[], fullScore: number): StudentResult[] {
  const offsets: number[] = [];
  let acc = 0;
  for (const r of runs) { offsets.push(acc); acc += r.problems.length; }

  const byName = new Map<string, StudentResult>();
  runs.forEach((run, i) => {
    const off = offsets[i] ?? 0;
    for (const row of run.rows) {
      const perProblem = row.perProblem.map((pr) => ({ ...pr, problemId: pr.problemId + off }));
      const prev = byName.get(row.name);
      if (!prev) {
        byName.set(row.name, { ...row, perProblem });
      } else {
        prev.real += row.real;
        prev.est += row.est;
        prev.delta = prev.real - prev.est;
        prev.perProblem = [...prev.perProblem, ...perProblem];
      }
    }
  });

  const rows = [...byName.values()];
  rows.sort((a, b) => b.real - a.real);
  rows.forEach((r, i) => { r.rank = i + 1; });
  const byEst = rows.slice().sort((a, b) => b.est - a.est);
  byEst.forEach((r, i) => { r.estRank = i + 1; });
  for (const r of rows) {
    r.rankDelta = r.estRank - r.rank;
    r.calibration = clamp(100 - (Math.abs(r.delta) / fullScore) * 100, 0, 100);
  }
  return rows;
}

export function runWeeklyContest(s: SeasonState): SeasonState {
  const week = s.week;
  const isFinal = week >= SEASON_WEEKS;
  const levels = (isFinal ? FINAL_LEVELS : WEEKLY_LEVELS).slice();
  const minutes = isFinal ? FINAL_MINUTES : WEEKLY_MINUTES;
  const dayCount = isFinal ? FINAL_DAYS : 1;
  const title = isFinal ? 'CSP 报名赛（两试）' : `第 ${week} 周 · 周末校赛`;

  const cohort: CohortEntry[] = s.students.map((st) => ({
    name: st.name,
    archetype: st.archetype,
    skills: contestSkills(st),
    // 赛季疲劳 0-100 折算成引擎的 0-0.7，赛中还会继续累
    fatigue: Math.min(0.68, (st.fatigue / 100) * 0.55),
  }));

  const fullScore = levels.length * 100 * dayCount;
  const seedBase = (s.seed * 31 + week * 7919 + 5) >>> 0;
  const runs = Array.from({ length: dayCount }, (_, d) => runOneDay(cohort, levels, minutes, (seedBase + d * 1013) >>> 0));
  const rows = dayCount > 1 ? mergeDays(runs, fullScore) : runs[0].rows;
  // 两试的题号接在一起（0-3 / 4-7），跟 mergeDays 里的 perProblem 偏移保持一致
  const problems: Problem[] = [];
  let pidOffset = 0;
  for (const r of runs) {
    for (const p of r.problems) problems.push({ ...p, id: p.id + pidOffset });
    pidOffset += r.problems.length;
  }

  const recap: ContestRecap = {
    week,
    title,
    levels,
    minutes,
    rows,
    fullScore,
    problems,
    dayCount,
  };

  return {
    ...s,
    week: week + 1,
    phase: isFinal ? 'finished' : 'result',
    // 打完一场 3 小时的比赛本身也很耗人：队员 +8，陪跑的背景选手 +5
    students: s.students.map((st) => ({
      ...st,
      fatigue: clamp(st.fatigue + (st.onTeam ? 8 : 5) * dayCount, 0, 100),
    })),
    report: s.report,
    lastContest: recap,
    contests: [...s.contests, recap],
  };
}

// ===== 赛季结算 =====
export interface SeasonRow {
  name: string;
  archetype: Archetype;
  onTeam: boolean;
  startOverall: number;
  endOverall: number;
  overallGain: number;
  startRank: number;
  finalRank: number;
  rankGain: number;
  finalReal: number;
  provinceFirst: boolean;
  provinceTeam: boolean;
}

export interface SeasonReport {
  rows: SeasonRow[];
  team: SeasonRow[];
  provinceFirstCount: number;
  provinceTeamCount: number;
  coachScore: number;
  grade: string;
  comment: string;
  final: ContestRecap;
  avgRankGain: number;
  avgOverallGain: number;
}

const GRADES: { min: number; grade: string; comment: string }[] = [
  { min: 88, grade: 'S · 传奇教练', comment: '这一届被你带成了传说，省队名单上写满了你的学生。' },
  { min: 72, grade: 'A · 金牌教练', comment: '队伍整体抬了一大截，报名赛上好几张省一证书是你学生的。' },
  { min: 56, grade: 'B · 优秀教练', comment: '训练有效果，已经有学生摸到省一线，离顶尖教练差一口气。' },
  { min: 34, grade: 'C · 合格教练', comment: '稳住了基本盘，成绩单不好看也不难看。' },
  { min: 0, grade: 'D · 新手上路', comment: '训练安排乱成一团，学生大多在原地打转。' },
];

export function seasonReport(s: SeasonState): SeasonReport {
  const final = s.lastContest ?? s.contests[s.contests.length - 1];
  const rows: SeasonRow[] = s.students.map((st) => {
    const res = final?.rows.find((r) => r.name === st.name);
    const endOverall = overallOf(st.skills);
    return {
      name: st.name,
      archetype: st.archetype,
      onTeam: st.onTeam,
      startOverall: st.startOverall,
      endOverall,
      overallGain: endOverall - st.startOverall,
      startRank: st.startRank,
      finalRank: res?.rank ?? s.students.length,
      rankGain: st.startRank - (res?.rank ?? s.students.length),
      finalReal: res?.real ?? 0,
      provinceFirst: false,
      provinceTeam: false,
    };
  });

  // 省一：期末赛前 15%（四舍五入，至少 1 人）；省队：前三
  const firstLine = Math.max(1, Math.round(rows.length * PROVINCE_FIRST_RATIO));
  for (const r of rows) {
    r.provinceFirst = r.finalRank <= firstLine;
    r.provinceTeam = r.finalRank <= PROVINCE_TEAM_SIZE;
  }

  const team = rows.filter((r) => r.onTeam);
  const provinceFirstCount = team.filter((r) => r.provinceFirst).length;
  const provinceTeamCount = team.filter((r) => r.provinceTeam).length;

  const avgRankGain = team.length ? team.reduce((a, r) => a + r.rankGain, 0) / team.length : 0;
  const avgOverallGain = team.length ? team.reduce((a, r) => a + r.overallGain, 0) / team.length : 0;

  // 教练的成果最终看省一名单：省一为主，省队（前三）加成，实力提升为辅
  // （名次进步只做展示——挑最强的人名次只能往下掉，拿它算分反而惩罚强队）
  let score = 30;
  score += provinceFirstCount * 12;
  score += provinceTeamCount * 6;
  score += clamp(avgOverallGain, 0, 30) * 1.2;
  const coachScore = Math.round(clamp(score, 0, 100));
  const g = GRADES.find((x) => coachScore >= x.min) ?? GRADES[GRADES.length - 1];

  return {
    rows,
    team,
    provinceFirstCount,
    provinceTeamCount,
    coachScore,
    grade: g.grade,
    comment: g.comment,
    final,
    avgRankGain,
    avgOverallGain,
  };
}

// ===== 给 UI 用的杂项 =====
export const INTENSITY_INFO: Record<WeekIntensity, { name: string; note: string; emoji: string }> = {
  normal: { name: '常规训练', note: '每天一节专题课，涨得稳、不累人', emoji: '📘' },
  extra: { name: '加练', note: '晚上加课 + 周末加测，涨得快但人会被榨干', emoji: '🔥' },
  rest: { name: '休息', note: '这周放假，恢复疲劳，专题不涨', emoji: '☕' },
};

export function topicNameOf(t: Topic): string {
  return TOPIC_NAMES[t];
}

/** 名单排序：实力从高到低 */
export function rosterSorted(s: SeasonState): SeasonStudent[] {
  return s.students.slice().sort((a, b) => strengthOf(b) - strengthOf(a));
}

export function nameOfRoster(): string[] {
  return ROSTER.map((r) => r.name);
}
