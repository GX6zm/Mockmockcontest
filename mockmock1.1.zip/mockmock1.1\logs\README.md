# logs/

自动校验的运行日志，由 `scripts/log.mjs` 追加写入，**不要手改**。

- `verify.log` —— 每次跑完检查脚本追加一行：

  ```
  2026-10-19 21:30:11 [career-check] seeds=20261019/777/4242 runs=3 best=91S worst=20C spread=71 ms=541.4
  2026-10-19 21:31:02 [coach-smoke] args=--full result=ok
  2026-10-19 21:31:40 [trace-check] seed=20261019 contests=25 mismatches=0
  ```

## 谁在写

| 脚本 | 记录内容 |
| --- | --- |
| `scripts/career-check.mjs` | 种子、条数、最高/最低评分与等级、强弱差、耗时 |
| `scripts/coach-smoke.mjs` | 参数（`--full` 等）、成功/失败 |
| `scripts/e2e-check.mjs` | 成功/失败 |
| `scripts/trace-check.mjs` | 种子、回放场数、逐分不一致数 |

## 怎么用

1. **改数值前后各跑一次**，对比同一行数字就知道有没有漂移（例：调完 `stage.curve` 后
   `career-check` 的 `best=` 从 91S 变成多少）。
2. 日志只追加不覆盖；要留档某次大改，把它复制进 `CHANGELOG.md` 的对应条目。
3. 想手动记一笔改动的理由，用 `logNote(tag, message)`（`scripts/log.mjs` 导出）。

## 为什么不用 console 输出就够了

控制台输出一次就没了；`career-check` 一次要跑 9 分钟、`coach-smoke` 要开无头浏览器，
回头「上一版是多少分」经常想不起来，所以把关键数字落到文件里。
