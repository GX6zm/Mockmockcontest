import { useEffect, useMemo, useRef, useState } from 'react';
import confetti from 'canvas-confetti';
import {
  LEVELS,
  PRESETS,
  ROSTER_SIZE,
  createContest,
  finalize,
  formatTime,
  levelInfo,
  randomSeed,
} from './game.ts';
import { ROSTER } from './roster.ts';
import { buildEasterReport } from './easter.ts';
import CoachScreen from './CoachScreen.tsx';
import { ContestScreen, Shell } from './ContestScreen.tsx';
import { loadGrowth, ratingBoard, settleContest } from './growth.ts';
import type { GrowthResult } from './growth.ts';
import type { Contest, ContestConfig, StudentResult } from './types.ts';

const AVG_START_RATING = Math.round(ROSTER.reduce((a, r) => a + r.rating0, 0) / Math.max(1, ROSTER.length));

/** 名字 -> CSP 最好成绩，用于赛后战报标注 */
const CSP_BY_NAME = new Map(ROSTER.filter((r) => r.csp).map((r) => [r.name, r.csp!]));
const OIERDB_BY_NAME = new Map(ROSTER.filter((r) => r.oierdb).map((r) => [r.name, r.oierdb!]));
const CSP_LABEL = (csp: { group: 'j' | 's'; award: number }) => `${csp.group === 's' ? 'S' : 'J'}${csp.award}`;
const CSP_COLOR = { 1: 'text-amber-300 bg-amber-500/10', 2: 'text-slate-300 bg-slate-500/15', 3: 'text-orange-300/80 bg-orange-500/10' } as const;

const DEFAULT_CFG: ContestConfig = {
  preset: 'school',
  problemCount: 3,
  levels: [3, 4, 5],
  studentCount: ROSTER_SIZE, // 默认全员参赛
  minutes: 180,
  seed: 20261018,
};

// ===== 主组件 =====
export default function App() {
  const [screen, setScreen] = useState<'setup' | 'coach' | 'contest' | 'reveal'>('setup');
  const [cfg, setCfg] = useState<ContestConfig>(DEFAULT_CFG);
  const [contest, setContest] = useState<Contest | null>(null);

  const start = (next: ContestConfig) => {
    setCfg(next);
    setContest(createContest(next));
    setScreen('contest');
  };

  if (screen === 'coach') {
    return <CoachScreen onExit={() => setScreen('setup')} />;
  }
  if (screen === 'setup' || !contest) {
    return <SetupScreen initial={cfg} onStart={start} onCoach={() => setScreen('coach')} />;
  }
  if (screen === 'contest') {
    return <ContestScreen contest={contest} onFinish={() => setScreen('reveal')} />;
  }
  return (
    <RevealScreen
      contest={contest}
      onRestart={() => start({ ...cfg, seed: randomSeed() })}
      onNewSetup={() => setScreen('setup')}
    />
  );
}

// ===== 赛前设置 =====
function SetupScreen({
  initial, onStart, onCoach,
}: {
  initial: ContestConfig; onStart: (c: ContestConfig) => void; onCoach: () => void;
}) {
  const preset = PRESETS.find((p) => p.id === initial.preset) || PRESETS[0];
  const [presetId, setPresetId] = useState(preset.id);
  const [count, setCount] = useState(initial.problemCount);
  const [levels, setLevels] = useState<number[]>(initial.levels.slice());
  const [students, setStudents] = useState(initial.studentCount);
  const [minutes, setMinutes] = useState(initial.minutes);
  const [seed, setSeed] = useState(initial.seed);

  const applyPreset = (id: string) => {
    const p = PRESETS.find((x) => x.id === id) || PRESETS[0];
    setPresetId(p.id);
    setCount(p.levels.length);
    setLevels(p.levels.slice());
    setMinutes(p.minutes);
  };

  const setCountSafe = (n: number) => {
    setCount(n);
    setLevels((prev) => {
      const next = prev.slice();
      // 加题时按“由易到难再压轴”的顺序补默认颜色
      const filler = [1, 2, 3, 5, 6, 4, 7, 2, 3, 5, 6, 4];
      while (next.length < n) next.push(filler[next.length % filler.length]);
      return next.slice(0, n);
    });
  };

  const setLevelAt = (i: number, lv: number) => {
    setLevels((prev) => {
      const next = prev.slice();
      next[i] = lv;
      return next;
    });
  };

  const launch = () =>
    onStart({
      preset: presetId,
      problemCount: count,
      levels: levels.slice(0, count),
      studentCount: students,
      minutes,
      seed: seed >>> 0,
    });

  return (
    <div className="min-h-screen bg-[#0b0f19] text-slate-200 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl grid lg:grid-cols-[1.15fr_0.85fr] gap-4">
        <div className="rounded-2xl border border-indigo-500/20 bg-[#111827]/90 p-6 shadow-2xl">
          <div className="flex items-baseline gap-2">
            <h1 className="text-2xl font-black tracking-tight text-white">OI 模拟赛</h1>
            <span className="text-[11px] px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-300 font-bold">校赛版</span>
          </div>
          <p className="text-slate-400 text-xs mt-1 mb-5">无实时评测 · 上帝视角估分 · 赛后统一出分</p>

          <div className="mb-4">
            <div className="text-[11px] text-slate-400 mb-1.5">赛事模板</div>
            <div className="grid grid-cols-5 gap-1.5">
              {PRESETS.map((p) => (
                <button
                  key={p.id}
                  onClick={() => applyPreset(p.id)}
                  className={`rounded-lg px-1.5 py-2 text-left transition-all border ${
                    presetId === p.id
                      ? 'bg-indigo-600/25 border-indigo-400/60 text-white'
                      : 'bg-slate-800/60 border-slate-700/60 text-slate-300 hover:border-indigo-400/40'
                  }`}
                >
                  <div className="text-[11px] font-bold whitespace-nowrap">{p.name}</div>
                  <div className="text-[9px] text-slate-400 mt-0.5 whitespace-nowrap">{p.note}</div>
                  <div className="text-[8px] text-slate-500 mt-0.5 whitespace-nowrap">{p.clock}</div>
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-4">
            <Slider label="题目数量" value={count} min={3} max={10} step={1} onChange={setCountSafe} suffix="题" />
            <Slider label="参赛人数" value={students} min={5} max={ROSTER_SIZE} step={1} onChange={setStudents} suffix="人" />
            <Slider label="比赛时长" value={minutes} min={120} max={300} step={30} onChange={setMinutes} suffix="分钟" testId="cfg-duration" />
            <div>
              <div className="text-[11px] text-slate-400 mb-1">随机种子</div>
              <div className="flex gap-1.5">
                <input
                  type="number"
                  value={seed}
                  onChange={(e) => setSeed(Number(e.target.value) || 0)}
                  className="flex-1 min-w-0 bg-slate-800/80 border border-slate-700 rounded-lg px-2 py-1 text-xs font-mono text-slate-200 outline-none focus:border-indigo-400"
                />
                <button
                  onClick={() => setSeed(randomSeed())}
                  className="px-2 rounded-lg bg-slate-800 border border-slate-700 text-sm hover:border-indigo-400"
                  title="换一个种子"
                >
                  🎲
                </button>
              </div>
            </div>
          </div>
          <div className="-mt-2 mb-4 text-[10px] leading-relaxed text-slate-500">
            名单来自校 OJ 排行榜（仅保留 LV2 及以上，共 {ROSTER_SIZE} 人，默认全员参赛），
            其中 {ROSTER.filter((r) => r.oierdb).length} 人的 OIerDb 正赛成绩、
            {ROSTER.filter((r) => r.csp).length} 人的 CSP 获奖已并入初始 rating 换算（正赛 80% + 校 OJ 20%，
            没正赛记录的只看校 OJ），初始 rating 平均 {AVG_START_RATING}。每场比赛后按名次结算 rating：爆冷名次涨得多，热门翻车掉得多。
          </div>

          <div className="mb-5">
            <div className="text-[11px] text-slate-400 mb-1.5 flex items-center gap-2">
              题目难度（洛谷颜色）
              <span className="text-[9px] text-slate-500">点色块切换，同色题在赛内还有 ±3 的强弱抖动</span>
            </div>
            <div className="flex flex-wrap gap-1.5 mb-2.5">
              {LEVELS.map((L) => (
                <span
                  key={L.id}
                  className="px-1.5 py-0.5 rounded text-[9px] font-medium"
                  style={{ backgroundColor: L.color + '26', color: L.ink }}
                  title={L.en}
                >
                  {L.name}
                </span>
              ))}
            </div>
            <div className="space-y-2 max-h-[280px] overflow-y-auto pr-1">
              {levels.slice(0, count).map((lv, i) => (
                <div key={i} className="flex items-center gap-2">
                  <span className="text-slate-500 text-[11px] w-6 font-mono">P{i + 1}</span>
                  <div className="flex gap-1">
                    {LEVELS.map((L) => (
                      <button
                        key={L.id}
                        onClick={() => setLevelAt(i, L.id)}
                        title={`${L.name} · ${L.en}`}
                        className={`w-7 h-5 rounded transition-all ${lv === L.id ? 'ring-2 ring-white/80 scale-105' : 'opacity-60 hover:opacity-100'}`}
                        style={{ backgroundColor: L.color, boxShadow: lv === L.id ? `0 0 10px ${L.color}88` : 'none' }}
                      />
                    ))}
                  </div>
                  <span
                    className="ml-auto text-[10px] px-2 py-0.5 rounded font-bold min-w-[104px] text-center"
                    style={{ backgroundColor: levelInfo(lv).color + '22', color: levelInfo(lv).ink }}
                  >
                    {levelInfo(lv).name}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={launch}
            data-testid="start-contest"
            className="w-full py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-bold text-sm shadow-lg shadow-indigo-900/40 transition-all hover:scale-[1.01] active:scale-[0.99]"
          >
            🚀 开始比赛
          </button>
          <button
            onClick={onCoach}
            data-testid="coach-btn"
            className="w-full mt-2 py-2.5 rounded-xl border border-emerald-500/40 bg-emerald-600/10 hover:bg-emerald-600/20 text-emerald-200 font-bold text-sm transition-all"
          >
            🎓 教练模式：带一队打多年（真实赛历）
          </button>
        </div>

        <div className="rounded-2xl border border-slate-700/60 bg-[#111827]/70 p-5 text-[12px] leading-relaxed text-slate-300 space-y-4">
          <div>
            <div className="font-bold text-white mb-1.5">📜 赛制</div>
            <ul className="space-y-1 text-slate-400">
              <li>· 全程 <b className="text-slate-200">没有评测反馈</b>，提交只是存一版代码</li>
              <li>· 每题 4 个子任务：<b className="text-slate-200">10 / 20 / 30 / 40</b></li>
              <li>· 以 <b className="text-slate-200">最后一次提交</b> 为准，赛后统一出分</li>
              <li>· 交出去的正解可能挂分，也可能反挂分</li>
            </ul>
          </div>
          <div>
            <div className="font-bold text-white mb-1.5">👁 你会看到什么</div>
            <ul className="space-y-1 text-slate-400">
              <li>· 榜上是每位选手的 <b className="text-slate-200">自我估分（≈）</b></li>
              <li>· 估分有固定噪声，所有人同一条中性规则</li>
              <li>· 真实成绩只在比赛结束后揭晓</li>
            </ul>
          </div>
          <div>
            <div className="font-bold text-white mb-1.5">🧠 选手会做什么</div>
            <ul className="space-y-1 text-slate-400">
              <li>· 想不出正解就写暴力保底</li>
              <li>· 对拍、卡常、犹豫要不要交</li>
              <li>· 最后十分钟回去抢救最差的那题</li>
            </ul>
          </div>
          <div className="text-[10px] text-slate-500 pt-2 border-t border-slate-700/60">
            名单与初始 rating 取自校 OJ 排行榜；成长数据只存在本机浏览器，换电脑需要重新累积。
          </div>
        </div>
      </div>
    </div>
  );
}

function Slider({
  label, value, min, max, step, onChange, suffix, testId,
}: {
  label: string; value: number; min: number; max: number; step: number;
  onChange: (n: number) => void; suffix: string; testId?: string;
}) {
  return (
    <div>
      <div className="flex justify-between text-[11px] text-slate-400 mb-1">
        <span>{label}</span>
        <span className="text-indigo-300 font-bold">
          {value} {suffix}
        </span>
      </div>
      <input
        type="range"
        data-testid={testId}
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full h-1.5 rounded-lg appearance-none cursor-pointer bg-slate-700 accent-indigo-500"
      />
    </div>
  );
}

// ===== 赛后出分 =====
function RevealScreen({
  contest,
  onRestart,
  onNewSetup,
}: {
  contest: Contest;
  onRestart: () => void;
  onNewSetup: () => void;
}) {
  const results = useMemo(() => finalize(contest), [contest]);
  const easter = useMemo(() => buildEasterReport(results, contest.seed), [results, contest.seed]);
  const finalCellW = contest.problems.length >= 9 ? 28 : contest.problems.length >= 7 ? 32 : 36;
  const revealOrder = useMemo(
    () => results.slice().sort((a, b) => b.est - a.est || a.name.localeCompare(b.name)),
    [results],
  );
  const [stage, setStage] = useState<'judge' | 'ready' | 'reveal' | 'final'>('judge');
  const [count, setCount] = useState(0);
  const [growth, setGrowth] = useState<GrowthResult | null>(null);
  const settled = useRef(false);

  // 赛后结算成长：只算一次，避免重渲染重复加分
  useEffect(() => {
    if (settled.current) return;
    settled.current = true;
    const res = settleContest(loadGrowth(), results, {
      title: `${contest.problems.length} 题 · ${contest.students.length} 人`,
      fullScore: contest.problems.length * 100,
    });
    setGrowth(res);
  }, [results, contest]);

  useEffect(() => {
    const t = setTimeout(() => setStage('ready'), 2400);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    if (stage !== 'reveal') return;
    if (count >= revealOrder.length) {
      setStage('final');
      try {
        confetti({ particleCount: 140, spread: 90, origin: { y: 0.35 }, colors: ['#6366f1', '#22d3ee', '#fbbf24', '#f472b6'] });
      } catch {
        /* ignore */
      }
      return;
    }
    const t = setTimeout(() => setCount((c) => c + 1), 230);
    return () => clearTimeout(t);
  }, [stage, count, revealOrder.length]);

  if (stage === 'judge') {
    return (
      <Shell>
        <div className="flex flex-col items-center justify-center min-h-[60vh] gap-5">
          <div className="text-4xl animate-pulse">⚙️</div>
          <div className="text-lg font-bold text-white">统一评测中…</div>
          <div className="text-xs text-slate-400">{contest.submissions.length} 份代码排队进入评测机</div>
          <div className="w-56 h-1.5 bg-slate-800 rounded-full overflow-hidden">
            <div className="h-full bg-indigo-500 animate-pulse" style={{ width: '65%' }} />
          </div>
        </div>
      </Shell>
    );
  }

  if (stage === 'ready') {
    return (
      <Shell>
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-5">
            <div className="text-3xl mb-1">📋</div>
            <h1 className="text-xl font-black text-white">评测完成，成绩已封存</h1>
            <p className="text-xs text-slate-400 mt-1">下面是赛后估分榜，和你心里想的一样吗？</p>
          </div>

          <div className="rounded-2xl border border-slate-700/60 bg-[#111827]/80 overflow-hidden mb-5">
            <div className="flex px-4 py-2 text-[10px] text-slate-400 border-b border-slate-700/60">
              <span className="w-8">#</span>
              <span className="flex-1">选手</span>
              <span className="w-20 text-right">估分</span>
            </div>
            <div className="max-h-[48vh] overflow-y-auto">
              {revealOrder.map((r, i) => (
                <div key={r.id} className="flex items-center px-4 py-1.5 border-b border-slate-800/60 text-xs">
                  <span className="w-8 text-slate-500 font-mono">{i + 1}</span>
                  <span className="flex-1 text-slate-200 truncate">
                    {r.name}
                  </span>
                  <span className="w-20 text-right font-mono text-slate-300">≈{r.est}</span>
                </div>
              ))}
            </div>
          </div>

          <button
            onClick={() => setStage('reveal')}
            data-testid="reveal-real"
            className="w-full py-3 rounded-xl bg-gradient-to-r from-rose-600 to-amber-600 hover:from-rose-500 hover:to-amber-500 text-white font-bold shadow-lg shadow-rose-900/30 transition-all hover:scale-[1.01]"
          >
            🔓 公布真实成绩
          </button>
        </div>
      </Shell>
    );
  }

  if (stage === 'reveal') {
    return (
      <Shell>
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-4">
            <div className="text-xs text-slate-400">统一评测结果 · 逐个揭晓</div>
            <div className="text-[11px] text-slate-500 mt-1">估分榜正在被真实分数改写…</div>
          </div>
          <div className="rounded-2xl border border-slate-700/60 bg-[#111827]/80 overflow-hidden">
            <div className="flex px-4 py-2 text-[10px] text-slate-400 border-b border-slate-700/60">
              <span className="w-14">估分名次</span>
              <span className="flex-1">选手</span>
              <span className="w-16 text-right">估分</span>
              <span className="w-20 text-right">真实</span>
              <span className="w-20 text-right">差值</span>
            </div>
            <div className="max-h-[58vh] overflow-y-auto">
              {revealOrder.map((r, i) => {
                const shown = i < count;
                return (
                  <div
                    key={r.id}
                    className={`flex items-center px-4 py-1.5 border-b border-slate-800/60 text-xs transition-all duration-300 ${shown ? '' : 'opacity-40'}`}
                  >
                    <span className="w-14 text-slate-500 font-mono">{r.estRank}</span>
                    <span className="flex-1 text-slate-200 truncate">
                      {r.name}
                    </span>
                    <span className="w-16 text-right font-mono text-slate-400">≈{r.est}</span>
                    <span className="w-20 text-right font-mono font-bold text-white">{shown ? r.real : '…'}</span>
                    <span className={`w-20 text-right font-mono text-[11px] ${shown ? deltaClass(r.delta) : 'text-slate-600'}`}>
                      {shown ? deltaText(r.delta) : ''}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </Shell>
    );
  }

  const stats = summary(results);
  return (
    <Shell>
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-4">
          <div className="text-3xl mb-1">🏆</div>
          <h1 data-testid="final-heading" className="text-2xl font-black text-white">最终成绩</h1>
          <p data-testid="final-meta" className="text-xs text-slate-400 mt-1">
            {contest.problems.length} 题 · {contest.students.length} 人 · 用时 {formatTime(contest.timeElapsed)} / 限时{' '}
            {formatTime(contest.duration)} · 种子 {contest.seed}
          </p>
        </div>

        <div className="grid md:grid-cols-4 gap-2 mb-4">
          <SummaryCard label="平均挂分" value={stats.avgDelta.toFixed(1)} tone={stats.avgDelta < 0 ? 'neg' : 'pos'} sub="真实 − 估分" />
          <SummaryCard
            label="最大挂分"
            value={stats.worst ? `${stats.worst.delta}` : '—'}
            tone="neg"
            sub={stats.worst ? stats.worst.name : '无人挂分'}
            quote={easter.highlights.find((h) => h.label === '最大挂分')?.quote}
          />
          <SummaryCard
            label="最大反挂"
            value={stats.best ? `+${stats.best.delta}` : '—'}
            tone="pos"
            sub={stats.best ? stats.best.name : '无人反挂'}
            quote={easter.highlights.find((h) => h.label === '最大反挂')?.quote}
          />
          <SummaryCard
            label="估分最准"
            value={stats.accurate ? `${stats.accurate.calibration}` : '—'}
            tone="neutral"
            sub={stats.accurate ? stats.accurate.name : ''}
            quote={easter.highlights.find((h) => h.label === '估分最准')?.quote}
          />
        </div>

        <div className="grid lg:grid-cols-3 gap-3">
          <div className="lg:col-span-2 rounded-xl border border-indigo-500/20 bg-[#111827]/80 overflow-hidden">
            <div className="flex px-3 py-2 bg-[#0f1626] text-[10px] text-slate-400 border-b border-slate-700/60">
              <span className="w-8">#</span>
              <span className="w-24">选手</span>
              <span className="px-2" style={{ width: contest.problems.length * (finalCellW + 2) + 16 }}>各题真实得分</span>
              <span className="flex-1" />
              <span className="w-14 text-right">Rating</span>
              <span className="w-11 text-right">估分</span>
              <span className="w-11 text-right">真分</span>
              <span className="w-12 text-right">涨跌</span>
              <span className="w-10 text-right">名次</span>
            </div>
            <div className="max-h-[52vh] overflow-y-auto">
              {results.map((r) => (
                <div key={r.id} className={`flex items-center px-3 py-1.5 border-b border-slate-800/60 text-[11px] ${r.rank <= 3 ? 'bg-amber-400/[0.05]' : ''}`}>
                  <span className="w-8 text-center text-[10px] text-slate-400">
                    {r.rank === 1 ? '🥇' : r.rank === 2 ? '🥈' : r.rank === 3 ? '🥉' : r.rank}
                  </span>
                  <span className="w-24 flex items-center gap-1 truncate">
                    <span className="text-slate-200 truncate">{r.name}</span>
                  </span>
                  <span className="flex gap-0.5 px-2" style={{ width: contest.problems.length * (finalCellW + 2) + 16 }}>
                    {r.perProblem.map((p) => (
                      <span
                        key={p.problemId}
                        className="h-5 rounded flex items-center justify-center font-mono text-[9px] font-bold"
                        style={{
                          width: finalCellW,
                          backgroundColor: p.real >= 100 ? '#22c55e22' : p.real > 0 ? '#e2e8f012' : '#ffffff08',
                          color: p.real >= 100 ? '#4ade80' : p.real > 0 ? '#cbd5e1' : '#3b4a63',
                          border: p.real >= 100 ? '1px solid #22c55e44' : '1px solid rgba(148,163,184,0.12)',
                        }}
                        title={`P${p.problemId + 1} 估 ${p.est} / 实 ${p.real}${p.reason ? ' · ' + p.reason : ''}`}
                      >
                        {p.real >= 100 ? '✓' : p.real}
                      </span>
                    ))}
                  </span>
                  <span className="flex-1" />
                  <span className="w-14 text-right font-mono text-[10px] text-slate-400" title="赛后 Rating（括号内为涨跌）">
                    {growth ? growth.after[r.name] : ''}
                    {growth && growth.deltas[r.name] ? (
                      <span className={growth.deltas[r.name] > 0 ? 'text-emerald-400/80' : 'text-rose-400/80'}>
                        {' '}
                        {growth.deltas[r.name] > 0 ? '+' : ''}
                        {growth.deltas[r.name]}
                      </span>
                    ) : null}
                  </span>
                  <span className="w-11 text-right font-mono text-slate-400">≈{r.est}</span>
                  <span className="w-11 text-right font-mono font-bold text-white">{r.real}</span>
                  <span className={`w-12 text-right font-mono text-[10px] ${deltaClass(r.delta)}`}>{deltaText(r.delta)}</span>
                  <span className="w-10 text-right text-[10px]">
                    {r.rankDelta > 0 ? (
                      <span className="text-emerald-400">↑{r.rankDelta}</span>
                    ) : r.rankDelta < 0 ? (
                      <span className="text-rose-400">↓{-r.rankDelta}</span>
                    ) : (
                      <span className="text-slate-600">—</span>
                    )}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <div className="rounded-xl border border-slate-700/60 bg-[#111827]/80 p-3">
              <h3 className="text-[11px] font-bold text-slate-300 mb-2">📉 挂分最惨</h3>
              <div className="space-y-1">
                {stats.hangers.slice(0, 3).map((r) => (
                  <div key={r.id} className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-300 truncate">{r.name}</span>
                    <span className="font-mono text-rose-400">{r.delta}</span>
                  </div>
                ))}
                {stats.hangers.length === 0 && <div className="text-[10px] text-slate-600">本场无人挂分</div>}
              </div>
            </div>

            <div className="rounded-xl border border-slate-700/60 bg-[#111827]/80 p-3">
              <h3 className="text-[11px] font-bold text-slate-300 mb-2">📈 反挂榜</h3>
              <div className="space-y-1">
                {stats.climbers.slice(0, 3).map((r) => (
                  <div key={r.id} className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-300 truncate">{r.name}</span>
                    <span className="font-mono text-emerald-400">+{r.delta}</span>
                  </div>
                ))}
                {stats.climbers.length === 0 && <div className="text-[10px] text-slate-600">本场无人反挂</div>}
              </div>
            </div>

            <div className="rounded-xl border border-slate-700/60 bg-[#111827]/80 p-3">
              <h3 className="text-[11px] font-bold text-slate-300 mb-2">🎯 估分校准榜</h3>
              <div className="space-y-1">
                {stats.calibrated.slice(0, 3).map((r) => (
                  <div key={r.id} className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-300 truncate">{r.name}</span>
                    <span className="font-mono text-indigo-300">{r.calibration}</span>
                  </div>
                ))}
              </div>
              <div className="text-[9px] text-slate-600 mt-1">稳定型选手通常排在这里</div>
            </div>

            <div className="rounded-xl border border-slate-700/60 bg-[#111827]/80 p-3">
              <h3 className="text-[11px] font-bold text-slate-300 mb-2">🏅 成长榜</h3>
              {growth ? (
                <>
                  <div className="space-y-1">
                    {ratingBoard(growth.data)
                      .slice(0, 5)
                      .map((p, i) => {
                        const d = growth.deltas[p.name] ?? 0;
                        return (
                          <div key={p.name} className="flex items-center gap-1 text-[11px]">
                            <span className="w-4 text-slate-600 font-mono text-[10px]">{i + 1}</span>
                            <span className="text-slate-300 truncate flex-1">{p.name}</span>
                            <span className="font-mono text-slate-200">{p.rating}</span>
                            <span className={`font-mono text-[10px] w-9 text-right ${d > 0 ? 'text-emerald-400' : d < 0 ? 'text-rose-400' : 'text-slate-600'}`}>
                              {d > 0 ? `+${d}` : d === 0 ? '±0' : d}
                            </span>
                          </div>
                        );
                      })}
                  </div>
                  <div className="text-[9px] text-slate-600 mt-1">按赛后 rating 排序，右侧为本场涨跌</div>
                </>
              ) : (
                <div className="text-[10px] text-slate-600">结算中…</div>
              )}
            </div>
          </div>
        </div>

        <div className="mt-3 rounded-xl border border-amber-500/20 bg-amber-500/[0.04] p-3">
          <div className="flex items-baseline justify-between mb-1">
            <h3 className="text-[11px] font-bold text-amber-200/90">🎭 今日语录</h3>
            <span className="text-[9px] text-amber-200/40">每场一条 · 纯彩蛋，不影响成绩</span>
          </div>
          <p className="text-[11px] leading-relaxed text-amber-100/80 whitespace-pre-line">
            {easter.banner.speaker ? <span className="text-amber-300/70">{easter.banner.speaker}：</span> : null}
            {easter.banner.text}
          </p>
        </div>

        <div className="mt-3 rounded-xl border border-slate-700/60 bg-[#111827]/80 p-3">
          <h3 className="text-[11px] font-bold text-slate-300 mb-2">📝 战报</h3>
          <div className="grid md:grid-cols-2 gap-x-6 gap-y-1 max-h-44 overflow-y-auto">
            {results.map((r) => {
              const d = growth?.deltas[r.name] ?? 0;
              const after = growth?.after[r.name];
              return (
                <div key={r.id} className="text-[10.5px] text-slate-400 flex items-center gap-1.5">
                  <span className="text-slate-300 shrink-0 w-16 truncate">{r.name}</span>
                  {(() => {
                    const od = OIERDB_BY_NAME.get(r.name);
                    if (od) {
                      const tone =
                        od.national <= 1000
                          ? 'text-fuchsia-300 bg-fuchsia-500/15'
                          : od.national <= 4000
                            ? 'text-sky-300 bg-sky-500/15'
                            : 'text-slate-400 bg-slate-600/25';
                      return (
                        <span
                          className={`shrink-0 font-mono text-[9px] px-1 rounded ${tone}`}
                          title={`OIerDb 全国第 ${od.national} 名 · 评分 ${Math.round(od.score)} · CCF 评级 ${od.ccf} · ${od.grade}`}
                        >
                          #{od.national}
                        </span>
                      );
                    }
                    const csp = CSP_BY_NAME.get(r.name);
                    if (!csp) return null;
                    return (
                      <span
                        className={`shrink-0 font-mono text-[9px] px-1 rounded ${CSP_COLOR[csp.award as 1 | 2 | 3]}`}
                        title={`CSP-${csp.group === 's' ? 'S' : 'J'} ${csp.year} ${csp.award}等奖 ${csp.score} 分${csp.rank ? ` · 全国第 ${csp.rank} / ${csp.total}` : ''}`}
                      >
                        {CSP_LABEL(csp)}
                      </span>
                    );
                  })()}
                  <span className="truncate flex-1">{reportOf(r)}</span>
                  <span
                    className={`shrink-0 font-mono text-[10px] px-1 rounded ${
                      d > 0 ? 'text-emerald-300 bg-emerald-500/10' : d < 0 ? 'text-rose-300 bg-rose-500/10' : 'text-slate-500 bg-slate-700/30'
                    }`}
                    title={after ? `赛后 rating ${after}` : undefined}
                  >
                    {after ? `${after}` : '—'}
                    <span className="ml-1">{d > 0 ? `+${d}` : d === 0 ? '±0' : d}</span>
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        <div className="flex gap-2 mt-4">
          <button
            onClick={onRestart}
            className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-bold text-sm"
          >
            🔄 同配置再来一局
          </button>
          <button
            onClick={onNewSetup}
            className="flex-1 py-2.5 rounded-xl bg-slate-800 border border-slate-600 hover:border-slate-400 text-slate-200 font-bold text-sm"
          >
            ⚙️ 换个配置
          </button>
        </div>
      </div>
    </Shell>
  );
}

function SummaryCard({
  label,
  value,
  sub,
  tone,
  quote,
}: {
  label: string;
  value: string;
  sub: string;
  tone: 'pos' | 'neg' | 'neutral';
  quote?: { text: string; speaker: string | null };
}) {
  const color = tone === 'pos' ? 'text-emerald-400' : tone === 'neg' ? 'text-rose-400' : 'text-indigo-300';
  return (
    <div className="rounded-xl border border-slate-700/60 bg-[#111827]/80 px-3 py-2">
      <div className="text-[10px] text-slate-500">{label}</div>
      <div className={`text-lg font-black font-mono ${color}`}>{value}</div>
      <div className="text-[9px] text-slate-500 truncate">{sub}</div>
      {quote ? (
        <div className="mt-1 border-t border-white/5 pt-1 text-[9px] leading-snug text-amber-200/55 whitespace-pre-line">
          {quote.speaker ? <span className="text-amber-300/60">{quote.speaker}：</span> : null}
          {quote.text}
        </div>
      ) : null}
    </div>
  );
}

function deltaText(d: number): string {
  if (d === 0) return '±0';
  return d > 0 ? `+${d}` : `${d}`;
}

function deltaClass(d: number): string {
  if (d < -9) return 'text-rose-400';
  if (d > 9) return 'text-emerald-400';
  return 'text-slate-500';
}

function summary(results: StudentResult[]) {
  const avgDelta = results.reduce((a, r) => a + r.delta, 0) / Math.max(1, results.length);
  const sorted = results.slice().sort((a, b) => a.delta - b.delta);
  const hangers = sorted.filter((r) => r.delta < -9);
  const climbers = sorted.filter((r) => r.delta > 9).reverse();
  const calibrated = results.slice().sort((a, b) => b.calibration - a.calibration);
  return {
    avgDelta,
    worst: hangers[0],
    best: climbers[0],
    accurate: calibrated[0],
    hangers,
    climbers,
    calibrated,
  };
}

function reportOf(r: StudentResult): string {
  const attempts = r.perProblem.reduce((a, p) => a + p.attempts, 0);
  if (attempts === 0) return '一道都没交，交了白卷';
  const parts: string[] = [];
  if (r.delta < -9) parts.push(`估 ${r.est} → 实 ${r.real}，挂 ${-r.delta}`);
  else if (r.delta > 9) parts.push(`估 ${r.est} → 实 ${r.real}，反挂 ${r.delta}`);
  else parts.push(`估 ${r.est} → 实 ${r.real}，估得挺准`);
  const worst = r.perProblem.slice().sort((a, b) => a.delta - b.delta)[0];
  if (worst && worst.delta < -9 && worst.reason) parts.push(`P${worst.problemId + 1} ${worst.reason}`);
  return parts.join('，') + '。';
}
