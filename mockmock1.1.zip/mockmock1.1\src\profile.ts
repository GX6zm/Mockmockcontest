// 由 scripts/profile.mjs 从 data/属性对照表.csv 生成，请勿手改
import type { Skills, Topic } from './types.ts';

export interface ProfileOverride {
  grade?: 1 | 2 | 3 | 4 | 5 | 6;
  talent?: number;
  topics?: Partial<Record<Topic, number>>;
  meta?: Partial<Pick<Skills, 'coding' | 'reading' | 'debug'>>;
}

/** 手填的属性覆盖；没填的人沿用引擎生成值 */
export const PROFILE_BY_NAME: Record<string, ProfileOverride> = {
  "特别之处": { grade: 3, talent: 1.315, topics: { math: 0.97, dp: 0.92, graph: 0.9, greedy: 0.92, ds: 1, impl: 1, string: 1, geometry: 1 }, meta: { coding: 1, reading: 0.88, debug: 1 } },
  "王思琦": { grade: 4, talent: 1.298, topics: { math: 0.95, dp: 0.91, graph: 0.83, greedy: 1, ds: 0.93, impl: 1, string: 1, geometry: 0.9 }, meta: { coding: 1, reading: 0.8, debug: 1 } },
  "丁一宸": { grade: 5, talent: 1.297, topics: { math: 0.98, dp: 0.95, graph: 1, greedy: 0.92, ds: 0.91, impl: 1, string: 0.88, geometry: 0.92 }, meta: { coding: 1, reading: 0.81, debug: 0.94 } },
  "傻白虎": { grade: 5, talent: 1.295, topics: { math: 0.95, dp: 1, graph: 0.86, greedy: 1, ds: 0.99, impl: 0.9, string: 0.88, geometry: 1 }, meta: { coding: 0.96, reading: 0.93, debug: 0.88 } },
  "noitamotuA_珂": { grade: 4, talent: 1.297, topics: { math: 0.92, dp: 0.83, graph: 0.92, greedy: 1, ds: 1, impl: 0.91, string: 1, geometry: 0.95 }, meta: { coding: 0.95, reading: 0.76, debug: 0.92 } },
  "肖子卓": { grade: 3, talent: 1.297, topics: { math: 1, dp: 1, graph: 0.87, greedy: 0.91, ds: 0.98, impl: 0.9, string: 1, geometry: 0.91 }, meta: { coding: 0.86, reading: 1, debug: 0.94 } },
  "法克火星人": { grade: 5, talent: 1.29, topics: { math: 0.72, dp: 1, graph: 1, greedy: 0.89, ds: 0.9, impl: 0.95, string: 1, geometry: 0.85 }, meta: { coding: 1, reading: 0.92, debug: 0.81 } },
  "周炜恒": { grade: 4, talent: 1.245, topics: { math: 1, dp: 0.88, graph: 0.78, greedy: 1, ds: 0.76, impl: 0.87, string: 0.91, geometry: 0.71 }, meta: { coding: 1, reading: 0.96, debug: 0.89 } },
  "陈和骏": { grade: 2, talent: 1.276, topics: { math: 0.87, dp: 0.9, graph: 0.85, greedy: 0.9, ds: 0.9, impl: 0.89, string: 0.8, geometry: 0.74 }, meta: { coding: 0.9, reading: 0.8, debug: 0.8 } },
  "周逸然": { grade: 4, talent: 1.25, topics: { math: 0.82, dp: 1, graph: 0.62, greedy: 1, ds: 0.7, impl: 1, string: 0.76, geometry: 0.84 }, meta: { coding: 0.96, reading: 0.65, debug: 0.74 } },
  "为什么不让我叫Ciall": { grade: 3, talent: 1.252, topics: { math: 0.82, dp: 0.94, graph: 0.77, greedy: 1, ds: 0.87, impl: 0.89, string: 0.8, geometry: 0.57 }, meta: { coding: 0.86, reading: 0.81, debug: 0.88 } },
  "王鼎翼": { grade: 4, talent: 1.198, topics: { math: 0.95, dp: 0.91, graph: 0.69, greedy: 0.77, ds: 0.79, impl: 1, string: 0.59, geometry: 0.77 }, meta: { coding: 0.98, reading: 0.78, debug: 0.9 } },
  "Zctf一零八八": { grade: 4, talent: 1.25, topics: { math: 0.53, dp: 0.96, graph: 0.87, greedy: 0.87, ds: 0.6, impl: 0.98, string: 0.89, geometry: 0.78 }, meta: { coding: 0.91, reading: 0.7, debug: 0.92 } },
  "陈钰婉": { grade: 6, talent: 1.133, topics: { math: 0.54, dp: 0.79, graph: 0.93, greedy: 0.87, ds: 0.72, impl: 0.99, string: 0.75, geometry: 0.94 }, meta: { coding: 0.84, reading: 0.61, debug: 0.97 } },
  "张培楠": { grade: 4, talent: 1.233, topics: { math: 0.82, dp: 1, graph: 0.91, greedy: 0.9, ds: 0.81, impl: 0.54, string: 0.83, geometry: 0.7 }, meta: { coding: 0.9, reading: 0.83, debug: 0.83 } },
  "赵绎哲": { grade: 4, talent: 1.201, topics: { math: 0.9, dp: 0.96, graph: 0.89, greedy: 0.83, ds: 0.85, impl: 0.8, string: 0.7, geometry: 0.97 }, meta: { coding: 0.68, reading: 0.84, debug: 0.66 } },
  "陈逸阳": { grade: 4, talent: 1.209, topics: { math: 0.78, dp: 0.81, graph: 0.84, greedy: 0.82, ds: 0.79, impl: 0.83, string: 0.87, geometry: 0.86 }, meta: { coding: 0.7, reading: 0.87, debug: 1 } },
  "周檬轩": { grade: 3, talent: 1.231, topics: { math: 0.9, dp: 0.8, graph: 0.89, greedy: 0.9, ds: 0.96, impl: 0.87, string: 0.75, geometry: 0.65 }, meta: { coding: 0.75, reading: 0.79, debug: 0.74 } },
  "都大人的题构结据数做年常": { grade: 5, talent: 1.225, topics: { math: 0.92, dp: 0.63, graph: 0.87, greedy: 0.85, ds: 0.7, impl: 0.85, string: 0.93, geometry: 0.83 }, meta: { coding: 0.75, reading: 0.66, debug: 0.87 } },
  "苗淇": { grade: 3, talent: 1.198, topics: { math: 0.66, dp: 0.83, graph: 0.84, greedy: 0.9, ds: 0.75, impl: 0.74, string: 0.73, geometry: 0.9 }, meta: { coding: 0.91, reading: 0.91, debug: 0.74 } },
  "zch_stl大变": { grade: 4, talent: 1.198, topics: { math: 0.74, dp: 0.66, graph: 0.95, greedy: 0.92, ds: 0.67, impl: 0.91, string: 0.61, geometry: 0.68 }, meta: { coding: 0.95, reading: 0.74, debug: 0.81 } },
  "李金潼": { grade: 3, talent: 1.2, topics: { math: 0.81, dp: 0.81, graph: 0.74, greedy: 0.6, ds: 0.78, impl: 0.79, string: 0.85, geometry: 0.74 }, meta: { coding: 1, reading: 0.62, debug: 0.71 } },
  "罗崇艺": { grade: 4, talent: 1.197, topics: { math: 0.78, dp: 0.78, graph: 0.56, greedy: 0.76, ds: 0.77, impl: 0.76, string: 0.88, geometry: 0.73 }, meta: { coding: 0.98, reading: 0.56, debug: 0.66 } },
  "不见了，失败了。": { grade: 5, talent: 1.19, topics: { math: 0.69, dp: 0.69, graph: 0.55, greedy: 0.71, ds: 0.69, impl: 0.92, string: 0.78, geometry: 0.9 }, meta: { coding: 0.81, reading: 0.84, debug: 1 } },
  "陈怡嘉": { grade: 4, talent: 1.19, topics: { math: 0.62, dp: 0.78, graph: 0.8, greedy: 0.55, ds: 0.78, impl: 0.89, string: 0.79, geometry: 0.96 }, meta: { coding: 0.67, reading: 0.76, debug: 0.91 } },
  "蔡青辰": { grade: 3, talent: 1.205, topics: { math: 0.86, dp: 0.43, graph: 0.75, greedy: 0.83, ds: 0.5, impl: 0.84, string: 0.72, geometry: 0.87 }, meta: { coding: 0.86, reading: 0.62, debug: 0.69 } },
  "李君泽": { grade: 3, talent: 1.199, topics: { math: 0.84, dp: 0.71, graph: 0.7, greedy: 1, ds: 0.6, impl: 0.92, string: 0.66, geometry: 0.78 }, meta: { coding: 0.55, reading: 0.8, debug: 0.6 } },
  "孙可轩": { grade: 4, talent: 1.201, topics: { math: 0.78, dp: 0.8, graph: 0.8, greedy: 0.74, ds: 0.64, impl: 0.9, string: 0.58, geometry: 0.7 }, meta: { coding: 0.74, reading: 0.86, debug: 0.64 } },
  "张博一": { grade: 1, talent: 1.225, topics: { math: 0.8, dp: 0.78, graph: 0.78, greedy: 0.7, ds: 0.74, impl: 0.8, string: 0.64, geometry: 0.41 }, meta: { coding: 0.85, reading: 0.7, debug: 0.56 } },
  "杨昕然": { grade: 2, talent: 1.194, topics: { math: 0.74, dp: 0.65, graph: 0.5, greedy: 0.73, ds: 0.55, impl: 0.8, string: 0.84, geometry: 0.72 }, meta: { coding: 0.75, reading: 0.71, debug: 0.8 } },
  "王岚清": { grade: 5, talent: 1.15, topics: { math: 0.75, dp: 0.77, graph: 0.82, greedy: 0.87, ds: 0.65, impl: 0.75, string: 0.52, geometry: 0.64 }, meta: { coding: 0.57, reading: 0.85, debug: 0.72 } },
  "吴禹泽": { grade: 5, talent: 1.19, topics: { math: 0.8, dp: 0.84, graph: 0.62, greedy: 0.67, ds: 0.72, impl: 0.68, string: 0.54, geometry: 0.65 }, meta: { coding: 0.8, reading: 0.8, debug: 0.59 } },
  "张正轩": { grade: 2, talent: 1.18, topics: { math: 0.75, dp: 0.66, graph: 0.71, greedy: 0.72, ds: 0.64, impl: 0.76, string: 0.55, geometry: 0.81 }, meta: { coding: 0.65, reading: 0.82, debug: 0.64 } },
  "张爱熙": { grade: 2, talent: 1.225, topics: { math: 0.65, dp: 0.85, graph: 0.7, greedy: 0.73, ds: 0.48, impl: 0.55, string: 0.77, geometry: 0.66 }, meta: { coding: 0.64, reading: 0.79, debug: 0.83 } },
  "刘益铭": { grade: 2, talent: 1.19, topics: { math: 0.73, dp: 0.61, graph: 0.73, greedy: 0.92, ds: 0.69, impl: 0.43, string: 0.56, geometry: 0.61 }, meta: { coding: 0.81, reading: 0.53, debug: 0.67 } },
  "刘子牧": { grade: 3, talent: 1.19, topics: { math: 0.66, dp: 0.65, graph: 0.83, greedy: 0.85, ds: 0.63, impl: 0.73, string: 0.87, geometry: 0.15 }, meta: { coding: 0.8, reading: 0.66, debug: 0.48 } },
  "孙宇安": { grade: 4, talent: 1.113, topics: { math: 0.95, dp: 1, graph: 0.64, greedy: 0.41, ds: 0.67, impl: 0.44, string: 0.47, geometry: 0.71 }, meta: { coding: 0.5, reading: 0.74, debug: 0.67 } },
  "赵泽瑄": { grade: 3, talent: 1.151, topics: { math: 0.81, dp: 0.66, graph: 0.59, greedy: 0.4, ds: 0.8, impl: 0.41, string: 0.71, geometry: 0.58 }, meta: { coding: 0.7, reading: 0.53, debug: 0.7 } },
  "翟煜泽": { grade: 5, talent: 1, topics: { math: 0.58, dp: 0.64, graph: 0.65, greedy: 0.59, ds: 0.5, impl: 0.75, string: 0.53, geometry: 0.66 }, meta: { coding: 0.68, reading: 0.79, debug: 0.75 } },
  "刘尚泽坤": { grade: 5, talent: 1.16, topics: { math: 0.88, dp: 0.49, graph: 0.89, greedy: 0.48, ds: 0.91, impl: 0.56, string: 0.47, geometry: 0.44 }, meta: { coding: 0.62, reading: 0.61, debug: 0.53 } },
  "MLE自动机": { grade: 1, talent: 1.085, topics: { math: 0.72, dp: 0.72, graph: 0.8, greedy: 0.79, ds: 0.5, impl: 0.82, string: 0.67, geometry: 0 }, meta: { coding: 0.68, reading: 0.5, debug: 0.48 } },
  "霍秋实": { grade: 2, talent: 1.201, topics: { math: 0.49, dp: 0.48, graph: 0.53, greedy: 0.43, ds: 0.44, impl: 0.59, string: 0.49, geometry: 0.66 }, meta: { coding: 0.73, reading: 0.46, debug: 0.48 } },
  "石丰源": { grade: 5, talent: 1.15, topics: { math: 0.58, dp: 0.37, graph: 0.51, greedy: 0.54, ds: 0.43, impl: 0.49, string: 0.6, geometry: 0.56 }, meta: { coding: 0.4, reading: 0.3, debug: 0.73 } },
  "职业失踪人员": { grade: 5, talent: 1.2, topics: { math: 0.8, dp: 0.6, graph: 0.6, greedy: 0.3, ds: 0.27, impl: 0.6, string: 0.6, geometry: 0.15 }, meta: { coding: 0.6, reading: 0.8, debug: 0.54 } },
  "陈霖锐": { grade: 1, talent: 1.028, topics: { math: 0.38, dp: 0.32, graph: 0.49, greedy: 0.47, ds: 0.39, impl: 0.89, string: 0.4, geometry: 0.59 }, meta: { coding: 0.59, reading: 0.5, debug: 0.4 } },
  "樊一靓": { grade: 1, talent: 1.28, topics: { math: 0.2, dp: 0.5, graph: 0.6, greedy: 0.8, ds: 0.67, impl: 0.6, string: 0.2, geometry: 0.05 }, meta: { coding: 0.5, reading: 0.8, debug: 0.8 } },
  "代羽辰": { grade: 3, talent: 1.198, topics: { math: 0.36, dp: 0.71, graph: 0.54, greedy: 0.47, ds: 0.56, impl: 0.27, string: 0.44, geometry: 0.31 }, meta: { coding: 0.63, reading: 0.57, debug: 0.16 } },
  "贺思杰": { grade: 1, talent: 1.05, topics: { math: 0.21, dp: 0.37, graph: 0.46, greedy: 0.56, ds: 0.5, impl: 0.53, string: 0.41, geometry: 0.62 }, meta: { coding: 0.46, reading: 0.4, debug: 0.24 } },
  "陶锐轩": { grade: 4, talent: 1.065, topics: { math: 0.27, dp: 0.41, graph: 0.33, greedy: 0.51, ds: 0.56, impl: 0.44, string: 0.36, geometry: 0.3 }, meta: { coding: 0.62, reading: 0.61, debug: 0.4 } },
  "韩亦书": { grade: 1, talent: 0.8, topics: { math: 0.62, dp: 0.44, graph: 0.25, greedy: 0.47, ds: 0.26, impl: 0.36, string: 0.58, geometry: 0.36 }, meta: { coding: 0.08, reading: 0.27, debug: 0.28 } },
  "王穆迪": { grade: 1, talent: 1.05, topics: { math: 0.69, dp: 0.33, graph: 0.19, greedy: 0.18, ds: 0.41, impl: 0.23, string: 0.43, geometry: 0.37 }, meta: { coding: 0.07, reading: 0.2, debug: 0.43 } },
  "李嘉柠": { grade: 2, talent: 1, topics: { math: 0.5, dp: 0.6, graph: 0.35, greedy: 0.16, ds: 0.18, impl: 0.4, string: 0.05, geometry: 0.26 }, meta: { coding: 0.4, reading: 0.11, debug: 0.25 } },
  "刘郑邦": { grade: 1, talent: 1.15, topics: { math: 0.49, dp: 0.43, graph: 0.43, greedy: 0.27, ds: 0.12, impl: 0.17, string: 0.24, geometry: 0.3 }, meta: { coding: 0.07, reading: 0.37, debug: 0.31 } },
  "张家康": { grade: 2, talent: 1, topics: { math: 0.25, dp: 0.27, graph: 0.14, greedy: 0.26, ds: 0.24, impl: 0.38, string: 0.18, geometry: 0.19 }, meta: { coding: 0.36, reading: 0.28, debug: 0.16 } },
};

export const PROFILE_FILLED = 54;
