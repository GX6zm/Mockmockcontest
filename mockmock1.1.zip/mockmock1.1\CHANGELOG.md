# 变更日志（CHANGELOG）

记录每一次大改动的「改了什么 / 为什么 / 怎么验证的」。细颗粒的实现笔记在 `PROGRESS.md`，
每次自动校验的原始数字在 `logs/verify.log`。

---

## 2026-10-20 · 训练提速 + 省队 17 + CTT/CTS/IOI + NOI 笔试

- 按用户 m01684 要求：训练/模拟赛成长提高（`TRAIN_BASE` 0.10→0.18、模拟赛 scale 0.007→0.016）；省队扩到 A5+B12=17、单校上限 5；NOI 后新增 W34 CTT、W37 CTS、W40 IOI。
- 按用户 m02155 补上 **NOI 100 分笔试**：NOI 满分 705（本作 700），笔试按阅读/代码/年级经验独立出分，`StudentResult.written` 记录并计入真分/估分/排名；结算页显示「满分 700」「总分含 100 分笔试」。
- 校准：省选 `FIELDS.prov` 锚点 62/55/40/5，NOI 300/270/230/175，CTT/CTS/IOI 难度区间 65–102；探针跑通 NOI 金 #39 → CTT 前 30 → CTS 前 4 → IOI 铜。
- 验证：`tsc --noEmit` 0；`vite build` + `inline.mjs` → `OI模拟赛.html` **399,804 B**；`e2e-check` 20.5s / 16 徽章；`coach-smoke` 一届 40 周通过（S · 传奇教练）。`career-check` 仍是六属性删除前基线。

## 2026-10-20 · 六属性彻底删除 + 战报彩蛋

- 按用户要求删除 **性格 / 实力 / 自我认知 / 抗压 / 耐心 / 冒险**，不是只删表列：`Skills` 只剩 8 知识点 + 代码/阅读/调试，`Student/SeasonStudent/StudentResult` 去掉 archetype，`ARCHETYPES/ARCH_TUNE/topicAffinity/ARCHETYPE_BY_NAME` 全部移除；`data/天赋对照表.txt` 改成 姓名/天赋/备注 三列。
- 依赖行为改成固定中性规则，不保留隐藏属性：估分噪声 `gauss*3.0`、交题 `cautious=.55` / `wantMore=.55`、初赛 `0.53*阅读 + 0.37*代码 + 0.10*年级经验`、事件只改疲劳/专题/成长。
- 用户最后在 `data/属性对照表-综合预览.xlsx` 改值，已按**姓名**导回 `data/属性对照表.csv`（15 列、54 行；备份 `.bak-sync`）；`profile.mjs --verify` **54 人 / 756 字段**，Excel UsedRange 55×15；CSV↔xlsx 按姓名逐格比对 **0 处不一致**。
- 新增 `src/quotes.ts`（201 条“唐话”，原文、说话人、标签）和 `src/easter.ts`（每场 1 条今日语录 + 最大挂分/最大反挂/估分最准 3 个高亮位，按 contest seed 确定、不重复、不改分），接入观战赛后页。
- 同步更新 `docs/属性与比赛影响.md`、`docs/选手属性全表.md`、`README.md`、`PROGRESS.md`。
- 验证：`tsc --noEmit` 0；`vite build` + `inline.mjs` → `OI模拟赛.html` **395,033 B**；`e2e-check` 20.3s / 16 徽章；`coach-smoke` 通过。`event-check` / `career-check` 删除六属性后待重跑。

## 2026-10-19 · M6.5 全属性编辑器

- 新增 `data/属性对照表.csv` + `.txt`（54 人 × 21 列）、`scripts/profile.mjs`、`src/profile.ts`；
  `createSeason` 里按姓名套用覆盖值（年级/性格/天赋/实力/8 知识点/7 元能力）。
- 加 `--show` 终端对齐打印（Tab + 中文字宽问题不再错位）。
- 校验：`tsc` 0；把当前值原样回填后跑 `coach-smoke --full`，结果与回填前一致；单文件 370 KB。

## 2026-10-19 · M6 按真实分数校准 + 删 J 组 + 选手详情

- 新增每题「得分率曲线」`ContestConfig.scoreCurve`，把引擎原始分映射到真实赛事得分区间；
  八场正赛各一条曲线。
- 删掉 CSP-J 赛道（用户：「J组没必要」）：初赛全校一张 S 卷、直接出分；复赛单组；
  生涯评分去掉 J 省一。
- 选手详情面板 `src/StudentDetail.tsx`：全部属性、性格天赋、本学期每场成绩。
- 修 bug：`runStage` 一直漏传 `ranges`（NOIP 起的题目难度区间从 M4 起没生效）。
- 校准：`career-check` 91 S / 36 B / 20 C（强-弱差 71）；阈值 S85/A55/B34/C19/D0。
- 校验：`tsc` 0、`e2e-check` 20s、`trace-check` 25 场 0 不一致；单文件 348 KB。

## 2026-10-19 · M5 正赛改成实时观战 + 虚构外校选手

- 教练模式的正赛/模拟赛复用观战的 `ContestScreen`：实时榜单、暂停、1x–4x、+10 分钟、
  到收卷、估分榜、公布真实成绩；默认观看，可「跳过观看」。
- `runWeeklyContest(s, trace)` 记录每场 `ContestConfig`，前端用同一份 cfg 重建 → 同 seed 逐分一致
  （`scripts/trace-check.mjs` 校验）。
- 新增 `src/field.ts`：用「官方名额 + 分数线」反推整条分数分布，虚构外校选手，
  给出省内排名/分位/奖项；`NATIONAL_QUOTAS` 供 NOI/APIO/WC 发牌。
- 队伍人数不设上限（`TEAM_MAX` 移除），用 `sizePenalty` 做注意力稀释。
- 官方 2025 数据全量替换（CSP-S 陕西 157 人/100 线、J 162/230、NOIP 128/95/86、
  NOI 705 分 金 50 银 152 铜 85、APIO 193/130/80 …）。
- 校验：`career-check` 78 A / 47 B / 34 C；`e2e-check` 20.1s；`trace-check` 25 场 0 不一致；单文件 352 KB。

## 2026-10-19 · M4 初赛笔试 / 报名制 / 比赛成长 / 省线判奖

- 初赛改成「100 分笔试直接出分」，不再套比赛引擎；`prelimPaperScore` 按能力 + 噪声 + 疲劳算分。
- 报名：只有 CSP 初赛可选报名（勾选名单），其余比赛晋级即自动报名。
- 比赛成长：`growFromContest`，难度与水平越匹配涨得越多，参赛同时加疲劳；比赛周仍可训练。
- 模拟赛可调难度档/题数/时长（`MOCK_PRESETS`）。
- 奖项改按「官方省线 + 省内名额」判（`bandOfLines`），修掉「省一按百分比发」的失真。
- 省选总分改为标准分：`NOIP 标准分 × 0.3 + 省选标准分 × 0.7`（标准分 = 本人 ÷ 全省最高 × 100）。
- 校验：`career-check` 三年 97 S / 47 B / 34 C；`coach-smoke --full` B 55；单文件 348 KB。

## 2026-10-19 · M3 三年生涯 + 真实赛历

- 一学年 32 周、3 学年；7 场正式比赛按 2026–27 真实日程：CSP 初赛 9/19 → 复赛 10/31 →
  NOIP 11/29 → WC 次年 2 月 → 省选 3 月（两试）→ APIO 5 月 → NOI 7 月（两试）。
- 年级系统（初一~高三）、每年升学/毕业/补新生（6 初一 + 4 高一）、生涯结算与等级。
- 全国排名：官方分数线锚点插值 → 全国分位 → 官方奖档。
- 校验：`career-check` 首次跑通 3 年；单文件 340 KB。

## 2026-10-19 · M2 教练模式 + 随机事件

- 教练模式：选队（6–8 人）、每周排训练专题/强度、处理随机事件（7 模板、约 62%/周）、
  跑比赛、赛季结算。
- 观战模式 e2e 从「路径断言」改为「`data-testid` 契约」，改文案不再静默失效。
- 校验：`coach-smoke.mjs`、`event-check.mjs`、`event-choice-check.mjs`。

## 2026-10-17 · M1 单文件游戏

- Vite + React + TS 起步；`scripts/inline.mjs` 把 `dist/` 内联成 300 KB 单文件 `OI模拟赛.html`，
  双击即玩（用户核心诉求：不装环境、能直接发同学）。



