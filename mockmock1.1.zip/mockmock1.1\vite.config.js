import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    host: "0.0.0.0",
    port: 3000,
    strictPort: true,
    hmr: {
      port: 3000,
    },
    watch: {
      // 编辑器/工具写文件时产生的临时目录会让 Windows 的文件监听报 EBUSY
      ignored: ["**/*.tmpdir", "**/*.tmpdir/**", "**/.*.tmp", "**/.git/**"],
    },
  },
});
