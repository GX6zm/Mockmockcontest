// 验证：教练模式「瞬时结算」与「回放观看」用同一个引擎，结果逐分一致。
// runWeeklyContest(s, trace) 记下每场比赛的 cfg；前端用 createContest(cfg) 重建后
// 自己 tick 完整时长，finalize 出来的分数必须和瞬时结算的 recap.rows 完全相等。
import {
  createSeason, setTeam, planWeek, runWeeklyContest, advanceWeek, stageOfWeek, YEAR_WEEKS,
} from '../src/season.ts';
import { createContest, tick, finalize, TOPIC_LIST } from '../src/game.ts';
import { logRun } from './log.mjs';

const seed = Number(process.argv[2] ?? 20261019);
let s = createSeason(seed, 1);
s = setTeam(s, s.students.slice(0, 8).map((st) => st.name));

let checked = 0;
let mismatches = 0;

for (let week = 1; week <= YEAR_WEEKS; week++) {
  if (s.phase === 'team') s = setTeam(s, s.students.slice(0, 8).map((st) => st.name));
  // 2026-10-23：这里之前用的是 planWeek 的旧签名（4 个位置参数），现在 planWeek 只收
  // (SeasonState, WeekPlan) 两个参数——旧调用会让 plan 退化成一个字符串，全队永远练不出
  // 任何成长，复赛/NOIP 起的所有正式赛都「没人报名」，回放自检形同虚设。改成全程 extra
  // 强度 + 轮转刷最弱专题，尽量把真实赛道（含新的 CTT/CTS/答辩）跑起来。
  const topic = TOPIC_LIST[week % TOPIC_LIST.length] ?? null;
  s = planWeek(s, { topic, intensity: 'extra', mock: { preset: 'normal', problemCount: 3, minutes: 180 } });
  const stage = stageOfWeek(week);
  const trace = [];
  const t0 = Date.now();
  const next = runWeeklyContest(s, trace);
  const dt = Date.now() - t0;
  const recap = next.lastContest;


  // 初赛是笔试直接出分，没有可看的比赛
  if (stage && stage.kind === 'prelim') {
    if (trace.length !== 0) { console.log(`❌ 第 ${week} 周初赛不该有回放`); mismatches++; }
  } else if (trace.length === 0) {
    console.log(`⚠️ 第 ${week} 周 ${stage?.short ?? '模拟赛'}：没有回放（可能没人报名）`);
  } else {
    // 回放：同 cfg 重建 + 跑满时长
    // 多日比赛（省选/NOI 两试）trace 里是每天一条 round，瞬时结算用 mergeDays 把
    // 两天分数加总；回放也要累加同一人的分数，不能被下一天的 round 覆盖掉。
    const replayRows = new Map();
    for (const round of trace) {
      const c = createContest(round.cfg);
      tick(c, c.duration);
      if (!c.isFinished) throw new Error(`第 ${week} 周 ${round.label} 没跑到收卷`);
      for (const r of finalize(c)) replayRows.set(r.name, (replayRows.get(r.name) ?? 0) + r.real);
    }
    // 瞬时结算的分数；NOI 的 real 里还叠了一段「100 分笔试」（prelimPaperScore 另算的，
    // 不走 tick 引擎、trace 里也没有这一段可回放），对比前先扣掉，否则必然对不上。
    const settleRows = new Map(recap.rows.map((r) => [r.name, r.real - (r.written ?? 0)]));
    for (const [name, score] of settleRows) {
      const replay = replayRows.get(name);
      if (replay === undefined) { console.log(`❌ ${week} 周 ${name} 不在回放里`); mismatches++; continue; }
      if (replay !== score) { console.log(`❌ ${week} 周 ${name}：瞬时 ${score} ≠ 回放 ${replay}`); mismatches++; }
    }
    checked++;
    console.log(`✅ 第 ${week.toString().padStart(2)} 周 ${recap.title.slice(0, 22)}：${trace.length} 场回放、${settleRows.size} 人逐分一致（瞬时 ${dt}ms）`);
  }
  s = advanceWeek(next);
  if (s.phase === 'finished') break;
}

console.log(`\n检查 ${checked} 场比赛，不一致 ${mismatches} 处`);
logRun('trace-check', { seed, contests: checked, mismatches });
if (mismatches) process.exitCode = 1;
