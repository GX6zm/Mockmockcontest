/**
 * 教练模式 · 每周随机事件（M1.1）
 *
 * 设计目标：让「每周的 16 个决定」真的影响结局，而不只是换一个专题按钮。
 * 事件在「排训练」之前出现，玩家必须做一个有代价的选择；选完才进入训练。
 *
 * 2026-10-23 事件库扩容：从 7 个模板扩到 20 个，新增「设备 / 心理 / 荣誉」三个分类，
 * 降低三年生涯里反复抽到同一张事件卡的概率。
 *
 * 原则：
 * - 效果全部可量化、有代价，没有纯赚的选项；
 * - 事件只改 SeasonStudent 的 fatigue / topics（以及本周训练效率），
 *   不碰 game.ts 的比赛循环；
 * - 没有“心态/抗压/冒险”这类隐藏属性，选项一律落在疲劳、专题、训练效率上；
 * - 数据驱动：加事件 = 往 EVENT_DEFS 里加一条，不用改状态机。
 */
import { TOPIC_LIST } from './game.ts';
import type { Topic } from './types.ts';
import type { SeasonState } from './season.ts';

export interface StudentPatch {
  /** 0-100 */
  fatigue?: number;
  /** 专题水平增量 */
  topics?: Partial<Record<Topic, number>>;
}

export interface EventPatch {
  /** 事件日志里显示的一句话（会带上学生名字） */
  log: string;
  /** 只作用于事件指向的那个学生 */
  target?: StudentPatch;
  /** 作用于全队 */
  team?: StudentPatch;
  /** 本周训练效率倍率（1 = 正常；0.6 = 砍半） */
  growthMult?: number;
}

export interface EventChoice {
  id: string;
  label: string;
  /** 按钮上的代价提示（玩家可见） */
  note: string;
  apply: (s: SeasonState, target: string | null, rng: () => number) => EventPatch;
}

export interface SeasonEventDef {
  id: string;
  /** 归类：感情 / 教学 / 行政 / 家庭 / 机会 / 健康 / 竞争 / 设备 / 心理 / 荣誉 */
  tag: string;
  title: string;
  /** 需要指定一个队员 */
  needsTarget: boolean;
  /** 抽取权重 */
  weight: number;
  /** 正文，{name} 替换成学生名 */
  text: string;
  options: EventChoice[];
}

/** 找某个学生当前最弱的专题（事件可以"顺手补一点"） */
function weakestTopic(s: SeasonState, name: string | null): Topic | null {
  const st = s.students.find((x) => x.name === name);
  if (!st) return null;
  let worst: Topic | null = null;
  let v = 2;
  for (const t of TOPIC_LIST) {
    if (st.skills.topics[t] < v) { v = st.skills.topics[t]; worst = t; }
  }
  return worst;
}

/** 把"涨一点点某专题"写成 patch；找不到学生就退化成 generic 补弱项 */
function bump(s: SeasonState, target: string | null, delta: number): EventPatch['target'] {
  const t = weakestTopic(s, target);
  if (!t) return {};
  return { topics: { [t]: delta } as Partial<Record<Topic, number>> };
}

export const EVENT_DEFS: SeasonEventDef[] = [
  {
    id: 'romance',
    tag: '感情',
    title: '早恋风波',
    needsTarget: true,
    weight: 1.1,
    text: '{name} 最近和隔壁班一个同学走得很近，晚自习明显心不在焉，训练日志上开始出现"发呆"。',
    options: [
      {
        id: 'talk',
        label: '约谈一次，定个边界',
        note: '疲劳 +4 · 顺手补最弱专题 +1%',
        apply: (s, t) => ({
          log: `你在操场边和 ${t ?? '他'} 聊了 40 分钟：不反对，但不能耽误训练。对方点头了。`,
          target: { fatigue: 4, ...bump(s, t, 0.01) },
        }),
      },
      {
        id: 'blind',
        label: '睁一只眼闭一只眼',
        note: '疲劳 +2 · 本周训练 ×0.9',
        apply: (_s, t) => ({
          log: `${t ?? '他'} 心情很好，训练时却总在回消息。你说不出哪里不对。`,
          target: { fatigue: 2 },
          growthMult: 0.9,
        }),
      },
      {
        id: 'plan',
        label: '约法三章，一起排时间表',
        note: '疲劳 +3 · 最弱专题 +2%',
        apply: (s, t) => ({
          log: `${t ?? '他'} 自己把晚自习切成了训练/见面两段，还顺手把最弱的专题补了一点。`,
          target: { fatigue: 3, ...bump(s, t, 0.02) },
        }),
      },
    ],
  },
  {
    id: 'teacher',
    tag: '教学',
    title: '班主任找上门',
    needsTarget: false,
    weight: 1.0,
    text: '文化课班主任在走廊拦住你：最近作业交得越来越晚，"你这个训练，是不是占得太多了？"',
    options: [
      {
        id: 'cut',
        label: '把训练压一压',
        note: '本周训练 ×0.6 · 疲劳 −10',
        apply: () => ({
          log: '训练量砍半，班主任满意了，学生倒是睡了个好觉。',
          team: { fatigue: -10 },
          growthMult: 0.6,
        }),
      },
      {
        id: 'arrange',
        label: '和班主任商量着排课',
        note: '本周训练 ×0.85 · 疲劳 −4',
        apply: () => ({
          log: '你们把晚自习重新切了块，各退一步，勉强都过得去。',
          team: { fatigue: -4 },
          growthMult: 0.85,
        }),
      },
      {
        id: 'hold',
        label: '顶住，用成绩说话',
        note: '本周训练 ×1.1 · 疲劳 +4',
        apply: () => ({
          log: '你把成绩单拍在桌上："期末看结果。"班主任没再说话。',
          team: { fatigue: 4 },
          growthMult: 1.1,
        }),
      },
    ],
  },
  {
    id: 'school',
    tag: '行政',
    title: '校领导的压力',
    needsTarget: false,
    weight: 0.9,
    text: '年级会上领导点了名：今年信息学竞赛要出成绩，"你们那批人到底行不行，给个准话。"',
    options: [
      {
        id: 'vow',
        label: '立军令状',
        note: '本周训练 ×1.15 · 疲劳 +6',
        apply: () => ({
          log: '你在会上把目标写在了黑板上。回来以后，机房的气氛明显绷紧了。',
          team: { fatigue: 6 },
          growthMult: 1.15,
        }),
      },
      {
        id: 'talk',
        label: '会后单独找领导沟通',
        note: '本周训练 ×0.95 · 疲劳 +2',
        apply: () => ({
          log: '你在办公室解释了赛制和时间线，领导勉强接受了"稳着来"。',
          team: { fatigue: 2 },
          growthMult: 0.95,
        }),
      },
      {
        id: 'refuse',
        label: '顶回去：节奏不能乱',
        note: '本周训练 ×1.05',
        apply: () => ({
          log: '你坚持了自己的节奏。领导没再说什么，但队里有人听说了这事。',
          growthMult: 1.05,
        }),
      },
    ],
  },
  {
    id: 'parent',
    tag: '家庭',
    title: '家长焦虑',
    needsTarget: true,
    weight: 1.1,
    text: '{name} 家长的电话打到你手机上，语气很急：孩子天天泡机房，文化课要掉下来了。',
    options: [
      {
        id: 'meeting',
        label: '请家长来学校谈一次',
        note: '疲劳 +6 · 最弱专题 +1%',
        apply: (s, t) => ({
          log: `你给 ${t ?? '他'} 家长看了训练记录和升学数据，对方走的时候脸色好多了。`,
          target: { fatigue: 6, ...bump(s, t, 0.01) },
        }),
      },
      {
        id: 'call',
        label: '电话里安抚',
        note: '疲劳 +2 · 最弱专题 +0.5%',
        apply: (s, t) => ({
          log: `你在电话里讲了半小时，${t ?? '他'} 家长将信将疑地挂了电话。`,
          target: { fatigue: 2, ...bump(s, t, 0.005) },
        }),
      },
      {
        id: 'self',
        label: '让学生自己跟家里谈',
        note: '五五开：谈成疲劳 +3、补最弱专题 +1.5%；谈崩疲劳 +5',
        apply: (s, t, rng) => {
          const ok = rng() < 0.5;
          return {
            log: ok
              ? `${t ?? '他'} 自己跟家里谈通了，回来的时候眼睛是亮的。`
              : `${t ?? '他'} 和家里吵了一架，回来一言不发，训练时手一直在抖。`,
            target: ok
              ? { fatigue: 3, ...bump(s, t, 0.015) }
              : { fatigue: 5 },
          };
        },
      },
    ],
  },
  {
    id: 'exchange',
    tag: '机会',
    title: '隔壁学校约交流赛',
    needsTarget: false,
    weight: 0.8,
    text: '隔壁学校发来消息：周六想约一场交流赛，四道题，打完一起讲评。',
    options: [
      {
        id: 'accept',
        label: '接，当实战演练',
        note: '疲劳 +12 · 本周训练 ×0.9',
        apply: () => ({
          log: '交流赛打得很凶，虽然累，但队里第一次见识了外面的节奏。',
          team: { fatigue: 12 },
          growthMult: 0.9,
        }),
      },
      {
        id: 'decline',
        label: '婉拒，按计划练',
        note: '本周训练 ×1.05 · 少一次实战',
        apply: () => ({
          log: '你推掉了交流赛，按原计划训练。有人小声说"好想打"。',
          growthMult: 1.05,
        }),
      },
      {
        id: 'partial',
        label: '只派状态好的几个去',
        note: '疲劳 +5 · 本周训练 ×0.95',
        apply: () => ({
          log: '你挑了三个状态最好的去打，回来给大家讲了半节复盘课。',
          team: { fatigue: 5 },
          growthMult: 0.95,
        }),
      },
    ],
  },
  {
    id: 'cold',
    tag: '健康',
    title: '有人感冒了',
    needsTarget: true,
    weight: 0.9,
    text: '{name} 连着打了两天喷嚏，今天早上没来早训。',
    options: [
      {
        id: 'rest',
        label: '让他休息一周',
        note: '疲劳 −25 · 本周训练 ×0.9',
        apply: (_s, t) => ({
          log: `${t ?? '他'} 在家躺了一周，回来的时候脸色好多了。`,
          target: { fatigue: -25 },
          growthMult: 0.9,
        }),
      },
      {
        id: 'push',
        label: '带病训练，轻伤不下火线',
        note: '疲劳 +15 · 最弱专题 +1.5%',
        apply: (s, t) => ({
          log: `${t ?? '他'} 裹着外套来机房，一边咳嗽一边敲代码。你有点心疼。`,
          target: { fatigue: 15, ...bump(s, t, 0.015) },
        }),
      },
      {
        id: 'half',
        label: '半天训练半天休息',
        note: '疲劳 −6',
        apply: (_s, t) => ({
          log: `${t ?? '他'} 上午来机房，下午回去睡觉。折中方案，谁都不太满意。`,
          target: { fatigue: -6 },
        }),
      },
    ],
  },
  {
    id: 'rival',
    tag: '竞争',
    title: '隔壁教练来挖人',
    needsTarget: true,
    weight: 0.7,
    text: '隔壁学校的教练私下加了 {name} 的微信，说"来我们这，每周两次一对一"。',
    options: [
      {
        id: 'promise',
        label: '找学生谈话，给出承诺',
        note: '疲劳 +2 · 最弱专题 +1%',
        apply: (s, t) => ({
          log: `你跟 ${t ?? '他'} 交了底：资源有限，但你的时间都给他。他留下来了。`,
          target: { fatigue: 2, ...bump(s, t, 0.01) },
        }),
      },
      {
        id: 'invest',
        label: '加大投入，用行动表态',
        note: '本周训练 ×1.1 · 疲劳 +8',
        apply: (_s, t) => ({
          log: `你连夜给 ${t ?? '他'} 排了一套加练计划。他没说什么，第二天来得最早。`,
          target: { fatigue: 8 },
          growthMult: 1.1,
        }),
      },
      {
        id: 'free',
        label: '尊重他的选择，不拦',
        note: '留下：疲劳 −2、补最弱专题 +1%；离开：疲劳 +4',
        apply: (s, t, rng) => {
          const stay = rng() > 0.35;
          return {
            log: stay
              ? `${t ?? '他'} 想了两天，最后还是留在了机房。`
              : `${t ?? '他'} 去了隔壁学校，人虽然还在队里，心已经不在。`,
            target: stay
              ? { fatigue: -2, ...bump(s, t, 0.01) }
              : { fatigue: 4 },
          };
        },
      },
    ],
  },
  {
    id: 'laptop',
    tag: '设备',
    title: '机房电脑集体卡顿',
    needsTarget: false,
    weight: 0.8,
    text: '机房的十几台老机器评测一慢就卡成 PPT，大家交代码都得排队等编译。',
    options: [
      {
        id: 'queue',
        label: '排队硬扛，按计划练',
        note: '本周训练 ×0.85',
        apply: () => ({
          log: '大家轮流上机，编译排队排到脾气都快没了，但计划总算没停。',
          growthMult: 0.85,
        }),
      },
      {
        id: 'borrow',
        label: '借隔壁年级的机房',
        note: '疲劳 +5（全队）',
        apply: () => ({
          log: '每天搬着书包换机房，折腾是折腾，好歹机器跑得动。',
          team: { fatigue: 5 },
        }),
      },
      {
        id: 'report',
        label: '报修 + 这周主攻纸上推导',
        note: '疲劳 −4（全队）· 本周训练 ×0.7',
        apply: () => ({
          log: '机器交给 IT 老师修，这周改成黑板推导和口头讲题，节奏慢了不少。',
          team: { fatigue: -4 },
          growthMult: 0.7,
        }),
      },
    ],
  },
  {
    id: 'rank_shock',
    tag: '竞争',
    title: '学弟学妹反超',
    needsTarget: true,
    weight: 0.8,
    text: '{name} 这次校内模拟赛的名次被一个刚入队的新生甩在了后面，脸色一整天都不好看。',
    options: [
      {
        id: 'motivate',
        label: '单独谈心，重新定目标',
        note: '疲劳 +3 · 最弱专题 +1.5%',
        apply: (s, t) => ({
          log: `你跟 ${t ?? '他'} 聊了名次之外的事，${t ?? '他'} 点点头，回去开始补短板。`,
          target: { fatigue: 3, ...bump(s, t, 0.015) },
        }),
      },
      {
        id: 'ignore',
        label: '不提这事，当没看见',
        note: '本周训练 ×0.85（全队，心里有疙瘩练不进去）',
        apply: (_s, t) => ({
          log: `没人提这事，但 ${t ?? '他'} 自己憋着一股劲，训练时总走神。`,
          growthMult: 0.85,
        }),
      },
      {
        id: 'spar',
        label: '安排和那位新生对练一场',
        note: '疲劳 +6 · 最弱专题 +2%',
        apply: (s, t) => ({
          log: `${t ?? '他'} 和新生正面切磋了一场，虽然又输了，但服气了，练得更狠了。`,
          target: { fatigue: 6, ...bump(s, t, 0.02) },
        }),
      },
    ],
  },
  {
    id: 'tired_eyes',
    tag: '健康',
    title: '用眼过度',
    needsTarget: true,
    weight: 0.7,
    text: '{name} 最近老揉眼睛，说看屏幕有点发花，可还是不想停下来。',
    options: [
      {
        id: 'force_rest',
        label: '强制离屏休息两天',
        note: '疲劳 −18',
        apply: (_s, t) => ({
          log: `${t ?? '他'} 被你撵回宿舍睡了两天，回来说眼睛清爽多了。`,
          target: { fatigue: -18 },
        }),
      },
      {
        id: 'glasses',
        label: '去配一副防蓝光眼镜，照常练',
        note: '疲劳 +6 · 最弱专题 +1%',
        apply: (s, t) => ({
          log: `${t ?? '他'} 戴上新眼镜继续敲代码，顺手把最弱的专题补了一点。`,
          target: { fatigue: 6, ...bump(s, t, 0.01) },
        }),
      },
      {
        id: 'self_call',
        label: '他自己说没事，随他去',
        note: '50% 没事；50% 疲劳 +12',
        apply: (_s, t, rng) => {
          const ok = rng() < 0.5;
          return {
            log: ok
              ? `${t ?? '他'} 歇了两天自己缓过来了，算你走运。`
              : `${t ?? '他'} 眼睛肿得没法看屏幕，被迫停训去医院。`,
            target: ok ? {} : { fatigue: 12 },
          };
        },
      },
    ],
  },
  {
    id: 'summer_camp',
    tag: '机会',
    title: '外地集训营邀请',
    needsTarget: false,
    weight: 0.8,
    text: '一家培训机构发来邀请：寒假去外地封闭集训十天，有知名教练带队授课。',
    options: [
      {
        id: 'go',
        label: '全队去，当成一次强化',
        note: '疲劳 +10（全队）· 本周训练 ×1.15',
        apply: () => ({
          log: '十天封闭集训下来，队里个个黑眼圈，但确实学到了不少新套路。',
          team: { fatigue: 10 },
          growthMult: 1.15,
        }),
      },
      {
        id: 'partial',
        label: '只送一两个主力去',
        note: '疲劳 +4（全队）',
        apply: () => ({
          log: '留守的人照常训练，去集训的那几个回来讲了不少见闻。',
          team: { fatigue: 4 },
        }),
      },
      {
        id: 'skip',
        label: '不去了，省下旅途折腾',
        note: '本周训练 ×1.05 · 疲劳 −2（全队）',
        apply: () => ({
          log: '你婉拒了邀请，按自己的节奏接着练，省心不少。',
          team: { fatigue: -2 },
          growthMult: 1.05,
        }),
      },
    ],
  },
  {
    id: 'media',
    tag: '荣誉',
    title: '校报要来采访',
    needsTarget: true,
    weight: 0.6,
    text: '校报记者找到你：想采访 {name}，写一篇"冲奖之路"的专题报道，占用一下午时间拍照。',
    options: [
      {
        id: 'accept',
        label: '答应，当成一次放松',
        note: '疲劳 −5 · 本周训练 ×0.9',
        apply: (_s, t) => ({
          log: `${t ?? '他'} 对着镜头讲了半天自己的故事，意外地挺放松。`,
          target: { fatigue: -5 },
          growthMult: 0.9,
        }),
      },
      {
        id: 'decline',
        label: '婉拒，专心训练',
        note: '本周训练 ×1.05',
        apply: () => ({
          log: '你替学生推掉了采访，记者说下次一定还来。',
          growthMult: 1.05,
        }),
      },
      {
        id: 'quick',
        label: '压缩成十分钟快采',
        note: '疲劳 +1 · 最弱专题 +0.5%',
        apply: (s, t) => ({
          log: `十分钟拍完收工，${t ?? '他'} 顺嘴跟记者聊的时候把弱项又过了一遍。`,
          target: { fatigue: 1, ...bump(s, t, 0.005) },
        }),
      },
    ],
  },
  {
    id: 'exam_week',
    tag: '教学',
    title: '文化课期中考撞车',
    needsTarget: false,
    weight: 1.0,
    text: '文化课期中考试周和训练计划撞在了一起，学生们晚上要复习到很晚。',
    options: [
      {
        id: 'pause',
        label: '停一周训练，专心复习',
        note: '本周训练 ×0.5 · 疲劳 −8（全队）',
        apply: () => ({
          log: '这周机房空了大半，大家回去啃文化课，倒是睡得比平时早。',
          team: { fatigue: -8 },
          growthMult: 0.5,
        }),
      },
      {
        id: 'balance',
        label: '各砍一半时间',
        note: '本周训练 ×0.75 · 疲劳 +2（全队）',
        apply: () => ({
          log: '训练和复习各占一半，没人睡够，但好歹两头都没全丢。',
          team: { fatigue: 2 },
          growthMult: 0.75,
        }),
      },
      {
        id: 'insist',
        label: '照常训练，文化课算了',
        note: '本周训练 ×1.1 · 疲劳 +8（全队）',
        apply: () => ({
          log: '你顶着压力照常练，有家长已经在年级群里嘀咕了几句。',
          team: { fatigue: 8 },
          growthMult: 1.1,
        }),
      },
    ],
  },
  {
    id: 'friendship',
    tag: '感情',
    title: '队内闹别扭',
    needsTarget: true,
    weight: 0.7,
    text: '{name} 这两天和队里另一个人因为一次组队训练吵了一架，机房的气氛有点僵。',
    options: [
      {
        id: 'mediate',
        label: '把两人叫到一起聊开',
        note: '疲劳 +3 · 最弱专题 +1%',
        apply: (s, t) => ({
          log: `你把两人叫到办公室，聊开以后 ${t ?? '他'} 反倒松了口气，练得更专心了。`,
          target: { fatigue: 3, ...bump(s, t, 0.01) },
        }),
      },
      {
        id: 'separate',
        label: '这周先分开练，冷静一下',
        note: '本周训练 ×0.9',
        apply: () => ({
          log: '两人这周各练各的，机房气氛是松了，但协作训练也停了。',
          growthMult: 0.9,
        }),
      },
      {
        id: 'ignore',
        label: '年轻人闹别扭，过几天就好',
        note: '50% 自己和好；50% 疲劳 +8 · 本周训练 ×0.85',
        apply: (_s, t, rng) => {
          const ok = rng() < 0.5;
          return {
            log: ok
              ? `过了几天两人自己又凑一块讨论题了，虚惊一场。`
              : `${t ?? '他'} 一直绷着脸，训练效率肉眼可见地掉了下去。`,
            target: ok ? {} : { fatigue: 8 },
            growthMult: ok ? 1 : 0.85,
          };
        },
      },
    ],
  },
  {
    id: 'scholarship',
    tag: '机会',
    title: '高校少年班推荐名额',
    needsTarget: true,
    weight: 0.6,
    text: '一所重点大学的少年班项目给了一个推荐名额，点名想要 {name} 这样的竞赛生去试一试。',
    options: [
      {
        id: 'send',
        label: '推荐他去，当作一次历练',
        note: '疲劳 +8 · 最弱专题 +1.5%',
        apply: (s, t) => ({
          log: `${t ?? '他'} 去面试了一圈，回来人明显沉稳了，顺手把弱项补了补。`,
          target: { fatigue: 8, ...bump(s, t, 0.015) },
        }),
      },
      {
        id: 'keep',
        label: '婉拒，专心备赛',
        note: '本周训练 ×1.05',
        apply: () => ({
          log: '你替他推掉了，面试和竞赛节奏实在冲突太大。',
          growthMult: 1.05,
        }),
      },
      {
        id: 'split',
        label: '先去露个面，中途请假回来',
        note: '疲劳 +4 · 本周训练 ×0.9',
        apply: (_s, t) => ({
          log: `${t ?? '他'} 去露了个面就赶回来了，路上折腾但没耽误太多。`,
          target: { fatigue: 4 },
          growthMult: 0.9,
        }),
      },
    ],
  },
  {
    id: 'burnout',
    tag: '心理',
    title: '训练瓶颈期',
    needsTarget: true,
    weight: 0.9,
    text: '{name} 最近怎么练效果都上不去，自己在训练日志里写"是不是没天赋"。',
    options: [
      {
        id: 'talk',
        label: '聊一次，帮他拆解问题',
        note: '疲劳 +2 · 最弱专题 +2%',
        apply: (s, t) => ({
          log: `你陪 ${t ?? '他'} 把最近的错题一条条过了一遍，瓶颈松动了一点。`,
          target: { fatigue: 2, ...bump(s, t, 0.02) },
        }),
      },
      {
        id: 'break',
        label: '放一天假换换脑子',
        note: '疲劳 −15',
        apply: (_s, t) => ({
          log: `${t ?? '他'} 歇了一天去打了场球，回来状态肉眼可见地松快了。`,
          target: { fatigue: -15 },
        }),
      },
      {
        id: 'push',
        label: '告诉他瓶颈都这样，硬扛过去',
        note: '疲劳 +10 · 50% 顿悟最弱专题 +3%，50% 没变化',
        apply: (s, t, rng) => {
          const ok = rng() < 0.5;
          return {
            log: ok
              ? `${t ?? '他'} 咬牙又练了一周，某天晚上突然就开窍了。`
              : `${t ?? '他'} 又硬扛了一周，瓶颈纹丝不动，人倒是更累了。`,
            target: ok ? { fatigue: 10, ...bump(s, t, 0.03) } : { fatigue: 10 },
          };
        },
      },
    ],
  },
  {
    id: 'power_outage',
    tag: '设备',
    title: '机房临时停电',
    needsTarget: false,
    weight: 0.6,
    text: '周三下午机房突然跳闸，重新来电前谁都没法继续敲代码。',
    options: [
      {
        id: 'paper',
        label: '改成纸上做题，停电也不耽误',
        note: '本周训练 ×0.8',
        apply: () => ({
          log: '大家改在纸上推题，没有编译器查错，进度慢了一些。',
          growthMult: 0.8,
        }),
      },
      {
        id: 'wait',
        label: '干等着，来电了再补',
        note: '疲劳 +3（全队）· 本周训练 ×0.9',
        apply: () => ({
          log: '等了一个多小时才来电，大家补着训练到很晚。',
          team: { fatigue: 3 },
          growthMult: 0.9,
        }),
      },
      {
        id: 'reschedule',
        label: '改约周末补训',
        note: '疲劳 +6（全队）',
        apply: () => ({
          log: '停电这天算是白搭，周末又多加了一场训练补回来。',
          team: { fatigue: 6 },
        }),
      },
    ],
  },
  {
    id: 'injury',
    tag: '健康',
    title: '手腕劳损',
    needsTarget: true,
    weight: 0.6,
    text: '{name} 敲键盘的手腕最近总是发酸，握鼠标都有点不得劲。',
    options: [
      {
        id: 'rest',
        label: '停练手部，换脑力训练（读题/推导）',
        note: '疲劳 −12 · 最弱专题 +1%',
        apply: (s, t) => ({
          log: `${t ?? '他'} 这周只做口头推导和读题，手腕歇过来了，脑子也没闲着。`,
          target: { fatigue: -12, ...bump(s, t, 0.01) },
        }),
      },
      {
        id: 'brace',
        label: '戴护腕继续练',
        note: '疲劳 +4 · 最弱专题 +1.5%',
        apply: (s, t) => ({
          log: `${t ?? '他'} 戴着护腕接着敲代码，手腕时不时还是会酸。`,
          target: { fatigue: 4, ...bump(s, t, 0.015) },
        }),
      },
      {
        id: 'checkup',
        label: '去医院看一下，耽误半天',
        note: '疲劳 −6',
        apply: (_s, t) => ({
          log: `${t ?? '他'} 去拍了个片，医生说没大事，开了点药膏就回来了。`,
          target: { fatigue: -6 },
        }),
      },
    ],
  },
  {
    id: 'room_borrowed',
    tag: '行政',
    title: '机房被借用',
    needsTarget: false,
    weight: 0.7,
    text: '学校临时通知，机房这周要借给高三摸底考试用，训练场地得挪地方。',
    options: [
      {
        id: 'relocate',
        label: '搬到阶梯教室，将就一下',
        note: '疲劳 +5（全队）· 本周训练 ×0.9',
        apply: () => ({
          log: '大家扛着笔记本挤在阶梯教室练，条件差了点，好歹没停。',
          team: { fatigue: 5 },
          growthMult: 0.9,
        }),
      },
      {
        id: 'postpone',
        label: '干脆这周推掉训练',
        note: '疲劳 −10（全队）· 本周训练 ×0.5',
        apply: () => ({
          log: '你索性把这周定成调整周，队里难得睡了几天好觉。',
          team: { fatigue: -10 },
          growthMult: 0.5,
        }),
      },
      {
        id: 'negotiate',
        label: '去协调换个时间段',
        note: '疲劳 +2（全队）',
        apply: () => ({
          log: '你跑了教务处两趟，总算把训练时间段挪到了晚上，没耽误正事。',
          team: { fatigue: 2 },
        }),
      },
    ],
  },
  {
    id: 'gala',
    tag: '荣誉',
    title: '校庆要表演节目',
    needsTarget: false,
    weight: 0.5,
    text: '校庆晚会缺节目，年级主任点名让信息学队出一个"编程才艺"环节。',
    options: [
      {
        id: 'perform',
        label: '认真准备一个节目',
        note: '疲劳 +6（全队）· 本周训练 ×0.75',
        apply: () => ({
          log: '队里排了个"现场手写代码接力"，台下反响还不错，就是排练占了不少时间。',
          team: { fatigue: 6 },
          growthMult: 0.75,
        }),
      },
      {
        id: 'symbolic',
        label: '随便糊弄一个意思一下',
        note: '本周训练 ×0.9',
        apply: () => ({
          log: '节目演得潦草，主任脸色不太好看，但训练没怎么耽误。',
          growthMult: 0.9,
        }),
      },
      {
        id: 'refuse',
        label: '找理由推掉',
        note: '本周训练 ×1.05（但年级主任记下了这件事）',
        apply: () => ({
          log: '你找了个借口推掉了演出，主任没说什么，但你能感觉到那份不悦。',
          growthMult: 1.05,
        }),
      },
    ],
  },
];

/** 事件抽到的结果（存进 SeasonState，UI 直接渲染） */
export interface PendingEvent {
  id: string;
  week: number;
  tag: string;
  title: string;
  text: string;
  target: string | null;
  options: { id: string; label: string; note: string }[];
}

export function eventDefById(id: string): SeasonEventDef | undefined {
  return EVENT_DEFS.find((d) => d.id === id);
}
