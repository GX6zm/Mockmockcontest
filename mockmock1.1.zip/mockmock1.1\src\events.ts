/**
 * 教练模式 · 每周随机事件（M1.1）
 *
 * 设计目标：让「每周的 16 个决定」真的影响结局，而不只是换一个专题按钮。
 * 事件在「排训练」之前出现，玩家必须做一个有代价的选择；选完才进入训练。
 *
 * 原则：
 * - 效果全部可量化、有代价，没有纯赚的选项；
 * - 事件只改 SeasonStudent 的 fatigue / topics（以及本周训练效率），
 *   不碰 game.ts 的比赛循环；
 * - 没有“心态/抗压/冒险”这类隐藏属性，选项一律落在疲劳、专题、训练效率上；
 * - 数据驱动：加事件 = 往 EVENT_DEFS 里加一条，不用改状态机。
 */
import { TOPIC_LIST } from './game.ts';
import type { Topic } from './types.ts';
import type { SeasonState } from './season.ts';

export interface StudentPatch {
  /** 0-100 */
  fatigue?: number;
  /** 专题水平增量 */
  topics?: Partial<Record<Topic, number>>;
}

export interface EventPatch {
  /** 事件日志里显示的一句话（会带上学生名字） */
  log: string;
  /** 只作用于事件指向的那个学生 */
  target?: StudentPatch;
  /** 作用于全队 */
  team?: StudentPatch;
  /** 本周训练效率倍率（1 = 正常；0.6 = 砍半） */
  growthMult?: number;
}

export interface EventChoice {
  id: string;
  label: string;
  /** 按钮上的代价提示（玩家可见） */
  note: string;
  apply: (s: SeasonState, target: string | null, rng: () => number) => EventPatch;
}

export interface SeasonEventDef {
  id: string;
  /** 归类：感情 / 教学 / 行政 / 家庭 / 机会 / 健康 / 竞争 */
  tag: string;
  title: string;
  /** 需要指定一个队员 */
  needsTarget: boolean;
  /** 抽取权重 */
  weight: number;
  /** 正文，{name} 替换成学生名 */
  text: string;
  options: EventChoice[];
}

/** 找某个学生当前最弱的专题（事件可以"顺手补一点"） */
function weakestTopic(s: SeasonState, name: string | null): Topic | null {
  const st = s.students.find((x) => x.name === name);
  if (!st) return null;
  let worst: Topic | null = null;
  let v = 2;
  for (const t of TOPIC_LIST) {
    if (st.skills.topics[t] < v) { v = st.skills.topics[t]; worst = t; }
  }
  return worst;
}

/** 把"涨一点点某专题"写成 patch；找不到学生就退化成 generic 补弱项 */
function bump(s: SeasonState, target: string | null, delta: number): EventPatch['target'] {
  const t = weakestTopic(s, target);
  if (!t) return {};
  return { topics: { [t]: delta } as Partial<Record<Topic, number>> };
}

export const EVENT_DEFS: SeasonEventDef[] = [
  {
    id: 'romance',
    tag: '感情',
    title: '早恋风波',
    needsTarget: true,
    weight: 1.1,
    text: '{name} 最近和隔壁班一个同学走得很近，晚自习明显心不在焉，训练日志上开始出现"发呆"。',
    options: [
      {
        id: 'talk',
        label: '约谈一次，定个边界',
        note: '疲劳 +4 · 顺手补最弱专题 +1%',
        apply: (s, t) => ({
          log: `你在操场边和 ${t ?? '他'} 聊了 40 分钟：不反对，但不能耽误训练。对方点头了。`,
          target: { fatigue: 4, ...bump(s, t, 0.01) },
        }),
      },
      {
        id: 'blind',
        label: '睁一只眼闭一只眼',
        note: '疲劳 +2 · 本周训练 ×0.9',
        apply: (_s, t) => ({
          log: `${t ?? '他'} 心情很好，训练时却总在回消息。你说不出哪里不对。`,
          target: { fatigue: 2 },
          growthMult: 0.9,
        }),
      },
      {
        id: 'plan',
        label: '约法三章，一起排时间表',
        note: '疲劳 +3 · 最弱专题 +2%',
        apply: (s, t) => ({
          log: `${t ?? '他'} 自己把晚自习切成了训练/见面两段，还顺手把最弱的专题补了一点。`,
          target: { fatigue: 3, ...bump(s, t, 0.02) },
        }),
      },
    ],
  },
  {
    id: 'teacher',
    tag: '教学',
    title: '班主任找上门',
    needsTarget: false,
    weight: 1.0,
    text: '文化课班主任在走廊拦住你：最近作业交得越来越晚，"你这个训练，是不是占得太多了？"',
    options: [
      {
        id: 'cut',
        label: '把训练压一压',
        note: '本周训练 ×0.6 · 疲劳 −10',
        apply: () => ({
          log: '训练量砍半，班主任满意了，学生倒是睡了个好觉。',
          team: { fatigue: -10 },
          growthMult: 0.6,
        }),
      },
      {
        id: 'arrange',
        label: '和班主任商量着排课',
        note: '本周训练 ×0.85 · 疲劳 −4',
        apply: () => ({
          log: '你们把晚自习重新切了块，各退一步，勉强都过得去。',
          team: { fatigue: -4 },
          growthMult: 0.85,
        }),
      },
      {
        id: 'hold',
        label: '顶住，用成绩说话',
        note: '本周训练 ×1.1 · 疲劳 +4',
        apply: () => ({
          log: '你把成绩单拍在桌上："期末看结果。"班主任没再说话。',
          team: { fatigue: 4 },
          growthMult: 1.1,
        }),
      },
    ],
  },
  {
    id: 'school',
    tag: '行政',
    title: '校领导的压力',
    needsTarget: false,
    weight: 0.9,
    text: '年级会上领导点了名：今年信息学竞赛要出成绩，"你们那批人到底行不行，给个准话。"',
    options: [
      {
        id: 'vow',
        label: '立军令状',
        note: '本周训练 ×1.15 · 疲劳 +6',
        apply: () => ({
          log: '你在会上把目标写在了黑板上。回来以后，机房的气氛明显绷紧了。',
          team: { fatigue: 6 },
          growthMult: 1.15,
        }),
      },
      {
        id: 'talk',
        label: '会后单独找领导沟通',
        note: '本周训练 ×0.95 · 疲劳 +2',
        apply: () => ({
          log: '你在办公室解释了赛制和时间线，领导勉强接受了"稳着来"。',
          team: { fatigue: 2 },
          growthMult: 0.95,
        }),
      },
      {
        id: 'refuse',
        label: '顶回去：节奏不能乱',
        note: '本周训练 ×1.05',
        apply: () => ({
          log: '你坚持了自己的节奏。领导没再说什么，但队里有人听说了这事。',
          growthMult: 1.05,
        }),
      },
    ],
  },
  {
    id: 'parent',
    tag: '家庭',
    title: '家长焦虑',
    needsTarget: true,
    weight: 1.1,
    text: '{name} 家长的电话打到你手机上，语气很急：孩子天天泡机房，文化课要掉下来了。',
    options: [
      {
        id: 'meeting',
        label: '请家长来学校谈一次',
        note: '疲劳 +6 · 最弱专题 +1%',
        apply: (s, t) => ({
          log: `你给 ${t ?? '他'} 家长看了训练记录和升学数据，对方走的时候脸色好多了。`,
          target: { fatigue: 6, ...bump(s, t, 0.01) },
        }),
      },
      {
        id: 'call',
        label: '电话里安抚',
        note: '疲劳 +2 · 最弱专题 +0.5%',
        apply: (s, t) => ({
          log: `你在电话里讲了半小时，${t ?? '他'} 家长将信将疑地挂了电话。`,
          target: { fatigue: 2, ...bump(s, t, 0.005) },
        }),
      },
      {
        id: 'self',
        label: '让学生自己跟家里谈',
        note: '五五开：谈成疲劳 +3、补最弱专题 +1.5%；谈崩疲劳 +5',
        apply: (s, t, rng) => {
          const ok = rng() < 0.5;
          return {
            log: ok
              ? `${t ?? '他'} 自己跟家里谈通了，回来的时候眼睛是亮的。`
              : `${t ?? '他'} 和家里吵了一架，回来一言不发，训练时手一直在抖。`,
            target: ok
              ? { fatigue: 3, ...bump(s, t, 0.015) }
              : { fatigue: 5 },
          };
        },
      },
    ],
  },
  {
    id: 'exchange',
    tag: '机会',
    title: '隔壁学校约交流赛',
    needsTarget: false,
    weight: 0.8,
    text: '隔壁学校发来消息：周六想约一场交流赛，四道题，打完一起讲评。',
    options: [
      {
        id: 'accept',
        label: '接，当实战演练',
        note: '疲劳 +12 · 本周训练 ×0.9',
        apply: () => ({
          log: '交流赛打得很凶，虽然累，但队里第一次见识了外面的节奏。',
          team: { fatigue: 12 },
          growthMult: 0.9,
        }),
      },
      {
        id: 'decline',
        label: '婉拒，按计划练',
        note: '本周训练 ×1.05 · 少一次实战',
        apply: () => ({
          log: '你推掉了交流赛，按原计划训练。有人小声说"好想打"。',
          growthMult: 1.05,
        }),
      },
      {
        id: 'partial',
        label: '只派状态好的几个去',
        note: '疲劳 +5 · 本周训练 ×0.95',
        apply: () => ({
          log: '你挑了三个状态最好的去打，回来给大家讲了半节复盘课。',
          team: { fatigue: 5 },
          growthMult: 0.95,
        }),
      },
    ],
  },
  {
    id: 'cold',
    tag: '健康',
    title: '有人感冒了',
    needsTarget: true,
    weight: 0.9,
    text: '{name} 连着打了两天喷嚏，今天早上没来早训。',
    options: [
      {
        id: 'rest',
        label: '让他休息一周',
        note: '疲劳 −25 · 本周训练 ×0.9',
        apply: (_s, t) => ({
          log: `${t ?? '他'} 在家躺了一周，回来的时候脸色好多了。`,
          target: { fatigue: -25 },
          growthMult: 0.9,
        }),
      },
      {
        id: 'push',
        label: '带病训练，轻伤不下火线',
        note: '疲劳 +15 · 最弱专题 +1.5%',
        apply: (s, t) => ({
          log: `${t ?? '他'} 裹着外套来机房，一边咳嗽一边敲代码。你有点心疼。`,
          target: { fatigue: 15, ...bump(s, t, 0.015) },
        }),
      },
      {
        id: 'half',
        label: '半天训练半天休息',
        note: '疲劳 −6',
        apply: (_s, t) => ({
          log: `${t ?? '他'} 上午来机房，下午回去睡觉。折中方案，谁都不太满意。`,
          target: { fatigue: -6 },
        }),
      },
    ],
  },
  {
    id: 'rival',
    tag: '竞争',
    title: '隔壁教练来挖人',
    needsTarget: true,
    weight: 0.7,
    text: '隔壁学校的教练私下加了 {name} 的微信，说"来我们这，每周两次一对一"。',
    options: [
      {
        id: 'promise',
        label: '找学生谈话，给出承诺',
        note: '疲劳 +2 · 最弱专题 +1%',
        apply: (s, t) => ({
          log: `你跟 ${t ?? '他'} 交了底：资源有限，但你的时间都给他。他留下来了。`,
          target: { fatigue: 2, ...bump(s, t, 0.01) },
        }),
      },
      {
        id: 'invest',
        label: '加大投入，用行动表态',
        note: '本周训练 ×1.1 · 疲劳 +8',
        apply: (_s, t) => ({
          log: `你连夜给 ${t ?? '他'} 排了一套加练计划。他没说什么，第二天来得最早。`,
          target: { fatigue: 8 },
          growthMult: 1.1,
        }),
      },
      {
        id: 'free',
        label: '尊重他的选择，不拦',
        note: '留下：疲劳 −2、补最弱专题 +1%；离开：疲劳 +4',
        apply: (s, t, rng) => {
          const stay = rng() > 0.35;
          return {
            log: stay
              ? `${t ?? '他'} 想了两天，最后还是留在了机房。`
              : `${t ?? '他'} 去了隔壁学校，人虽然还在队里，心已经不在。`,
            target: stay
              ? { fatigue: -2, ...bump(s, t, 0.01) }
              : { fatigue: 4 },
          };
        },
      },
    ],
  },
];

/** 事件抽到的结果（存进 SeasonState，UI 直接渲染） */
export interface PendingEvent {
  id: string;
  week: number;
  tag: string;
  title: string;
  text: string;
  target: string | null;
  options: { id: string; label: string; note: string }[];
}

export function eventDefById(id: string): SeasonEventDef | undefined {
  return EVENT_DEFS.find((d) => d.id === id);
}
