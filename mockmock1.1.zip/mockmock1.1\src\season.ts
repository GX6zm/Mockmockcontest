/**
 * 教练模式 · 生涯引擎（M2：三年周期 + 真实 OI 赛历 + 资格链）
 *
 * 一个学年 = 40 周（9 月 → 次年 7 月），赛历按真实 OI 节奏排：
 *   第 4 周  CSP-S 第一轮（初赛，100 分笔试，过线才能报复赛）
 *   第 8 周  CSP-S 第二轮（复赛，4 题 4 小时）
 *   第 12 周 NOIP（4 题 4.5 小时）
 *   第 16 周 WC 冬令营（3 题 5 小时）
 *   第 21 周 省选（两试，各 3 题 4.5 小时）
 *   第 26 周 APIO（3 题 5 小时）
 *   第 32 周 NOI（100 分笔试 + 两试，各 3 题 5 小时）
 *   第 34 周 CTT（国家集训队集训测试，两试）
 *   第 37 周 CTS（国家队选拔，两试）
 *   第 40 周 IOI（国际赛，两试）
 * 其余周次是训练周 + 周末校内模拟赛（不计入正式成绩，只给反馈）。
 *
 * 资格链：初赛过线 → 复赛；复赛二等及以上 → NOIP；NOIP 省一 → 省选/WC/APIO；
 * 省选进省队 → NOI；NOI 金牌 → CTT 前 30 → CTS 前 4 → IOI。
 * 拿不到资格就只能练一年，等下一个赛季。
 *
 * 生涯 = 3 个学年：每年 6 月高三毕业、高一新生入校，教练重新选队；
 * 3 年后看累计带出了几个省队、几块 NOI 牌。
 *
 * 训练 / 事件 / 比赛都只影响这个模块自己的状态，不碰 game.ts 的比赛循环。
 */
import { ROSTER } from './roster.ts';
import { awardIndexByRank, fieldScores, pctOf, rankAmong } from './field.ts';
import type { FieldSpec } from './field.ts';
import { GRADES_BY_NAME } from './grades.ts';
import { TALENT_BY_NAME } from './talent.ts';
import { PROFILE_BY_NAME } from './profile.ts';
import {
  TOPIC_LIST, TOPIC_NAMES, buildCohort, createContest, finalize, makeRng, tick,
} from './game.ts';
import { EVENT_DEFS, eventDefById } from './events.ts';
import type { PendingEvent, StudentPatch } from './events.ts';
import type { CohortEntry, ContestConfig, Problem, Skills, StudentResult, Topic } from './types.ts';

export const YEAR_WEEKS = 40;
export const CAREER_YEARS = 3;
/** 兼容旧脚本的名字（一学年周数） */
export const SEASON_WEEKS = YEAR_WEEKS;
export const TEAM_MIN = 6;
export const TEAM_MAX = 8;

/**
 * 一场「可观看」的比赛：runWeeklyContest 传 trace 时把每场要打的 cfg 记下来，
 * 前端用同一个 cfg 重建 Contest（同 seed 同结果），逐场播放给教练看；
 * 脚本不传 trace，则照旧瞬间算完——两边走的是同一个引擎，结果完全一致。
 */
export interface ContestRound {
  label: string;
  cfg: ContestConfig;
}

export type Grade = 1 | 2 | 3 | 4 | 5 | 6;
export const GRADE_NAMES: Record<Grade, string> = { 1: '初一', 2: '初二', 3: '初三', 4: '高一', 5: '高二', 6: '高三' };
/** 初中 / 高中分界：1–3 初中，4–6 高中 */
export const SENIOR_GRADE: Grade = 4;
export const isSenior = (g: Grade) => g >= SENIOR_GRADE;
export const isJunior = (g: Grade) => g < SENIOR_GRADE;

export type StageId = 'csp1' | 'csp2' | 'noip' | 'wc' | 'prov' | 'apio' | 'noi' | 'ctt' | 'cts' | 'ioi';

/** 奖项档：pct = 全国前百分之几（含）能拿这个奖 */
export interface AwardBand {
  pct: number;
  label: string;
  tone: 'gold' | 'silver' | 'bronze' | 'prov1' | 'team';
}

export interface StageDef {
  id: StageId;
  week: number;
  name: string;
  short: string;
  kind: 'prelim' | 'contest';
  /** J 组 / S 组 / BOTH = 同场分 J、S 两组 / OPEN = 不分学段 */
  group: 'J' | 'S' | 'BOTH' | 'OPEN';
  levels: number[];
  /** 每题难度范围（1-115），按历年真题难度定；初赛（笔试）不用 */
  ranges?: [number, number][];
  /** 引擎原始得分率 → 赛事真实得分率 的分段线性曲线（按历年真题得分率校准） */
  curve?: [number, number][];
  /** J/S 同场分卷时，J 组另一套难度范围 */
  rangesJ?: [number, number][];
  minutes: number;
  days: number;
  gate: StageId | null;
  gateText: string;
  advanceText: string;
  clock: string;
  /** 全国参赛人数（官方数据；推算的写在 note 里） */
  national: number;
  /** 得分率 → 全国分位的锚点（分位 = 全国前多少比例） */
  anchors: [number, number][];
  /** 奖项线（按全国分位），空数组 = 不评奖 */
  bands: AwardBand[];
  note?: string;
}

/**
 * 一学年的真实赛历（9 月第 1 周起算），参数按 2025–2026 赛季官方规程：
 * 初赛 100 分 2h（陕西 2025 S 线 37 / J 线 37.5，对应全国 80%/70% 位次）；
 * 复赛 S 组 4 题 4h、J 组 4 题 3.5h，一等/二等/三等 ≈ 全国前 20%/45%/75%；
 * NOIP 4 题 4.5h，全国获奖 67%（一等 20%、二等 22%、三等 25%），基准线 137/108/86；
 * WC 冬令营学生营员测试 1 场，不评奖（国家队从国家集训队里选）；
 * 省选两试各 4.5h，总分 = NOIP 标准分×30% + 省选标准分×70%，省队按上限 A 5 + B 12 = 17 人；
 * APIO 中国区 3 题 5h，金 64 / 银 128 / 铜 193（参赛约 600 名选手）；
 * NOI 两试各 5h，正式选手约 337 人，金 50 / 银 152 / 铜 85（85% 获奖）。
 */
export const YEAR_STAGES: StageDef[] = [
  {
    id: 'csp1', week: 4, name: 'CSP 第一轮（初赛）', short: '初赛',
    kind: 'prelim', group: 'S', levels: [], minutes: 120, days: 1, gate: null, gateText: '',
    advanceText: '过线才能参加第二轮', clock: '2026-09-19 · 第一轮',
    national: 34400, anchors: [], bands: [],
    note: '全校一张卷（S 卷），陕西线 37 分；晋级名额不少于实考 20%',
  },
  {
    id: 'csp2', week: 8, name: 'CSP 第二轮（复赛）', short: '复赛',
    kind: 'contest', group: 'S', levels: [3, 4, 5, 6], minutes: 240, days: 1,
    // 历年 CSP-S2：T1 普及+/提高-、T2 提高、T3 提高+、T4 省选
    ranges: [[45, 60], [60, 75], [72, 85], [85, 100]],
    // 校准：引擎原始得分率 → 2025 陕西 S 组真实得分率（强选手 84% ≈ 336 分）
    curve: [[0, 0], [0.25, 0.12], [0.32, 0.26], [0.38, 0.5], [0.45, 0.85], [0.6, 0.95], [1, 1]],
    gate: 'csp1', gateText: '初赛过线', advanceText: 'S 组二等及以上进 NOIP 名单',
    clock: '2026-10-31 · 4 小时',
    national: 785,
    anchors: [[0.2, 0.75], [0.4, 0.45]],
    bands: [
      { pct: 0.2, label: '省一', tone: 'prov1' },
      { pct: 0.45, label: '省二', tone: 'silver' },
      { pct: 0.75, label: '省三', tone: 'bronze' },
    ],
    note: '2025 赛季：陕西 S 组 785 人参赛、一等线 100 分、157 人、二等线 30 分，不设三等',
  },
  {
    id: 'noip', week: 12, name: 'NOIP', short: 'NOIP',
    kind: 'contest', group: 'S', levels: [3, 4, 5, 6], minutes: 270, days: 1,
    // 历年 NOIP：T1 提高-、T2 提高、T3 提高+、T4 省选
    ranges: [[58, 72], [62, 78], [72, 86], [86, 100]],
    // 校准：NOIP 2025 陕西一等线 128（≈32%）、二等 95、三等 86；强选手 ~67%（270 分）
    curve: [[0, 0], [0.15, 0.28], [0.3, 0.5], [0.4, 0.62], [0.5, 0.72], [0.65, 0.85], [1, 1]],
    gate: 'csp2', gateText: 'CSP-S 二等及以上（限高中生）', advanceText: '一等进省选 / WC 名单',
    clock: '2026-11-29 · 4.5h',
    national: 7725,
    anchors: [[0.215, 0.67], [0.27, 0.42], [0.3425, 0.2]],
    bands: [
      { pct: 0.2, label: 'NOIP 一等', tone: 'prov1' },
      { pct: 0.42, label: 'NOIP 二等', tone: 'silver' },
      { pct: 0.67, label: 'NOIP 三等', tone: 'bronze' },
    ],
    note: '全国高中生参赛约 7,725 人（一等 1,545 人 ÷ 20%）；基准线 137/108/86',
  },
  {
    id: 'wc', week: 16, name: 'WC 冬令营', short: 'WC',
    kind: 'contest', group: 'OPEN', levels: [5, 6, 7], minutes: 300, days: 1,
    // WC 学生营员测试：省选 ~ NOI-
    ranges: [[78, 90], [85, 98], [92, 108]],
    // 校准：WC2025 银线 257/300、铜线 211；陕西仅 6 人获奖（167–240 分）
    curve: [[0, 0], [0.1, 0.35], [0.2, 0.6], [0.35, 0.82], [0.5, 0.92], [1, 1]],
    gate: 'noip', gateText: 'NOIP 一等（省推荐名额）', advanceText: '测试排名，不评奖',
    clock: '2027-02 · 青岛 · 冬令营测试',
    national: 300, anchors: [[0.15, 0.9], [0.35, 0.5], [0.55, 0.1]], bands: [],
    note: '学生营员测试不评金银铜；国家队从国家集训队（NOI 前 50）里选拔',
  },
  {
    id: 'prov', week: 21, name: '省选（两试）', short: '省选',
    kind: 'contest', group: 'OPEN', levels: [4, 5, 6], minutes: 270, days: 2,
    // 省选两试：T1 提高+、T2 省选-、T3 省选/NOI
    ranges: [[62, 76], [76, 90], [88, 102]],
    // 校准：省选两试合计 600 分，陕西最高约 350–400、省队线约 300
    curve: [[0, 0], [0.3, 0.4], [0.5, 0.62], [0.65, 0.78], [0.8, 0.9], [1, 1]],
    gate: 'noip', gateText: 'NOIP 正式选手（非高三）', advanceText: '省队 17 个名额：A 类 5 + B 类 12（上限）',
    clock: '2027-03 上旬 · 两试',
    national: 160, anchors: [[0.2, 0.5], [0.27, 0.2], [0.32, 0.05]], bands: [],
    note: '总分 = NOIP 标准分×30% + 省选标准分×70%；单校不得超过省队名额的 1/3（17 个名额 → 我校最多 5 人）',
  },
  {
    id: 'apio', week: 26, name: 'APIO', short: 'APIO',
    kind: 'contest', group: 'OPEN', levels: [4, 5, 6], minutes: 300, days: 1,
    // APIO 中国区：省选 ~ NOI-
    ranges: [[72, 86], [82, 96], [90, 106]],
    // 校准：APIO2025 中国区 300 分、金 193 / 银 130 / 铜 80
    curve: [[0, 0], [0.3, 0.42], [0.45, 0.55], [0.6, 0.7], [0.8, 0.88], [1, 1]],
    gate: 'prov', gateText: '进入省队', advanceText: '亚太赛金银铜',
    clock: '2027-05 · 中国区',
    national: 600, anchors: [[0.267, 0.517], [0.433, 0.258], [0.643, 0.086]],
    bands: [
      { pct: 0.086, label: '金牌', tone: 'gold' },
      { pct: 0.258, label: '银牌', tone: 'silver' },
      { pct: 0.517, label: '铜牌', tone: 'bronze' },
    ],
    note: 'APIO2025 中国区 744 位师生、金牌 64 / 银 128 / 铜 193（线 193/130/80）',
  },
  {
    id: 'noi', week: 32, name: 'NOI（两试）', short: 'NOI',
    kind: 'contest', group: 'OPEN', levels: [5, 6, 7], minutes: 300, days: 2,
    // NOI 两试：NOI ~ NOI+
    ranges: [[85, 96], [92, 104], [98, 112]],
    // 校准：NOI2025 满分 705 = 笔试 100 + 两试 300×2 + A 类 5；本作按 700 分制（不含 A 类加分）
    curve: [[0, 0], [0.1, 0.3], [0.2, 0.55], [0.3, 0.75], [0.45, 0.88], [1, 1]],
    gate: 'prov', gateText: '进入省队', advanceText: '全国赛金银铜（初中生只能进夏令营）',
    clock: '2027-07 · 两试',
    national: 337, anchors: [[0.25, 0.85], [0.4, 0.6], [0.55, 0.148]],
    bands: [
      { pct: 0.148, label: '金牌', tone: 'gold' },
      { pct: 0.6, label: '银牌', tone: 'silver' },
      { pct: 0.85, label: '铜牌', tone: 'bronze' },
    ],
    note: '正式选手约 337 人（获奖 287 ÷ 85%）：金 50 / 银 152 / 铜 85；总分 = 笔试 100 + 两试各 300；铜牌还要求 ≥100 分',
  },
  {
    id: 'ctt', week: 34, name: 'CTT 国家集训队集训', short: 'CTT',
    kind: 'contest', group: 'OPEN', levels: [5, 6, 7], minutes: 300, days: 2,
    // 集训队测试：NOI 金 ~ IOI 级
    ranges: [[65, 78], [72, 85], [78, 92]],
    curve: [[0, 0], [0.1, 0.3], [0.25, 0.55], [0.45, 0.78], [0.65, 0.9], [1, 1]],
    gate: 'noi', gateText: 'NOI 金牌（国家集训队）', advanceText: '前 30 名进 CTS',
    clock: '2027-07 下旬 · 两试',
    national: 50, anchors: [[0.2, 0.85], [0.5, 0.55], [0.8, 0.2]], bands: [],
    note: 'NOI 金牌约 50 人进入国家集训队；CTT 测试后取前 30 名进入 CTS',
  },
  {
    id: 'cts', week: 37, name: 'CTS 国家队选拔', short: 'CTS',
    kind: 'contest', group: 'OPEN', levels: [6, 7, 7], minutes: 300, days: 2,
    // 国家队选拔：IOI 级；六属性删除后按引擎可达区间压一档
    ranges: [[65, 78], [72, 85], [78, 92]],
    curve: [[0, 0], [0.08, 0.25], [0.2, 0.5], [0.4, 0.75], [0.62, 0.9], [1, 1]],
    gate: 'ctt', gateText: 'CTT 前 30 名', advanceText: '前 4 名进 IOI 国家队',
    clock: '2027-08 上旬 · 两试',
    national: 30, anchors: [[0.15, 0.9], [0.45, 0.6], [0.75, 0.25]], bands: [],
    note: '从 CTT 前 30 名中选拔 4 人组成国家队；前 4 名进入 IOI',
  },
  {
    id: 'ioi', week: 40, name: 'IOI 国际信息学奥林匹克', short: 'IOI',
    kind: 'contest', group: 'OPEN', levels: [6, 7, 7], minutes: 300, days: 2,
    // IOI：国家队 4 人，国际赛难度；同样按引擎可达区间校准
    ranges: [[75, 88], [82, 95], [88, 102]],
    curve: [[0, 0], [0.08, 0.3], [0.2, 0.58], [0.4, 0.82], [0.62, 0.93], [1, 1]],
    gate: 'cts', gateText: 'CTS 前 4 名（国家队）', advanceText: '国际赛金银铜',
    clock: '2027-08 中旬 · 两试',
    national: 4, anchors: [[0.25, 0.9], [0.5, 0.65], [0.75, 0.35]], bands: [
      { pct: 0.25, label: '金牌', tone: 'gold' },
      { pct: 0.5, label: '银牌', tone: 'silver' },
      { pct: 1, label: '铜牌', tone: 'bronze' },
    ],
    note: '中国队 4 人出征；按 4 人内部排名发金/银/铜（简化）',
  },
];

/** 初赛：陕西 2025 S 线 37 分，全国分位来自官方指导线 */
export const PRELIM_NATIONAL_S = 34400;
/** 官方指导线：37 分 = 全国 80% 位次；62.5 分 = 前 25% */
export const PRELIM_ANCHORS_S: [number, number][] = [[0.37, 0.8], [0.625, 0.25]];

/** 在锚点之间线性插值出「全国前多少比例」；两端补 (0, 100%) 和 (满分, 1%) */
export function pctFromAnchors(anchors: [number, number][], ratio: number): number {
  const pts = ([[0, 1], ...anchors, [1, 0.01]] as [number, number][]).sort((a, b) => a[0] - b[0]);
  const r = Math.max(0, Math.min(1, ratio));
  for (let i = 1; i < pts.length; i++) {
    const [r0, p0] = pts[i - 1];
    const [r1, p1] = pts[i];
    if (r <= r1) {
      const t = r1 === r0 ? 0 : (r - r0) / (r1 - r0);
      return Math.max(0.005, Math.min(1, p0 + (p1 - p0) * t));
    }
  }
  return 0.01;
}

export function stageOfWeek(week: number): StageDef | null {
  return YEAR_STAGES.find((s) => s.week === week) ?? null;
}

/** 下一场比赛（含本周） */
export function nextStage(s: SeasonState): StageDef | null {
  return YEAR_STAGES.find((st) => st.week >= s.week) ?? null;
}

export type WeekIntensity = 'normal' | 'extra' | 'rest';
export type SeasonPhase = 'team' | 'plan' | 'report' | 'result' | 'finished';

export interface SeasonStudent {
  name: string;
  skills: Skills;
  startSkills: Skills;
  /** 初一 ~ 高三（1–3 初中，4–6 高中） */
  grade: Grade;
  /** 本学年开始时的综合与排名 */
  startOverall: number;
  startRank: number;
  /** 0-100 的疲劳 */
  fatigue: number;
  /** 个体天赋 1.0-1.3，决定同样训练涨多快 */
  talent: number;
  onTeam: boolean;
  /** 哪一年入校（1..3，转年新生） */
  joined: number;
  // ===== 本学年资格链（每年 6 月清空）=====
  csp1?: { score: number; passed: boolean };
  csp2?: { score: number; rank: number; award: 0 | 1 | 2 | 3 };
  noip?: { score: number; rank: number; first: boolean };
  wc?: { score: number; medal: 0 | 1 | 2 | 3 };
  prov?: { score: number; rank: number; first: boolean; team: boolean };
  apio?: { score: number; medal: 0 | 1 | 2 | 3 };
  noi?: { score: number; medal: 0 | 1 | 2 | 3 };
  ctt?: { score: number; rank: number; selected: boolean };
  cts?: { score: number; rank: number; selected: boolean };
  ioi?: { score: number; medal: 0 | 1 | 2 | 3 };
}

export interface WeekPlan {
  topic: Topic | null;
  intensity: WeekIntensity;
  /** 校内模拟赛配置：难度档 / 题数 / 时长 */
  mock?: MockConfig;
}

export type MockPreset = 'easy' | 'normal' | 'hard';

export interface MockConfig {
  preset: MockPreset;
  problemCount: number;
  minutes: number;
}

export const MOCK_PRESETS: Record<MockPreset, { name: string; levels: number[]; note: string }> = {
  easy: { name: '基础', levels: [1, 2, 3], note: '普及- ~ 普及，练手' },
  normal: { name: '提高', levels: [3, 4, 5], note: '普及+ ~ 提高+，常规' },
  hard: { name: '冲刺', levels: [4, 5, 6], note: '提高+ ~ 省选-，赛前冲刺' },
};

export interface TrainingLine {
  name: string;
  text: string;
  tone: 'good' | 'ok' | 'flat' | 'bad';
  fatigue: number;
}

export interface TrainingReport {
  week: number;
  plan: WeekPlan;
  lines: TrainingLine[];
}

export type ContestKind = 'practice' | 'prelim' | 'official';

export interface AwardRow {
  name: string;
  label: string;
  tone: 'gold' | 'silver' | 'bronze' | 'prov1' | 'team';
}

export interface ContestRecap {
  year: number;
  week: number;
  kind: ContestKind;
  stageId?: StageId;
  title: string;
  levels: number[];
  minutes: number;
  days: number;
  rows: StudentResult[];
  fullScore: number;
  problems: Problem[];
  /** 初赛成绩（只有 kind==='prelim'） */
  prelim?: {
    name: string; score: number; passed: boolean; onTeam: boolean;
    /** 全国排名（按分组全国人数折算） */
    nationalRank?: number; pct?: number;
  }[];
  /** 正赛的全国排名（参赛人数 × 得分分位） */
  national?: {
    total: number;
    rows: { name: string; score: number; rank: number; pct: number; award: string; team: boolean; note?: string; tone?: AwardRow['tone'] }[];
  };
  /** 官方赛事的奖项 / 头衔 */
  awards?: AwardRow[];
  /** 拿到下一阶段资格的人 */
  advanced?: string[];
  note?: string;
  cutoff?: number;
}

export interface YearSummary {
  year: number;
  team: string[];
  csp1Pass: number;
  csp2First: number;
  csp2Second: number;
  noipFirst: number;
  provTeam: number;
  wcGold: number;
  wcSilver: number;
  wcBronze: number;
  apioGold: number;
  apioSilver: number;
  apioBronze: number;
  noiGold: number;
  noiSilver: number;
  noiBronze: number;
  cttSelected: number;
  ctsSelected: number;
  ioiGold: number;
  ioiSilver: number;
  ioiBronze: number;
  avgOverallGain: number;
  graduates: string[];
}

export interface SeasonState {
  seed: number;
  careerYears: number;
  /** 第几个学年 1..careerYears */
  year: number;
  /** 当前周 1..YEAR_WEEKS；跑完最后一周变 YEAR_WEEKS + 1 */
  week: number;
  phase: SeasonPhase;
  students: SeasonStudent[];
  team: string[];
  plan: WeekPlan | null;
  report: TrainingReport | null;
  lastContest: ContestRecap | null;
  /** 本学年的比赛记录 */
  contests: ContestRecap[];
  /** 上周的队伍（新学年"沿用上季阵容"用） */
  lastTeam: string[];
  /** 本学年毕业的高三学生（选队页展示） */
  graduates: { name: string; grade: Grade; overall: number }[];
  /** 本学年新入学的高一新生 */
  newcomers: string[];
  /** 历年总结 */
  history: YearSummary[];
  // ===== 每周插曲（沿用 M1）=====
  pendingEvent: PendingEvent | null;
  eventLog: EventLogEntry[];
  lastEventResult: string | null;
  weekMult: number;
}

export interface EventLogEntry {
  week: number;
  year: number;
  id: string;
  title: string;
  choice: string;
  log: string;
}

// ===== 小工具 =====
const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));
const cloneSkills = (s: Skills): Skills => JSON.parse(JSON.stringify(s)) as Skills;

/** 综合分 0-100：八专题为主，coding / debug 加权两成 */
export function overallOf(s: Skills): number {
  const topicAvg = TOPIC_LIST.reduce((a, t) => a + s.topics[t], 0) / TOPIC_LIST.length;
  return Math.round((topicAvg * 0.8 + s.coding * 0.12 + s.debug * 0.08) * 1000) / 10;
}

/** 选手当前综合分（由技能现算，不是独立属性） */
export function overallScoreOf(st: SeasonStudent): number {
  return overallOf(st.skills);
}

function contestSkills(st: SeasonStudent): Skills {
  const f = st.fatigue / 100;
  const k = 1 - 0.18 * Math.pow(f, 1.3);
  const topics = {} as Record<Topic, number>;
  for (const t of TOPIC_LIST) topics[t] = clamp(st.skills.topics[t] * k, 0.03, 0.99);
  return {
    ...st.skills,
    topics,
    coding: clamp(st.skills.coding * k, 0.03, 0.99),
    debug: clamp(st.skills.debug * k, 0.03, 0.99),
  };
}

/** 近似正态（Irwin–Hall，4 个均匀分布），sd ≈ 0.577 */
function gauss(rng: () => number): number {
  return (rng() + rng() + rng() + rng() - 2) * 1.732;
}

// ===== 年级分配 =====
/**
 * 初始年级：优先用 data/年级对照表.txt 填的；没填的人按种子打散，
 * 保证高一/高二/高三都有人（否则一个 3 年周期没法玩）。
 */
function assignGrades(names: string[], seed: number): Map<string, Grade> {
  const out = new Map<string, Grade>();
  const unknown: string[] = [];
  for (const n of names) {
    const g = GRADES_BY_NAME[n];
    if (g === 1 || g === 2 || g === 3 || g === 4 || g === 5 || g === 6) out.set(n, g as Grade);
    else unknown.push(n);
  }
  const rng = makeRng((seed * 6151 + 11) >>> 0);
  const pool = unknown.slice();
  for (let i = pool.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
  }
  // 默认分布：初中 3 级共约 46%，高中 3 级共约 54%（真实校队低年级更多）
  const weights = [0.17, 0.15, 0.14, 0.2, 0.18, 0.16];
  const n = pool.length;
  const counts = weights.map((w) => Math.max(4, Math.round(n * w)));
  let cursor = 0;
  for (let g = 1; g <= 6; g++) {
    for (let k = 0; k < counts[g - 1] && cursor < n; k++, cursor++) {
      out.set(pool[cursor], g as Grade);
    }
  }
  while (cursor < n) { out.set(pool[cursor], 4); cursor++; }
  return out;
}

/** 新高一学生：拿现有模板按目标综合缩放，名字随机组合 */
const SURNAMES = ['张', '王', '李', '刘', '陈', '杨', '赵', '黄', '周', '吴', '徐', '孙', '马', '朱', '胡', '郭', '何', '高', '林', '罗'];
const GIVEN = ['子轩', '浩然', '雨桐', '思远', '嘉怡', '宇航', '若曦', '博文', '一鸣', '晨曦', '可欣', '天佑', '语桐', '泽宇', '欣怡', '沐辰', '雨泽', '砚清'];

function makeNewcomer(idx: number, year: number, seed: number, template: CohortEntry, grade: Grade = 1): SeasonStudent {
  const rng = makeRng((seed * 7717 + year * 911 + idx * 131 + 7) >>> 0);
  const name = `${SURNAMES[Math.floor(rng() * SURNAMES.length)]}${GIVEN[Math.floor(rng() * GIVEN.length)]}`;
  const target = clamp(0.28 + rng() * 0.42, 0.2, 0.75);
  const base = overallOf(template.skills) || 40;
  const k = target / base;
  const skills = cloneSkills(template.skills);
  const topics = {} as Record<Topic, number>;
  for (const t of TOPIC_LIST) topics[t] = clamp(skills.topics[t] * k, 0.05, 0.75);
  const scaled: Skills = {
    ...skills,
    topics,
    coding: clamp(skills.coding * k, 0.05, 0.75),
    debug: clamp(skills.debug * k, 0.05, 0.75),
    reading: clamp(skills.reading * k, 0.05, 0.75),
  };
  return {
    name,
    skills: scaled,
    startSkills: cloneSkills(scaled),
    grade,
    startOverall: overallOf(scaled),
    startRank: 0,
    fatigue: 0,
    talent: 0.85 + rng() * 0.3,
    onTeam: false,
    joined: year,
  };
}

// ===== 开局 =====
export function createSeason(seed: number, careerYears = CAREER_YEARS): SeasonState {
  const career = Math.max(1, Math.min(CAREER_YEARS, careerYears));
  const cohort = buildCohort(seed >>> 0);
  const rng = makeRng((seed * 7919 + 17) >>> 0);
  const grades = assignGrades(cohort.map((e) => e.name), seed >>> 0);
  const students: SeasonStudent[] = cohort.map((e) => {
    const over = PROFILE_BY_NAME[e.name];
    const skills = cloneSkills(e.skills);
    // 属性表只保留 topics / 代码·阅读·调试 / 年级 / 天赋
    if (over) {
      if (over.topics) for (const [k, v] of Object.entries(over.topics)) skills.topics[k as Topic] = v as number;
      if (over.meta) Object.assign(skills, over.meta);
    }
    // 天赋表填了就用表里的，没填沿用种子随机；随机数照常消耗，保证没填的人结果不变
    const talentRoll = 0.85 + rng() * 0.3;
    return {
      name: e.name,
      skills,
      startSkills: cloneSkills(skills),
      grade: over?.grade ?? grades.get(e.name) ?? 4,
      startOverall: overallOf(skills),
      startRank: 0,
      fatigue: 0,
      talent: over?.talent ?? TALENT_BY_NAME[e.name] ?? talentRoll,
      onTeam: false,
      joined: 1,
    };
  });
  rankStudents(students);
  return {
    seed: seed >>> 0,
    careerYears: career,
    year: 1,
    week: 1,
    phase: 'team',
    students,
    team: [],
      plan: null,
    report: null,
    lastContest: null,
    contests: [],
    lastTeam: [],
    graduates: [],
    newcomers: [],
    history: [],
    pendingEvent: null,
    eventLog: [],
    lastEventResult: null,
    weekMult: 1,
  };
}

function meanDifficulty(problems: Problem[]): number {
  if (!problems.length) return 60;
  return problems.reduce((a, p) => a + p.difficulty, 0) / problems.length;
}

/**
 * 赛后成长：题目平均难度与选手水平越接近（略高于水平 6 分左右）涨得越多，
 * 太简单或太难都涨得少。比赛成长写进对应专题（不再维护“实力”字段）。
 */
function growFromContest(
  st: SeasonStudent, meanDiff: number, problemCount: number, scale: number, topics: Set<Topic>,
): SeasonStudent {
  const gap = meanDiff - overallOf(st.skills);
  const match = clamp(1 - Math.abs(gap - 6) / 45, 0.12, 1);
  const gain = scale * match * clamp(problemCount / 4, 0.5, 1.5);
  const skills: Skills = { ...st.skills, topics: { ...st.skills.topics } };
  for (const t of topics) skills.topics[t] = clamp(skills.topics[t] + gain * 0.55, 0.03, 0.9986);
  return { ...st, skills };
}

function rankStudents(students: SeasonStudent[]) {
  students.forEach((st) => { st.startOverall = overallOf(st.skills); });
  students.slice().sort((a, b) => b.startOverall - a.startOverall).forEach((st, i) => { st.startRank = i + 1; });
}

export function setTeam(s: SeasonState, names: string[]): SeasonState {
  // 队伍人数上不封顶：教练愿意带多少人带多少人（成长会按人数稀释）
  const uniq = [...new Set(names)].filter((n) => s.students.some((st) => st.name === n));
  return withEvent({
    ...s,
    team: uniq,
      phase: 'plan',
    students: s.students.map((st) => ({ ...st, onTeam: uniq.includes(st.name) })),
  });
}

export function teamStudents(s: SeasonState): SeasonStudent[] {
  return s.team
    .map((n) => s.students.find((st) => st.name === n))
    .filter((x): x is SeasonStudent => Boolean(x));
}

// ===== 随机事件（每周一个，排训练前处理） =====
/** 每周出事件的概率：一学年 40 周大约 25 次 */
const EVENT_CHANCE = 0.62;

function rollWeekEvent(s: SeasonState): PendingEvent | null {
  if (!s.team.length) return null;
  const rng = makeRng((s.seed * 8191 + s.year * 104729 + s.week * 7331 + 3) >>> 0);
  if (rng() > EVENT_CHANCE) return null;

  const lastId = s.eventLog[s.eventLog.length - 1]?.id ?? null;
  let pool = EVENT_DEFS.slice();
  if (pool.length > 1) pool = pool.filter((d) => d.id !== lastId);

  const total = pool.reduce((a, d) => a + d.weight, 0);
  let r = rng() * total;
  let def = pool[pool.length - 1];
  for (const d of pool) {
    r -= d.weight;
    if (r <= 0) { def = d; break; }
  }
  const target = def.needsTarget ? s.team[Math.floor(rng() * s.team.length)] ?? null : null;
  return {
    id: def.id,
    week: s.week,
    tag: def.tag,
    title: def.title,
    text: def.text.replace('{name}', target ?? '一个队员'),
    target,
    options: def.options.map((o) => ({ id: o.id, label: o.label, note: o.note })),
  };
}

function withEvent(s: SeasonState): SeasonState {
  if (s.phase !== 'plan') return s;
  const ev = rollWeekEvent(s);
  return { ...s, pendingEvent: ev, lastEventResult: null };
}

function applyPatch(st: SeasonStudent, p: StudentPatch): SeasonStudent {
  const skills = cloneSkills(st.skills);
  if (p.topics) {
    for (const [t, d] of Object.entries(p.topics)) {
      const topic = t as Topic;
      skills.topics[topic] = clamp(skills.topics[topic] + (d ?? 0), 0.05, 0.99);
    }
  }
  return {
    ...st,
    skills,
    fatigue: clamp(st.fatigue + (p.fatigue ?? 0), 0, 100),
  };
}

export function chooseEventOption(s: SeasonState, optionId: string): SeasonState {
  const pending = s.pendingEvent;
  if (!pending) return s;
  const def = eventDefById(pending.id);
  const opt = def?.options.find((o) => o.id === optionId);
  if (!def || !opt) return s;

  const rng = makeRng((s.seed * 2654435761 + s.year * 31397 + pending.week * 131 + optionId.length * 17) >>> 0);
  const patch = opt.apply(s, pending.target, rng);
  const students = s.students.map((st) => {
    if (!st.onTeam) return st;
    if (pending.target && st.name === pending.target && patch.target) return applyPatch(st, patch.target);
    if (patch.team) return applyPatch(st, patch.team);
    return st;
  });

  return {
    ...s,
    students,
    pendingEvent: null,
    weekMult: s.weekMult * (patch.growthMult ?? 1),
    lastEventResult: patch.log,
    eventLog: [
      ...s.eventLog,
      { year: s.year, week: pending.week, id: pending.id, title: pending.title, choice: opt.label, log: patch.log },
    ],
  };
}

// ===== 一周训练 =====
const INTENSITY_GAIN: Record<WeekIntensity, number> = { normal: 5, extra: 14, rest: -38 };
const INTENSITY_K: Record<WeekIntensity, number> = { normal: 0.7, extra: 1.2, rest: 0 };
const TRAIN_BASE = 0.18;

function reportOf(growth: number, fatigue: number, intensity: WeekIntensity): { text: string; tone: TrainingLine['tone'] } {
  if (intensity === 'rest') {
    return { text: fatigue > 55 ? '休息了一周，缓过来一些' : '这周放松，状态拉满', tone: 'ok' };
  }
  let base: string;
  let tone: TrainingLine['tone'];
  if (growth >= 0.05) { base = '这周练透了，专题明显上了一个台阶'; tone = 'good'; }
  else if (growth >= 0.026) { base = '稳步在涨，手感不错'; tone = 'good'; }
  else if (growth >= 0.011) { base = '有点进步，但不算多'; tone = 'ok'; }
  else if (growth >= 0.004) { base = '基本原地踏步'; tone = 'flat'; }
  else { base = '几乎没吸收进去，像白练了一周'; tone = 'bad'; }
  if (fatigue >= 78) base += '，不过人已经很疲惫了';
  else if (fatigue >= 58) base += '，人有点累';
  return { text: base, tone };
}

export function planWeek(s: SeasonState, plan: WeekPlan): SeasonState {
  const rng = makeRng((s.seed * 131 + s.year * 7919 + s.week * 977 + 1) >>> 0);
  const k = INTENSITY_K[plan.intensity];
  const gain = INTENSITY_GAIN[plan.intensity];
  const lines: TrainingLine[] = [];

  // 带的人越多，每人分到的教练注意力越少（6 人满额，按 0.6 次方稀释，最少 0.2）
  const sizePenalty = Math.max(0.2, Math.pow(TEAM_MIN / Math.max(TEAM_MIN, s.team.length), 0.6));
  const students = s.students.map((st) => {
    const skills = cloneSkills(st.skills);
    let growth = 0;
    let trainedTopic: Topic | null = null;
    if (k > 0) {
      trainedTopic = st.onTeam && plan.topic ? plan.topic : TOPIC_LIST[Math.floor(rng() * TOPIC_LIST.length)] ?? null;
      if (trainedTopic) {
        const cur = skills.topics[trainedTopic];
        const attention = st.onTeam ? 1 : 0.35;
        growth = (1 - cur) * TRAIN_BASE * k * attention * sizePenalty * st.talent;
        growth *= 0.6 + rng() * 0.8;
        growth *= s.weekMult;
        skills.topics[trainedTopic] = clamp(cur + growth, 0.05, 0.99);
        skills.coding = clamp(skills.coding + growth * 0.12, 0.05, 0.99);
        skills.debug = clamp(skills.debug + growth * 0.1, 0.05, 0.99);
      }
    }
    const fatigue = clamp(st.fatigue + gain, 0, 100);
    if (st.onTeam) {
      const r = reportOf(growth, fatigue, plan.intensity);
      lines.push({ name: st.name, text: r.text, tone: r.tone, fatigue });
    }
    return { ...st, skills, fatigue };
  });

  return {
    ...s,
    students,
    plan,
    report: { week: s.week, plan, lines },
    phase: 'report',
    weekMult: 1,
  };
}

// ===== 比赛引擎 =====
function runOneDay(cohort: CohortEntry[], levels: number[], minutes: number, seed: number, ranges?: [number, number][], trace?: ContestRound[], label?: string, curve?: [number, number][]) {
  const cfg = {
    preset: 'season-week',
    problemCount: levels.length,
    levels,
    studentCount: cohort.length,
    minutes,
    seed,
    cohort,
    difficultyRanges: ranges,
    scoreCurve: curve,
  };
  if (trace) trace.push({ label: label ?? '比赛', cfg });
  const contest = createContest(cfg);
  let guard = 0;
  while (!contest.isFinished && guard++ < 20000) tick(contest, 60);
  return { rows: finalize(contest), problems: contest.problems as Problem[] };
}

function mergeDays(runs: { rows: StudentResult[]; problems: Problem[] }[], fullScore: number): StudentResult[] {
  const offsets: number[] = [];
  let acc = 0;
  for (const r of runs) { offsets.push(acc); acc += r.problems.length; }

  const byName = new Map<string, StudentResult>();
  runs.forEach((run, i) => {
    const off = offsets[i] ?? 0;
    for (const row of run.rows) {
      const perProblem = row.perProblem.map((pr) => ({ ...pr, problemId: pr.problemId + off }));
      const prev = byName.get(row.name);
      if (!prev) {
        byName.set(row.name, { ...row, perProblem });
      } else {
        prev.real += row.real;
        prev.est += row.est;
        prev.delta = prev.real - prev.est;
        prev.perProblem = [...prev.perProblem, ...perProblem];
      }
    }
  });

  const rows = [...byName.values()];
  rows.sort((a, b) => b.real - a.real);
  rows.forEach((r, i) => { r.rank = i + 1; });
  const byEst = rows.slice().sort((a, b) => b.est - a.est);
  byEst.forEach((r, i) => { r.estRank = i + 1; });
  for (const r of rows) {
    r.rankDelta = r.estRank - r.rank;
    r.calibration = clamp(100 - (Math.abs(r.delta) / fullScore) * 100, 0, 100);
  }
  return rows;
}

/** 初赛分数：阅读程序 / 完善程序 + 一点实现手感，100 分制 */
const PRELIM_LINE = 37;
/** 初中组（J 组）初赛线：卷子更容易，线反而略高（陕西 2025：J 37.5 / S 37） */
const PRELIM_JUNIOR_LINE = 37.5;

/**
 * 初赛 = 笔试（选择/阅读程序/完善程序），直接出分，不套比赛引擎。
 * 卷面能力 ≈ 阅读程序 + 代码基础 + 年级经验；J 卷更基础，S 卷多算法阅读。
 * 校准目标（回归测试会卡）：NOI 银牌级 J ≥95、S ≥92；高二中游 J ≈85、S ≈80；初三 J ≈65。
 */
function prelimPaperScore(st: SeasonStudent, rng: () => number): number {
  const sk = st.skills;
  const exp = (st.grade - 1) / 5;
  // 原来 13% 的“心态”权重已删除，按中性规则并入阅读（+8%）和代码（+5%）。
  const ability = 0.53 * clamp(sk.reading, 0, 1) + 0.37 * clamp(sk.coding, 0, 1) + 0.10 * exp;
  // 陕西 2025 官方线 37 分 ≈ 全国前 20%，62.5 分 ≈ 省前 25%；按能力线性映射，弱一些的学生就是过不了线
  const base = clamp((ability - 0.53) / 0.42, 0, 1);
  const noise = gauss(rng) * 3.2;
  const fatiguePenalty = Math.min(4, (st.fatigue / 100) * 4);
  return clamp(Math.round(clamp(base, 0, 1) * 100 + noise - fatiguePenalty), 0, 100);
}

const ratioLine = (n: number, p: number) => Math.max(1, Math.round(n * p));

function bumpFatigue(s: SeasonState, dayCount: number): SeasonState {
  return {
    ...s,
    students: s.students.map((st) => ({
      ...st,
      fatigue: clamp(st.fatigue + (st.onTeam ? 8 : 5) * dayCount, 0, 100),
    })),
  };
}

/** 校内模拟赛：难度档/题数/时长由教练在排训练时选（不计正式成绩，只给成长和反馈） */
function runPractice(s: SeasonState, trace?: ContestRound[]): SeasonState {
  const week = s.week;
  const mock = s.plan?.mock ?? { preset: 'normal' as MockPreset, problemCount: 3, minutes: 180 };
  const baseLevels = MOCK_PRESETS[mock.preset].levels;
  const count = clamp(mock.problemCount, 1, 6);
  const levels = Array.from({ length: count }, (_, i) => baseLevels[Math.min(baseLevels.length - 1, Math.floor((i * baseLevels.length) / count))]);
  const minutes = clamp(mock.minutes, 60, 300);
  const cohort: CohortEntry[] = s.students.map((st) => ({
    name: st.name,
    skills: contestSkills(st),
    fatigue: Math.min(0.68, (st.fatigue / 100) * 0.55),
  }));
  const fullScore = levels.length * 100;
  const run = runOneDay(cohort, levels, minutes, (s.seed * 31 + s.year * 6151 + week * 7919 + 5) >>> 0, undefined, trace, `校内模拟赛 · ${count} 题 · ${minutes} 分钟（${MOCK_PRESETS[mock.preset].name}）`);
  const topics = new Set(run.problems.map((p) => p.topic));
  const meanDiff = meanDifficulty(run.problems);
  const grown = s.students.map((st) => growFromContest(st, meanDiff, run.problems.length, 0.016, topics));
  const recap: ContestRecap = {
    year: s.year, week, kind: 'practice', title: `第 ${week} 周 · 校内模拟赛（${MOCK_PRESETS[mock.preset].name}）`,
    levels, minutes, days: 1, rows: run.rows, fullScore, problems: run.problems,
    note: `模拟赛 ${count} 题 · ${minutes} 分钟 · ${MOCK_PRESETS[mock.preset].note}；不计正式成绩，难度和水平匹配时成长最多`,
  };
  return {
    ...bumpFatigue({ ...s, students: grown }, 1),
    week: week + 1,
    phase: 'result',
    lastContest: recap,
    contests: [...s.contests, recap],
  };
}

/**
 * 初赛（笔试）：全校一张卷，直接出分（不用比赛引擎）。
 * 过线才能进 CSP 第二轮；初中生也可以考，但 NOIP 起只限高中生。
 */
function runPrelim(s: SeasonState, stage: StageDef): SeasonState {
  const week = s.week;
  const rows: NonNullable<ContestRecap['prelim']> = [];

  const students = s.students.map((st, i) => {
    const rngBase = (s.seed * 131 + s.year * 7331 + week * 991 + i * 17 + 3) >>> 0;
    const score = prelimPaperScore(st, makeRng((rngBase + 29) >>> 0));
    const passed = score >= PRELIM_LINE;
    const pct = pctFromAnchors(PRELIM_ANCHORS_S, score / 100);
    rows.push({
      name: st.name, score, passed, onTeam: st.onTeam,
      nationalRank: Math.max(1, Math.round(PRELIM_NATIONAL_S * pct)), pct,
    });
    return { ...st, csp1: { score, passed } };
  });

  const pass = rows.filter((r) => r.passed);
  const recap: ContestRecap = {
    year: s.year, week, kind: 'prelim', stageId: stage.id, title: stage.name,
    levels: [], minutes: stage.minutes, days: 1, rows: [], fullScore: 100, problems: [],
    prelim: rows,
    cutoff: PRELIM_LINE,
    advanced: pass.map((r) => r.name),
    national: {
      total: PRELIM_NATIONAL_S,
      rows: rows
        .slice()
        .sort((a, b) => b.score - a.score)
        .map((p) => ({
          name: p.name, score: p.score, rank: p.nationalRank ?? 0, pct: p.pct ?? 1,
          award: p.passed ? '过线' : '未过线',
          team: p.onTeam, note: 'S 卷',
        })),
    },
    note: `笔试直接出分：全校 ${rows.length} 人参加，陕西线 ${PRELIM_LINE} 分，过线 ${pass.length} 人。`,
  };
  return {
    ...s,
    students,
    week: week + 1,
    phase: 'result',
    lastContest: recap,
    contests: [...s.contests, recap],
  };
}

/** 按省线判奖：min 是该奖的最低分（满分按实际场次） */
interface ScoreLine { label: string; min: number; tone: AwardBand['tone'] }
function bandOfLines(lines: ScoreLine[], real: number): ScoreLine | null {
  for (const l of lines) if (real >= l.min) return l;
  return null;
}

/** 陕西 CSP-S 2025 第二轮官方一等线/名额（CCF 2025-11-14 评级通知）：
 *  157 人 / 100 分、二等 30 分，不设三等。参赛人数官方未公布，按 20% 一等率反推 ≈785。 */
const CSP2_GUIDE = {
  S: { total: 785, quota: 157, lines: [{ label: '省一', min: 100, tone: 'prov1' }, { label: '省二', min: 30, tone: 'silver' }] as ScoreLine[] },
};

/** 虚构外校/外省选手的分数分布池（满分按各赛事实际：CSP 400、NOIP 400、WC/APIO 300、NOI 700、CTT/CTS/IOI 700、省选总分 100 分制） */
export const FIELDS: Record<string, FieldSpec> = {
  'csp2.S': { total: 785, anchors: [{ q: 0, score: 400 }, { q: 0.2, score: 100 }, { q: 0.4, score: 30 }, { q: 1, score: 0 }] },
  noip: { total: 160, anchors: [{ q: 0, score: 300 }, { q: 0.2, score: 128 }, { q: 0.43, score: 95 }, { q: 0.49, score: 86 }, { q: 1, score: 0 }] },
  prov: { total: 79, anchors: [{ q: 0, score: 62 }, { q: 0.15, score: 55 }, { q: 0.5, score: 40 }, { q: 1, score: 5 }] },
  wc: { total: 500, anchors: [{ q: 0, score: 300 }, { q: 0.112, score: 285 }, { q: 0.386, score: 257 }, { q: 0.68, score: 211 }, { q: 1, score: 100 }] },
  apio: { total: 640, anchors: [{ q: 0, score: 290 }, { q: 0.1, score: 193 }, { q: 0.3, score: 130 }, { q: 0.6, score: 80 }, { q: 1, score: 0 }] },
  // NOI 2025：满分 705，本作 700（100 笔试 + 两试 600）；金 571 / 银 410 / 铜 320 按 700/705 折算；
  // 六属性删除后引擎两试顶分约 180，加笔试约 280/700，金线随之下调到 270，保证顶尖选手能进 CTT
  noi: { total: 338, anchors: [{ q: 0, score: 300 }, { q: 0.15, score: 270 }, { q: 0.5, score: 230 }, { q: 0.85, score: 175 }, { q: 1, score: 0 }] },
  // CTT/CTS/IOI 同样按引擎可达区间校准，保证 NOI 金牌能真正往后走
  ctt: { total: 50, anchors: [{ q: 0, score: 320 }, { q: 0.2, score: 280 }, { q: 0.6, score: 210 }, { q: 1, score: 80 }] },
  cts: { total: 30, anchors: [{ q: 0, score: 260 }, { q: 0.15, score: 245 }, { q: 0.45, score: 200 }, { q: 1, score: 100 }] },
  ioi: { total: 4, anchors: [{ q: 0, score: 300 }, { q: 0.25, score: 270 }, { q: 0.5, score: 230 }, { q: 0.75, score: 180 }, { q: 1, score: 100 }] },
};

/** 全国性赛事按名次名额发奖（NOI 338 人：金 50 / 银 152 / 铜 85；APIO 640：金 64 / 银 128 / 铜 193；WC 500：金 56 / 银 137 / 铜 147） */
export const NATIONAL_QUOTAS: Record<string, number[]> = {
  noi: [50, 202, 287],
  apio: [64, 192, 385],
  wc: [56, 193, 340],
  ioi: [1, 2, 4],
};

/** 陕西 NOIP 2025 官方线：一等 128（32 人）、二等 95（37）、三等 86（10） */
const NOIP_SSX = {
  total: 160,
  lines: [
    { label: 'NOIP 一等', min: 128, tone: 'prov1' },
    { label: 'NOIP 二等', min: 95, tone: 'silver' },
    { label: 'NOIP 三等', min: 86, tone: 'bronze' },
  ] as ScoreLine[],
  anchors: [[0.215, 0.494], [0.2375, 0.431], [0.32, 0.2]] as [number, number][],
};

/** APIO 2025 中国区线：金 193 / 银 130 / 铜 80（满分 300） */
const APIO_LINES: ScoreLine[] = [
  { label: '金牌', min: 193, tone: 'gold' },
  { label: '银牌', min: 130, tone: 'silver' },
  { label: '铜牌', min: 80, tone: 'bronze' },
];

/** 按全国分位找奖项档；NOI 铜牌还要求 ≥100 分 */
function bandOf(stage: StageDef, pct: number, real: number): AwardBand | null {
  for (const b of stage.bands) {
    if (pct > b.pct + 1e-9) continue;
    if (stage.id === 'noi' && b.label === '铜牌' && real < 100) return null;
    return b;
  }
  return null;
}

/** 复赛：4 题 4h，初赛过线的人全部参加（初中生也可考，NOIP 起才限高中生），按陕西官方省线判奖 */
function runCsp2(s: SeasonState, stage: StageDef, trace?: ContestRound[]): SeasonState {
  const week = s.week;
  const entrants = s.students.filter((st) => Boolean(st.csp1?.passed));

  const allRows: StudentResult[] = [];
  const allProblems: Problem[] = [];
  const awards: AwardRow[] = [];
  const advanced: string[] = [];
  const nationalRows: NonNullable<ContestRecap['national']>['rows'] = [];
  const teamSet = new Set(s.team);
  const info = new Map<string, { rank: number; award: 0 | 1 | 2 | 3; score: number }>();
  const ranAny = entrants.length > 0;

  if (ranAny) {
    const guide = CSP2_GUIDE.S;
    const cohort: CohortEntry[] = entrants.map((st) => ({
      name: st.name,
      skills: contestSkills(st),
      fatigue: Math.min(0.68, (st.fatigue / 100) * 0.55),
    }));
    const seedBase = (s.seed * 31 + s.year * 977 + week * 7919 + 5) >>> 0;
    const run = runOneDay(cohort, stage.levels, stage.minutes, seedBase, stage.ranges, trace,
      `${stage.levels.length} 题 · ${stage.minutes / 60} 小时`, stage.curve);
    allProblems.push(...run.problems);

    for (const r of run.rows) {
      allRows.push(r);
      // 省排名：陕西参赛池里比自己高的人数（官方只公布名额，池子按「线 = 第 quota 名」反推）
      const spec = FIELDS['csp2.S'];
      const rank = rankAmong(fieldScores(spec), r.real);
      const pct = pctOf(rank, spec.total);
      const line = bandOfLines(guide.lines, r.real);
      const awardNum: 0 | 1 | 2 | 3 = line ? (line.label.includes('省一') ? 1 : line.label.includes('省二') ? 2 : 3) : 0;
      info.set(r.name, { rank, award: awardNum, score: Math.round(r.real) });
      if (line) awards.push({ name: r.name, label: line.label, tone: line.tone });
      if (line && awardNum <= 2) advanced.push(r.name);
      nationalRows.push({
        name: r.name, score: Math.round(r.real), rank, pct,
        award: line?.label ?? '无奖', team: teamSet.has(r.name), note: 'S 组',
      });
    }
  }

  // 展示用的总排名按真分排（发奖用的是省排名/省线）
  allRows.sort((a, b) => b.real - a.real);
  allRows.forEach((r, i) => { r.rank = i + 1; });

  const meanDiff = meanDifficulty(allProblems);
  const topicSet = new Set(allProblems.map((p) => p.topic));
  const students = s.students.map((st) => {
    const it = info.get(st.name);
    if (!it) return { ...st, csp2: undefined };
    const next: SeasonStudent = { ...st, csp2: { score: it.score, rank: it.rank, award: it.award } };
    return growFromContest(next, meanDiff, 4, 0.018, topicSet);
  });

  const recap: ContestRecap = {
    year: s.year, week, kind: 'official', stageId: stage.id, title: stage.name,
    levels: stage.levels, minutes: stage.minutes, days: 1, rows: allRows, fullScore: 400, problems: allProblems,
    awards, advanced,
    national: { total: FIELDS['csp2.S'].total, rows: nationalRows },
    note: ranAny
      ? `初赛过线 ${entrants.length} 人参加（4 题 · 4h）；二等及以上进 NOIP 名单。陕西官方线：一等 100 分（157 人）、二等 30 分，不设三等`
      : '初赛没人过线，复赛报名表是空的',
  };
  return {
    ...bumpFatigue(s, 1),
    students,
    week: week + 1,
    phase: 'result',
    lastContest: recap,
    contests: [...s.contests, recap],
  };
}
/** 正式比赛：按真实资格链筛参赛者，跑完按全国分位排名发奖 */
function runStage(s: SeasonState, stage: StageDef, trace?: ContestRound[]): SeasonState {
  const week = s.week;

  // 各赛事的正式资格（口径来自 2025–26 赛季官方通知）
  const eligOfficial = (st: SeasonStudent) => {
    switch (stage.id) {
      case 'noip':
        return isSenior(st.grade) && (st.csp2?.award ?? 0) >= 1 && (st.csp2?.award ?? 0) <= 2;
      case 'wc':
        return isSenior(st.grade) && Boolean(st.noip?.first);
      case 'prov':
        return isSenior(st.grade) && st.noip !== undefined;
      case 'apio':
      case 'noi':
        return Boolean(st.prov?.team);
      case 'ctt':
        return st.noi?.medal === 1;
      case 'cts':
        return Boolean(st.ctt?.selected);
      case 'ioi':
        return Boolean(st.cts?.selected);
      default:
        return false;
    }
  };
  // 体验/夏令营名额：NOIP 的初中低年级后备体验、省选与 NOI 的初中体验，成绩不计奖
  const eligExperience = (st: SeasonStudent) => {
    switch (stage.id) {
      case 'noip':
        return isJunior(st.grade) && (st.csp2?.award ?? 0) >= 1;
      case 'prov':
      case 'noi':
        return isJunior(st.grade) && st.noip !== undefined;
      default:
        return false;
    }
  };

  const official = s.students.filter(eligOfficial);
  const experience = s.students.filter(eligExperience);
  const qualified = [...official, ...experience];
  const officialSet = new Set(official.map((st) => st.name));
  const experienceSet = new Set(experience.map((st) => st.name));
  const teamSet = new Set(s.team);

  if (!qualified.length) {
    const recap: ContestRecap = {
      year: s.year, week, kind: 'official', stageId: stage.id, title: stage.name,
      levels: stage.levels, minutes: stage.minutes, days: stage.days,
      rows: [], fullScore: stage.id === 'noi' ? 700 : stage.levels.length * 100 * stage.days, problems: [],
      note: `队里没有人拿到「${stage.gateText}」，这一场只能弃权`,
      awards: [], advanced: [],
    };
    return { ...s, week: week + 1, phase: 'result', lastContest: recap, contests: [...s.contests, recap] };
  }

  const cohort: CohortEntry[] = qualified.map((st) => ({
    name: st.name,
    skills: contestSkills(st),
    fatigue: Math.min(0.68, (st.fatigue / 100) * 0.55),
  }));
  // NOI 2025 正式总分 705：笔试 100 + 两试各 300 + A 类选手另加 5。
  // 这里不区分 A/B 类，按 700 分制（笔试 100 + 两试 600）计入总分。
  const fullScore = stage.id === 'noi' ? 700 : stage.levels.length * 100 * stage.days;
  const seedBase = (s.seed * 31 + s.year * 977 + week * 7919 + 5) >>> 0;
  const runs = Array.from({ length: stage.days }, (_, d) => runOneDay(cohort, stage.levels, stage.minutes, (seedBase + d * 1013) >>> 0, stage.ranges, trace, stage.days > 1 ? `${stage.short} · 第 ${d + 1} 试` : `${stage.short} · ${stage.levels.length} 题 · ${stage.minutes / 60} 小时`, stage.curve));
  const rows = stage.days > 1 ? mergeDays(runs, fullScore) : runs[0].rows;

  // NOI 另有 100 分笔试（计算机基础知识），单独出分后计入总分。
  // 用与初赛同一套阅读/代码/年级能力，但每个选手独立一次噪声，避免和两试估分绑死。
  if (stage.id === 'noi') {
    const written = new Map<string, number>();
    for (const st of qualified) {
      const nameSeed = [...st.name].reduce((acc, ch) => (acc * 131 + ch.charCodeAt(0)) >>> 0, 7);
      written.set(st.name, prelimPaperScore(st, makeRng((seedBase ^ nameSeed ^ 0x9e3779b9) >>> 0)));
    }
    for (const r of rows) {
      const w = written.get(r.name) ?? 0;
      r.written = w;
      r.real += w;
      r.est += w;
      r.delta = r.real - r.est;
    }
    rows.sort((a, b) => b.real - a.real);
    rows.forEach((r, i) => { r.rank = i + 1; });
    const byEst = rows.slice().sort((a, b) => b.est - a.est);
    byEst.forEach((r, i) => { r.estRank = i + 1; });
    for (const r of rows) {
      r.rankDelta = r.estRank - r.rank;
      r.calibration = clamp(100 - (Math.abs(r.delta) / fullScore) * 100, 0, 100);
    }
  }
  const problems: Problem[] = [];
  let pidOffset = 0;
  for (const r of runs) {
    for (const p of r.problems) problems.push({ ...p, id: p.id + pidOffset });
    pidOffset += r.problems.length;
  }

  // 省选：总分 = NOIP 标准分 30% + 省选标准分 70%（官方折算规则），按总分排省队
  // 标准化用「满分」而不是「校内最高分」，否则校队第一名永远排全省第一
  const PROV_TOP_RAW = 450; // 全省省选最高分（推算：约 75% 满分，官方不公布）
  const NOIP_TOP_RAW = 300; // 全省 NOIP 最高分（推算：2025 陕西最高分未公布）
  const provTotal = new Map<string, number>();
  if (stage.id === 'prov') {
    for (const r of rows) {
      const st = s.students.find((x) => x.name === r.name);
      // 官方标准分 = 本人 / 全省最高 × 100（不是除以满分）；全省最高用「我们的最高 vs 推算值」取大
      const noipStd = Math.min(1, (st?.noip?.score ?? 0) / NOIP_TOP_RAW) * 100;
      const provStd = Math.min(1, r.real / PROV_TOP_RAW) * 100;
      provTotal.set(r.name, (0.3 * noipStd + 0.7 * provStd) / 100);
    }
    rows.sort((a, b) => (provTotal.get(b.name) ?? 0) - (provTotal.get(a.name) ?? 0));
    rows.forEach((r, i) => { r.rank = i + 1; });
  }

  const nationalRows: NonNullable<ContestRecap['national']>['rows'] = [];
  const awards: AwardRow[] = [];
  const advanced: string[] = [];
  let schoolTeam = 0; // 单校不超过省队 1/3：17 个名额 → 我校最多 5 人
  let poolTotal = stage.national;

  for (const r of rows) {
    const isOfficial = officialSet.has(r.name);
    // 排名 = 该赛事分数池里比自己高的人数 + 1（省选按 NOIP 30% + 省选 70% 的总分池排）
    const spec = FIELDS[stage.id] ?? FIELDS.noip;
    const mine = stage.id === 'prov' ? (provTotal.get(r.name) ?? 0) * 100 : r.real;
    const rank = rankAmong(fieldScores(spec), mine);
    const pct = pctOf(rank, spec.total);
    poolTotal = spec.total;
    let award = '';
    let tone: AwardRow['tone'] = 'silver';

    if (stage.id === 'prov') {
      if (isOfficial && rank <= 17 && schoolTeam < 5) {
        award = '进省队'; tone = 'team'; schoolTeam += 1; advanced.push(r.name);
      } else if (!isOfficial) {
        award = '体验（不计成绩）';
      } else {
        award = '未进省队';
      }
    } else if (stage.id === 'ctt') {
      if (isOfficial && rank <= 30) {
        award = '进 CTS'; tone = 'team'; advanced.push(r.name);
      } else {
        award = '未进 CTS';
      }
    } else if (stage.id === 'cts') {
      if (isOfficial && rank <= 4) {
        award = '进 IOI 国家队'; tone = 'team'; advanced.push(r.name);
      } else {
        award = '未进国家队';
      }
    } else if (stage.id === 'noip') {
      const line = bandOfLines(NOIP_SSX.lines, r.real);
      if (isOfficial) {
        award = line ? line.label : '无奖';
        tone = line?.tone ?? 'silver';
        if (line?.label === 'NOIP 一等') advanced.push(r.name);
      } else {
        award = '后备体验（无证书）';
      }
    } else if (stage.id === 'noi' && !isOfficial) {
      award = '夏令营（成绩证明）';
    } else {
      const quotas = NATIONAL_QUOTAS[stage.id] ?? [];
      let idx = awardIndexByRank(rank, quotas);
      if (stage.id === 'noi' && idx === 2 && r.real < 100) idx = -1; // 铜牌须 ≥100/705 ≈ 100/700
      const labels = ['金牌', '银牌', '铜牌'] as const;
      award = idx >= 0 ? labels[idx] : '无奖';
      tone = idx === 0 ? 'gold' : idx === 1 ? 'silver' : idx === 2 ? 'bronze' : 'silver';
    }

    if (isOfficial && award && award !== '无奖' && !award.startsWith('未进')) {
      awards.push({ name: r.name, label: award, tone });
    }
    nationalRows.push({
      name: r.name, score: Math.round(r.real), rank, pct, award, tone,
      team: teamSet.has(r.name),
      note: experienceSet.has(r.name) ? '体验' : isOfficial ? '正式' : undefined,
    });
  }
  awards.sort((a, b) => (nationalRows.find((x) => x.name === a.name)?.rank ?? 9999) - (nationalRows.find((x) => x.name === b.name)?.rank ?? 9999));

  const awardOf = new Map(awards.map((a) => [a.name, a.label]));
  const advancedSet = new Set(advanced);
  const rankOf = new Map(nationalRows.map((r) => [r.name, r.rank]));
  const meanDiff = meanDifficulty(problems);
  const topicSet = new Set(problems.map((p) => p.topic));
  const students = s.students.map((st) => {
    const rank = rankOf.get(st.name);
    if (rank === undefined) return st;
    const label = awardOf.get(st.name) ?? '';
    let next: SeasonStudent = { ...st };
    if (stage.id === 'noip') {
      next = { ...next, noip: { score: Math.round(rows.find((r) => r.name === st.name)?.real ?? 0), rank, first: advancedSet.has(st.name) } };
    } else if (stage.id === 'prov') {
      next = { ...next, prov: { score: Math.round(rows.find((r) => r.name === st.name)?.real ?? 0), rank, first: label === '进省队', team: label === '进省队' } };
    } else if (stage.id === 'wc') {
      next = { ...next, wc: { score: Math.round(rows.find((r) => r.name === st.name)?.real ?? 0), medal: label === '金牌' ? 1 : label === '银牌' ? 2 : label === '铜牌' ? 3 : 0 } };
    } else if (stage.id === 'apio') {
      next = { ...next, apio: { score: Math.round(rows.find((r) => r.name === st.name)?.real ?? 0), medal: label === '金牌' ? 1 : label === '银牌' ? 2 : label === '铜牌' ? 3 : 0 } };
    } else if (stage.id === 'noi') {
      next = { ...next, noi: { score: Math.round(rows.find((r) => r.name === st.name)?.real ?? 0), medal: label === '金牌' ? 1 : label === '银牌' ? 2 : label === '铜牌' ? 3 : 0 } };
    } else if (stage.id === 'ctt') {
      next = { ...next, ctt: { score: Math.round(rows.find((r) => r.name === st.name)?.real ?? 0), rank, selected: advancedSet.has(st.name) } };
    } else if (stage.id === 'cts') {
      next = { ...next, cts: { score: Math.round(rows.find((r) => r.name === st.name)?.real ?? 0), rank, selected: advancedSet.has(st.name) } };
    } else if (stage.id === 'ioi') {
      next = { ...next, ioi: { score: Math.round(rows.find((r) => r.name === st.name)?.real ?? 0), medal: label === '金牌' ? 1 : label === '银牌' ? 2 : label === '铜牌' ? 3 : 0 } };
    }
    return growFromContest(next, meanDiff, problems.length, 0.018 * stage.days, topicSet);
  });

  const recap: ContestRecap = {
    year: s.year, week, kind: 'official', stageId: stage.id, title: stage.name,
    levels: stage.levels, minutes: stage.minutes, days: stage.days,
    rows, fullScore, problems,
    awards, advanced,
    national: { total: poolTotal, rows: nationalRows },
    note: `参赛 ${qualified.length} 人（正式 ${official.length}${experience.length ? ` · 体验 ${experience.length}` : ''}）· 资格：${stage.gateText || '无门槛'} · 全国约 ${poolTotal.toLocaleString()} 人${stage.id === 'noi' ? ' · 总分含 100 分笔试' : ''}`,
  };

  return {
    ...bumpFatigue(s, stage.days),
    students,
    week: week + 1,
    phase: 'result',
    lastContest: recap,
    contests: [...s.contests, recap],
  };
}

/** 跑本周的比赛：赛历上有正式比赛就跑正式的，没有就跑校内模拟赛 */
export function runWeeklyContest(s: SeasonState, trace?: ContestRound[]): SeasonState {
  const stage = stageOfWeek(s.week);
  if (!stage) return runPractice(s, trace);
  if (stage.kind === 'prelim') return runPrelim(s, stage);
  if (stage.id === 'csp2') return runCsp2(s, stage, trace);
  return runStage(s, stage, trace);
}

// ===== 周的推进 / 学年切换 =====
export function advanceWeek(s: SeasonState): SeasonState {
  if (s.phase !== 'result') return s;
  if (s.week > YEAR_WEEKS) return beginNextYear(s);
  return withEvent({
    ...s,
    phase: 'plan',
    plan: null,
    report: null,
    pendingEvent: null,
    lastEventResult: null,
    weekMult: 1,
  });
}

function summarizeYear(s: SeasonState): YearSummary {
  const team = teamStudents(s);
  const count = (f: (st: SeasonStudent) => boolean) => team.filter(f).length;
  const base = {
    year: s.year,
    team: s.team.slice(),
    csp1Pass: count((st) => Boolean(st.csp1?.passed)),
    csp2First: count((st) => st.csp2?.award === 1),
    csp2Second: count((st) => st.csp2?.award === 2),
    noipFirst: count((st) => Boolean(st.noip?.first)),
    provTeam: count((st) => Boolean(st.prov?.team)),
    wcGold: count((st) => st.wc?.medal === 1),
    wcSilver: count((st) => st.wc?.medal === 2),
    wcBronze: count((st) => st.wc?.medal === 3),
    apioGold: count((st) => st.apio?.medal === 1),
    apioSilver: count((st) => st.apio?.medal === 2),
    apioBronze: count((st) => st.apio?.medal === 3),
    noiGold: count((st) => st.noi?.medal === 1),
    noiSilver: count((st) => st.noi?.medal === 2),
    noiBronze: count((st) => st.noi?.medal === 3),
    cttSelected: count((st) => Boolean(st.ctt?.selected)),
    ctsSelected: count((st) => Boolean(st.cts?.selected)),
    ioiGold: count((st) => st.ioi?.medal === 1),
    ioiSilver: count((st) => st.ioi?.medal === 2),
    ioiBronze: count((st) => st.ioi?.medal === 3),
    avgOverallGain: team.length
      ? team.reduce((a, st) => a + (overallOf(st.skills) - st.startOverall), 0) / team.length
      : 0,
    graduates: [] as string[],
  };
  return base;
}

function beginNextYear(s: SeasonState): SeasonState {
  const summary = summarizeYear(s);
  if (s.year >= s.careerYears) {
    return { ...s, phase: 'finished', history: [...s.history, summary] };
  }
  const grads = s.students.filter((st) => st.grade === 6);
  summary.graduates = grads.map((g) => g.name);

  const staying = s.students
    .filter((st) => st.grade < 6)
    .map((st) => ({
      ...st,
      grade: (st.grade + 1) as Grade,
      startSkills: cloneSkills(st.skills),
      startOverall: overallOf(st.skills),
      startRank: 0,
      fatigue: Math.round(st.fatigue * 0.4),
      onTeam: false,
      // 清空上一学年的资格链
      csp1: undefined, csp2: undefined, noip: undefined,
      wc: undefined, prov: undefined, apio: undefined, noi: undefined,
      ctt: undefined, cts: undefined, ioi: undefined,
    }));

  const baseCohort = buildCohort((s.seed * 13 + s.year * 104729 + 7) >>> 0);
  const newcomers: SeasonStudent[] = [];
  // 每年补 6 个初一 + 4 个高一：初中生是校队的底座，高中生才是省选/NOI 的兵源
  const intake: Grade[] = [1, 1, 1, 1, 1, 1, 4, 4, 4, 4];
  for (let i = 0; i < intake.length; i++) {
    const tmpl = baseCohort[Math.floor(makeRng((s.seed * 977 + s.year * 131 + i * 37 + 5) >>> 0)() * baseCohort.length)];
    newcomers.push(makeNewcomer(i, s.year + 1, s.seed, tmpl, intake[i]));
  }

  // 新生名是随机拼的，可能和在校生/往届生重名；重名会让比赛引擎按名字认人出错，这里强制去重
  const used = new Set(staying.map((st) => st.name));
  for (const n of newcomers) {
    if (!used.has(n.name)) { used.add(n.name); continue; }
    let k = 2;
    let name = `${n.name}（${k}）`;
    while (used.has(name)) { k++; name = `${n.name}（${k}）`; }
    n.name = name;
    used.add(name);
  }
  const students = [...staying, ...newcomers];
  rankStudents(students);
  const keptTeam = s.team.filter((n) => students.some((st) => st.name === n));

  return {
    ...s,
    year: s.year + 1,
    week: 1,
    phase: 'team',
    students,
    team: [],
    lastTeam: keptTeam,
    plan: null,
    report: null,
    lastContest: null,
    contests: [],
    graduates: grads.map((g) => ({ name: g.name, grade: g.grade, overall: overallOf(g.skills) })),
    newcomers: newcomers.map((n) => n.name),
    history: [...s.history, summary],
    pendingEvent: null,
    lastEventResult: null,
    weekMult: 1,
  };
}

// ===== 结算 =====
export interface CareerRow {
  name: string;
  grade: Grade;
  onTeam: boolean;
  startOverall: number;
  endOverall: number;
  overallGain: number;
  csp2Award: number;
  noipFirst: boolean;
  provTeam: boolean;
  noiMedal: number;
}

export interface CareerReport {
  years: YearSummary[];
  totals: {
    csp1Pass: number; csp2First: number; csp2Second: number; noipFirst: number;
    provTeam: number; wcGold: number; wcSilver: number; wcBronze: number;
    apioGold: number; apioSilver: number; apioBronze: number;
    noiGold: number; noiSilver: number; noiBronze: number;
    cttSelected: number; ctsSelected: number;
    ioiGold: number; ioiSilver: number; ioiBronze: number;
  };
  roster: CareerRow[];
  team: CareerRow[];
  coachScore: number;
  grade: string;
  comment: string;
  avgOverallGain: number;
  /** 兼容旧脚本的字段 */
  provinceFirstCount: number;
  provinceTeamCount: number;
  avgRankGain: number;
  final: ContestRecap | null;
  rows: CareerRow[];
}

const GRADES: { min: number; grade: string; comment: string }[] = [
  { min: 85, grade: 'S · 传奇教练', comment: '几年下来，你把一所学校的名字打进了省队名单，下一届学生是冲着你的名头来的。' },
  { min: 55, grade: 'A · 金牌教练', comment: '省队、NOI 奖牌都有进账，队伍整体抬了一大截，是能拿出去说的成绩。' },
  { min: 34, grade: 'B · 优秀教练', comment: '训练有效果，学生能摸到省一线，离顶尖教练差一口气。' },
  { min: 19, grade: 'C · 合格教练', comment: '稳住了基本盘，成绩单不好看也不难看。' },
  { min: 0, grade: 'D · 新手上路', comment: '带完这一届，学生大多还在原地打转，赛历一场场错过。' },
];

/** 生涯结算：累计战绩 + 教练评分 */
export function seasonReport(s: SeasonState): CareerReport {
  const current = summarizeYear(s);
  const years = s.phase === 'finished' || s.history.length
    ? [...s.history, ...(s.phase === 'finished' ? [] : [current])]
    : [current];
  const t = {
    csp1Pass: 0, csp2First: 0, csp2Second: 0, noipFirst: 0, provTeam: 0,
    wcGold: 0, wcSilver: 0, wcBronze: 0,
    apioGold: 0, apioSilver: 0, apioBronze: 0,
    noiGold: 0, noiSilver: 0, noiBronze: 0,
    cttSelected: 0, ctsSelected: 0,
    ioiGold: 0, ioiSilver: 0, ioiBronze: 0,
  };
  for (const y of years) {
    t.csp1Pass += y.csp1Pass; t.csp2First += y.csp2First; t.csp2Second += y.csp2Second; t.noipFirst += y.noipFirst;
    t.provTeam += y.provTeam;
    t.wcGold += y.wcGold; t.wcSilver += y.wcSilver; t.wcBronze += y.wcBronze;
    t.apioGold += y.apioGold; t.apioSilver += y.apioSilver; t.apioBronze += y.apioBronze;
    t.noiGold += y.noiGold; t.noiSilver += y.noiSilver; t.noiBronze += y.noiBronze;
    t.cttSelected += y.cttSelected; t.ctsSelected += y.ctsSelected;
    t.ioiGold += y.ioiGold; t.ioiSilver += y.ioiSilver; t.ioiBronze += y.ioiBronze;
  }

  const roster: CareerRow[] = s.students.map((st) => ({
    name: st.name,
    grade: st.grade,
    onTeam: st.onTeam,
    startOverall: st.startOverall,
    endOverall: overallOf(st.skills),
    overallGain: overallOf(st.skills) - st.startOverall,
    csp2Award: st.csp2?.award ?? 0,
    noipFirst: Boolean(st.noip?.first),
    provTeam: Boolean(st.prov?.team),
    noiMedal: st.noi?.medal ?? 0,
  }));

  const avgOverallGain = years.length
    ? years.reduce((a, y) => a + y.avgOverallGain, 0) / years.length
    : 0;

  // 教练评分：用「每年平均产出」而不是三年累计次数，避免方差被少数省队/奖牌事件吃掉
  // （旧公式 csp2First*2 + provTeam*10，同一队伍换个 seed 可以从 57 掉到 20）
  const perYear = (n: number) => n / Math.max(1, years.length);
  let score = 10;
  score += perYear(t.csp1Pass) * 1.5;    // 每年初赛过线人数
  score += perYear(t.csp2First) * 3;     // 每年 S 组省一
  score += perYear(t.csp2Second) * 1.2;  // 复赛省二也算产出，不给 0 分
  score += perYear(t.noipFirst) * 3;     // 每年 NOIP 省一
  score += t.provTeam * 8;               // 累计进省队（三年合计）
  score += t.noiGold * 25 + t.noiSilver * 12 + t.noiBronze * 5;
  score += t.cttSelected * 2 + t.ctsSelected * 6;
  score += t.ioiGold * 18 + t.ioiSilver * 10 + t.ioiBronze * 5;
  score += (t.wcGold + t.apioGold) * 4 + (t.wcSilver + t.apioSilver) * 1.5;
  score += clamp(avgOverallGain, 0, 30) * 0.8;
  const coachScore = Math.round(clamp(score, 0, 100));
  const g = GRADES.find((x) => coachScore >= x.min) ?? GRADES[GRADES.length - 1];

  const teamRows = roster.filter((r) => r.onTeam);
  const lastContest = s.lastContest ?? [...s.contests].reverse().find((c) => c.kind === 'official') ?? null;

  return {
    years,
    totals: t,
    roster,
    team: teamRows,
    coachScore,
    grade: g.grade,
    comment: g.comment,
    avgOverallGain,
    provinceFirstCount: t.csp2First + t.noipFirst,
    provinceTeamCount: t.provTeam,
    avgRankGain: 0,
    final: lastContest,
    rows: roster,
  };
}

// ===== 给 UI 用的杂项 =====
export const INTENSITY_INFO: Record<WeekIntensity, { name: string; note: string; emoji: string }> = {
  normal: { name: '常规训练', note: '每天一节专题课，涨得稳、不累人', emoji: '📘' },
  extra: { name: '加练', note: '晚上加课 + 周末加测，涨得快但人会被榨干', emoji: '🔥' },
  rest: { name: '休息', note: '这周放假，恢复疲劳，专题不涨', emoji: '☕' },
};

export function topicNameOf(t: Topic): string {
  return TOPIC_NAMES[t];
}

export function rosterSorted(s: SeasonState): SeasonStudent[] {
  return s.students.slice().sort((a, b) => overallScoreOf(b) - overallScoreOf(a));
}

export function nameOfRoster(): string[] {
  return ROSTER.map((r) => r.name);
}

/** 某场比赛的参赛人数（正式 + 体验名额，给"本周赛事"提示用） */
export function qualifiedFor(s: SeasonState, stage: StageDef): number {
  return s.students.filter((st) => {
    switch (stage.id) {
      case 'csp1':
        return true;
      case 'csp2': return Boolean(st.csp1?.passed);
      case 'noip':
        // 正式：S 组二等及以上（限高中生）；体验：初中生拿省一可当后备体验
        return isSenior(st.grade)
          ? (st.csp2?.award ?? 0) >= 1 && (st.csp2?.award ?? 0) <= 2
          : isJunior(st.grade) && (st.csp2?.award ?? 0) >= 1;
      case 'wc': return isSenior(st.grade) && Boolean(st.noip?.first);
      case 'prov': return st.noip !== undefined;
      case 'apio': return Boolean(st.prov?.team);
      case 'noi': return Boolean(st.prov?.team) || (isJunior(st.grade) && st.noip !== undefined);
      case 'ctt': return st.noi?.medal === 1;
      case 'cts': return Boolean(st.ctt?.selected);
      case 'ioi': return Boolean(st.cts?.selected);
      default: return false;
    }
  }).length;
}
