# -*- coding: utf-8 -*-
"""从 data/属性对照表.csv 生成 docs/选手属性全表.md（一次性辅助脚本）。"""
import csv
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
raw = (ROOT / 'data' / '属性对照表.csv').read_bytes()
try:
    text = raw.decode('utf-8-sig')
except UnicodeDecodeError:
    text = raw.decode('gbk').lstrip('\ufeff')
text = text.replace('\r\n', '\n')
first = text.splitlines()[0]
delim = '\t' if first.count('\t') > first.count(',') else ','
rows = list(csv.reader(text.splitlines(), delimiter=delim))
header = [h.strip() for h in rows[0]]
data = [[c.strip() for c in r] for r in rows[1:] if r and r[0].strip()]

idx = {h: i for i, h in enumerate(header)}
TOPICS = ['数学', '动态规划', '图论', '贪心', '数据结构', '模拟实现', '字符串', '计算几何']
META = ['代码', '阅读', '调试']

def num(row, col, default=0.0):
    v = row[idx[col]] if col in idx and idx[col] < len(row) else ''
    try:
        return float(v)
    except (TypeError, ValueError):
        return default

def overall(row):
    topic_avg = sum(num(row, t, 0) for t in TOPICS) / len(TOPICS) / 100
    return (topic_avg * 0.8 + num(row, '代码', 0) / 100 * 0.12 + num(row, '调试', 0) / 100 * 0.08) * 100

def fmt(v):
    return f'{v:.1f}'

data.sort(key=lambda r: overall(r), reverse=True)

base = [
    '| # | 姓名 | 年级 | 天赋 | 综合* | 代码 | 阅读 | 调试 |',
    '|---|---|---|---|---|---|---|---|',
]
for i, r in enumerate(data, 1):
    cells = [str(i), r[idx['姓名']], r[idx['年级']], r[idx['天赋']], fmt(overall(r))]
    cells += [r[idx[c]] for c in META]
    base.append('| ' + ' | '.join(cells) + ' |')

know = [
    '| # | 姓名 | 数学 | 动态规划 | 图论 | 贪心 | 数据结构 | 模拟实现 | 字符串 | 计算几何 |',
    '|---|---|---|---|---|---|---|---|---|---|',
]
for i, r in enumerate(data, 1):
    cells = [str(i), r[idx['姓名']]] + [r[idx[t]] for t in TOPICS]
    know.append('| ' + ' | '.join(cells) + ' |')

out = [
    '# 选手属性全表（54 人）',
    '',
    '> 由 `data/属性对照表.csv`（GBK 或 UTF-8 BOM、**逗号分隔**，Excel 双击即可按列打开）自动生成，2026-10-20。',
    '> 所有属性均为 0–100 整数；`天赋` 是约 1.0–1.3 的乘数，不是百分制。',
    '> `综合*` 不是表里的字段，是按 `0.8×八知识点均值 + 0.12×代码 + 0.08×调试` 算出来的派生值，只用于排序/对照。',
    '> **改属性请改 CSV，不要改本文件**；改完跑 `node scripts/profile.mjs` 再重新构建。',
    '> 已彻底移除：性格 / 实力 / 自我认知 / 抗压 / 耐心 / 冒险（引擎/类型/详情卡里都不再存在）。',
    '',
    '## 一、基础与元能力',
    '',
    *base,
    '',
    '## 二、八个知识点',
    '',
    *know,
    '',
]

(ROOT / 'docs' / '选手属性全表.md').write_text('\n'.join(out), encoding='utf-8')
print(f'wrote docs/选手属性全表.md: {len(data)} players')
