# -*- coding: utf-8 -*-
"""Replace the placeholder 周逸然 section with the real one and append 周炜恒,
then add both rows to blog-roster-mapping.json."""
import io
import json
import os

BASE = r'C:\Users\lifen\Documents\deepseek-harness\default-workspace\mockmock-src'
P = os.path.join(BASE, 'data', 'level-analysis.md')
M = os.path.join(BASE, 'data', 'blog-roster-mapping.json')

text = io.open(P, encoding='utf-8').read()

start_marker = '## 周逸然（初三）— 洛谷账号未识别'
end_marker = '## No0Chenquanlin（陈泉林，高二）— 游戏角色「法克火星人」'
s = text.find(start_marker)
e = text.find(end_marker)
assert s != -1 and e != -1 and s < e, (s, e)

new_zyr = '''## zhouyiran_2011（周逸然，高一）— 游戏角色「周逸然」

**账号**：洛谷 uid 571937，橙名，ccfLevel 7，ranking 8511，注册 2021-09-12，签名「Do you remember the 21st night of September」，AC/提交数隐藏。
**OIerDb**：uid 170007，全国 2194 / 9528.91 / CCF 7（roster 里那份 2825/7146.63 是旧快照）。高一，高新三中。校 OJ rank 11，rating0=1783。

### 比赛记录（OIerDb 官网口径）
| 赛事 | 奖项 | 分数 | 排名/参赛 | 年级 |
|---|---|---|---|---|
| CSP 2026 提高 | 一等 | 239 | 2342 / 32643 | 高一 |
| CSP 2025 提高 | 一等 | 213 | 1981 / 30497 | 初三 |
| CSP 2025 入门 | 一等 | 339 | 1954 / 39205 | 初三 |
| CSP 2024 入门 | 一等 | 300 | 968 / 40430 | 初二 |
| CSP 2024 提高 | 二等 | 60 | 18237 / 27521 | 初二 |
| CSP 2023 提高 | 二等 | 75 | 9771 / 19202 | 初一 |
| NGOI 2026 | 一等 | 141 | 71 / — | 高一 |

无 NOIP/APIO/NOI/省选记录。

### 专栏（26 篇，2023-05 ~ 2024-11）
- cat4 学习笔记 9 篇：DP、数据结构、数论、最短路、最小生成树、tarjan、分块&莫队、概率和期望、哈希/KMP/Trie/AC 自动机。
- cat1 日志 8 篇：考试心得 1–3、专项训练、对拍代码、常用代码放置、代码暂存、翻译题目——典型的**低年级训练流水账**。
- cat2 题解 6 篇：P7745 ROBOT（2 赞）、P4163 [SCOI2007] 排列、P3193 [HNOI2008] GT考试、P4159 [SCOI2009] 迷路、ABC163E、P2054 洗牌。
- cat8 1 篇《曾经掉过的坑》。
- **2024-11 后停更**，高一阶段没有新的学习记录或游记。

### 判断
- 纯 CSP 型、稳扎稳打的「课本派」：J 组 300+ 稳定，S 组 60→213→239 三年爬升，无省选/NOIP 经历。
- 专栏内容停在初中阶段，深度上限 P3xxx 省选老题（SCOI/HNOI），**没有 d7–d8 的硬题解、没有游记**，看不出竞赛锐度。
- 校内第三梯队（与陈泉林、张顺凯同段但战绩略低），离省队线有一段距离；优势是基础扎实、曲线稳定，短板是**缺少高强度实战与难题突破**。

---

'''

zyr_old_len = e - s
text = text[:s] + new_zyr + text[e:]

zwh = '''---

## zzzwwwhhh123（周炜恒，高一）— 游戏角色「周炜恒」

**账号**：洛谷 uid 993668，橙名，ccfLevel 7，ranking 9760，AC 420 / 提交 614，注册 2023-04-17，签名空。
**OIerDb**：uid 198226，全国 2496 / 8943.61 / CCF 7（roster 快照 3795/6031.93 已过时）。高一，高新三中。**校 OJ rank 1、lv 8、rp 302、ac 1149、rating0=1797**——校内 OJ 榜首。

### 比赛记录（OIerDb 官网口径）
| 赛事 | 奖项 | 分数 | 排名/参赛 | 年级 |
|---|---|---|---|---|
| CSP 2026 提高 | 一等 | 267 | 983 / 32643（前 3.0%） | 高一 |
| CSP 2025 提高 | 一等 | 240 | 1184 / 30497 | 初三 |
| CSP 2025 入门 | 一等 | **400** | **1 / 39205（全国第一）** | 初三 |
| CSP 2024 入门 | 一等 | 300 | 968 / 40430 | 初二 |
| CSP 2024 提高 | 一等 | 200 | 3519 / 27521 | 初二 |

无 NOIP/APIO/NOI/省选记录——**高分但没走到提高组后期的竞赛**，这是他和前面几位最大的差别。

### 专栏（36 篇，几乎全是 2025 年的学习笔记）
- cat4 学习笔记约 28 篇，密度极高：平衡树、基环树与笛卡尔树、扫描线、点分治与动态点分治、cdq 分治、二分图、虚树、网络流、整体二分、后缀数组、Manacher、回文自动机、后缀自动机、莫比乌斯反演、杜教筛、拉格朗日插值、线段树综合、可持久化数据结构、K-D Tree、群论、dp、分块与莫队、AC 自动机、概率与期望……
- 训练记录：2025 寒假专项做题记录、2025 上半年专项训练、2025 上半年比赛总结、2025 暑假模拟赛记录 (1)–(4)、2026 省选冲刺模拟赛题解——**从 2025 寒假起就是系统化刷专题**。
- 题解 3 篇：P9062 [Ynoi2002] Adaptive Hsearch&Lsearch（1 赞）、ABC297Ex Diff Adjacent、P3067 [USACO12OPEN] Balanced Cow Subsets G。

### 判断
- **J 组满分全国第一、CSP-S 267（前 3%）**，高一，校内 OJ 排第 1——纸面数据已是省队边缘水平，但完全没参加 NOIP/省选，**缺少提高组后期实战检验**。
- 专栏画像非常清晰：**系统性、全覆盖的技术型选手**，数据结构/字符串/数论三大块全部自己写过笔记，训练节奏从寒假专题到暑假模拟赛一直没断，2026 年还在写省选冲刺模拟赛题解，说明目标明确冲着省队去。
- 和同档的肖子卓/丁子博相比：他们有 NOI/APIO 实战成绩，周炜恒是「积累最整齐但尚未验刀」；如果 2027 省选正常发挥，进队概率不低。
- 校内定位：按 OIerDb 折算排 9，但按校 OJ 与专栏密度看，实际实力在第三梯队头部，接近刘昱合/丁子博那一档的下沿。
'''

if '## zzzwwwhhh123（周炜恒' not in text:
    text = text.rstrip('\n') + '\n\n' + zwh

io.open(P, 'w', encoding='utf-8', newline='\n').write(text)

d = json.load(io.open(M, encoding='utf-8'))
rows = d['mapping']
names = {r.get('abbr') for r in rows}
add = [
    {"abbr": "Zyr", "luogu": "zhouyiran_2011", "uid": 571937, "blogGrade": None,
     "gameName": "周逸然", "gameRealName": "周逸然", "gameGrade": "高一",
     "quotes": 0, "boundQuotes": 0, "confidence": "用户确认",
     "evidence": "用户 2026-11-15 提供：zhouyiran_2011 = zyr；洛谷 /api/user/search 返回 uid 571937、橙名、ccf7；OIerDb uid 170007 同名同校。"},
    {"abbr": "Zwh", "luogu": "zzzwwwhhh123", "uid": 993668, "blogGrade": None,
     "gameName": "周炜恒", "gameRealName": "周炜恒", "gameGrade": "高一",
     "quotes": 0, "boundQuotes": 0, "confidence": "用户确认",
     "evidence": "用户 2026-11-15 提供：zzzwwwhhh123 = zwh；洛谷 /api/user/search 返回 uid 993668、橙名、ccf7；OIerDb uid 198226 同名同校。"},
]
for r in add:
    if r['abbr'] not in names:
        rows.append(r)
d['userCorrections'] = d.get('userCorrections', []) + [
    "2026-11-15：zhouyiran_2011 = zyr = 周逸然（洛谷 uid 571937），zzzwwwhhh123 = zwh = 周炜恒（洛谷 uid 993668）。"]
d['meta']['updatedAt'] = '2026-11-15'
io.open(M, 'w', encoding='utf-8', newline='\n').write(json.dumps(d, ensure_ascii=False, indent=2))

print('sections ok; mapping rows', len(d['mapping']), '; replaced chars', zyr_old_len)
