import {
  Fragment,
  useEffect,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
} from 'react';
import {
  TOPIC_COLORS,
  TOPIC_NAMES,
  estimateRankMap,
  formatTime,
  isIoiFormat,
  levelInfo,
  phaseColor,
  phaseLabel,
  problemEstimate,
  tick,
  totalEstimate,
} from './game.ts';
import { loadGrowth, profileOf } from './growth.ts';
import { buildContestFeed, buildContestMilestones, FEED_TONE } from './contestFeed.ts';
import { FocusPanel } from './FocusPanel.tsx';
import type { ContestGuideLine } from './season.ts';
import { kindName, tracesForStudent } from './thinking.ts';
import type { Contest, Phase, Problem, Student } from './types.ts';
import { Ic, motionFull } from './ui.tsx';

type CellFxKind = 'ac' | 'gain' | 'wa' | 'tle' | 're' | 'seal' | 'rework' | 'restore';

interface CellFx {
  kind: CellFxKind;
  label: string;
  until: number;
  seq: number;
}

interface RankShift {
  delta: number;
  until: number;
}

interface RecentAction {
  studentId: number;
  studentName: string;
  problemId: number;
  atReal: number;
  kind: CellFxKind;
  caption: string;
  tone: 'good' | 'sky' | 'amber' | 'rose';
}

interface PrevProblemSnap {
  subs: number;
  bestScore: number;
  debugRounds: number;
}

const PIPELINE_STEPS: { id: Phase; label: string }[] = [
  { id: 'survey', label: '通读' },
  { id: 'reading', label: '读题' },
  { id: 'thinking', label: '思考' },
  { id: 'coding', label: '编码' },
  { id: 'testing', label: '对拍' },
  { id: 'deciding', label: '交卷' },
];

const LINE_TONE_STYLE: Record<ContestGuideLine['tone'], { border: string; badge: string; text: string }> = {
  gold: {
    border: 'border-amber-400/55',
    badge: 'bg-amber-400/20 text-amber-200 border-amber-400/50',
    text: 'text-amber-200',
  },
  prov1: {
    border: 'border-amber-500/50',
    badge: 'bg-amber-500/18 text-amber-200 border-amber-500/45',
    text: 'text-amber-200',
  },
  team: {
    border: 'border-rose-400/55',
    badge: 'bg-rose-500/20 text-rose-200 border-rose-400/50',
    text: 'text-rose-200',
  },
  silver: {
    border: 'border-sky-400/45',
    badge: 'bg-sky-500/15 text-sky-200 border-sky-400/40',
    text: 'text-sky-200',
  },
  bronze: {
    border: 'border-orange-500/45',
    badge: 'bg-orange-500/15 text-orange-200 border-orange-500/40',
    text: 'text-orange-200',
  },
};

const CONFETTI_OFFSETS: { dx: string; color: string; left: string }[] = [
  { dx: '-28px', color: '#50cf9e', left: '16%' },
  { dx: '-14px', color: '#eab454', left: '26%' },
  { dx: '12px', color: '#56c2d4', left: '38%' },
  { dx: '26px', color: '#b8df4a', left: '50%' },
  { dx: '-20px', color: '#f5ca79', left: '62%' },
  { dx: '18px', color: '#7de2ba', left: '74%' },
  { dx: '-10px', color: '#eb737c', left: '84%' },
  { dx: '24px', color: '#eab454', left: '91%' },
];

// ===== 比赛进行中（赛时导播台 + 判题特效 + 实时目标线榜单） =====
export function ContestScreen({
  contest,
  onFinish,
  teamNames,
  opvName,
  guideLines,
  roundLabel,
}: {
  contest: Contest;
  onFinish: () => void;
  teamNames?: string[];
  opvName?: string | null;
  guideLines?: ContestGuideLine[];
  roundLabel?: string;
}) {
  const [speed, setSpeed] = useState(2);
  const [paused, setPaused] = useState(false);
  const [autoSlowMo, setAutoSlowMo] = useState(true);
  const [spotlightOpen, setSpotlightOpen] = useState(true);
  const [autoDirector, setAutoDirector] = useState(true);
  const [lockedFocusId, setLockedFocusId] = useState<number | null>(null);
  const [drawerStudentId, setDrawerStudentId] = useState<number | null>(null);
  const [boardFilter, setBoardFilter] = useState<'all' | 'team'>('all');
  const [feedTab, setFeedTab] = useState<'live' | 'milestones'>('live');
  const [, setFrame] = useState(0);
  const confettiSeqRef = useRef(0);

  const speedRef = useRef(speed);
  const pausedRef = useRef(paused);
  const autoSlowMoRef = useRef(autoSlowMo);
  const slowMoUntilRef = useRef(0);
  const slowMoCooldownRef = useRef<Set<string>>(new Set());
  const finishedRef = useRef(false);
  const onFinishRef = useRef(onFinish);

  // 轻量前端状态差分快照（不写回 Contest，100% 不影响结算结果）
  const prevSnapRef = useRef<Map<string, PrevProblemSnap>>(new Map());
  const prevRankRef = useRef<Map<number, number>>(new Map());
  const cellFxRef = useRef<Map<string, CellFx>>(new Map());
  const rankShiftRef = useRef<Map<number, RankShift>>(new Map());
  const recentActionRef = useRef<RecentAction | null>(null);
  const autoPickHoldRef = useRef<{ id: number; until: number }>({ id: -1, until: 0 });
  const fxSeqRef = useRef(1);

  const boardBodyRef = useRef<HTMLDivElement | null>(null);
  const rowTopsRef = useRef<Map<number, number>>(new Map());

  speedRef.current = speed;
  pausedRef.current = paused;
  autoSlowMoRef.current = autoSlowMo;
  onFinishRef.current = onFinish;

  const teamSet = useMemo(() => new Set(teamNames ?? []), [teamNames]);
  const ioi = isIoiFormat(contest);

  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    const step = (now: number) => {
      const dtReal = Math.min(0.25, (now - last) / 1000);
      last = now;
      if (!pausedRef.current && !contest.isFinished) {
        const inSlowMo = autoSlowMoRef.current && speedRef.current > 1 && now < slowMoUntilRef.current;
        const effSpeed = inSlowMo ? 1 : speedRef.current;
        tick(contest, dtReal * effSpeed * 60);
      }
      setFrame((f) => (f + 1) % 100000);
      if (contest.isFinished && !finishedRef.current) {
        finishedRef.current = true;
        onFinishRef.current();
        return false;
      }
      return true;
    };
    const loop = (now: number) => {
      if (!step(now)) return;
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    const fallback = window.setInterval(() => {
      if (document.hidden) step(performance.now());
    }, 200);
    return () => {
      cancelAnimationFrame(raf);
      window.clearInterval(fallback);
    };
  }, [contest]);

  const nowReal = typeof performance !== 'undefined' ? performance.now() : 0;
  const ranks = estimateRankMap(contest);
  const sorted = contest.students
    .slice()
    .sort((a, b) => totalEstimate(b, ioi) - totalEstimate(a, ioi) || a.id - b.id);

  // 逐帧差分检测：提交判题特效、对拍返工、排名超车角标与慢放触发（纯读 contest）
  for (const st of contest.students) {
    const isSquad = teamSet.size === 0 || teamSet.has(st.name) || st.name === opvName;
    const curRank = ranks.get(st.id) || 0;
    const prevRank = prevRankRef.current.get(st.id);
    if (st.totalSubmissions > 0 && prevRank !== undefined && prevRank > 0 && curRank > 0 && prevRank !== curRank) {
      rankShiftRef.current.set(st.id, {
        delta: prevRank - curRank,
        until: nowReal + 3200,
      });
    }
    if (st.totalSubmissions > 0) {
      prevRankRef.current.set(st.id, curRank);
    }

    // 关键主角进入犹豫提交时触发一次短暂 1x 推镜慢放（每题限一次，不卡进度）
    if (
      autoSlowMo &&
      speed > 1 &&
      isSquad &&
      st.currentProblem !== null &&
      (st.phase === 'deciding' || st.phase === 'fixing')
    ) {
      const cdKey = `${st.id}#${st.currentProblem}#${st.phase}`;
      if (!slowMoCooldownRef.current.has(cdKey)) {
        slowMoCooldownRef.current.add(cdKey);
        slowMoUntilRef.current = Math.max(slowMoUntilRef.current, nowReal + 1600);
      }
    }

    st.problems.forEach((ps, pid) => {
      const key = `${st.id}#${pid}`;
      const prev = prevSnapRef.current.get(key);
      const curBest = ps.attempts.reduce((m, a) => Math.max(m, a.score), 0);
      if (!prev) {
        prevSnapRef.current.set(key, {
          subs: ps.submissions,
          bestScore: curBest,
          debugRounds: ps.debugRounds,
        });
        return;
      }

      if (ps.submissions > prev.subs && ps.attempts.length > 0) {
        const att = ps.attempts[ps.attempts.length - 1];
        const seq = fxSeqRef.current++;
        if (ioi) {
          if (att.score >= 100) {
            cellFxRef.current.set(key, { kind: 'ac', label: 'AC', until: nowReal + 2800, seq });
            if (isSquad) {
              recentActionRef.current = {
                studentId: st.id,
                studentName: st.name,
                problemId: pid,
                atReal: nowReal,
                kind: 'ac',
                caption: `评测返回 AC 100 · P${pid + 1} 全测试点通过！`,
                tone: 'good',
              };
              if (prev.bestScore < 100 && motionFull()) {
                confettiSeqRef.current += 1;
              }
              if (autoSlowMo && speed > 1) {
                slowMoUntilRef.current = Math.max(slowMoUntilRef.current, nowReal + 1600);
              }
            }
          } else if (att.score > prev.bestScore) {
            const gain = Math.round(att.score - prev.bestScore);
            cellFxRef.current.set(key, { kind: 'gain', label: `+${gain}↑`, until: nowReal + 2500, seq });
            if (isSquad) {
              recentActionRef.current = {
                studentId: st.id,
                studentName: st.name,
                problemId: pid,
                atReal: nowReal,
                kind: 'gain',
                caption: `评测返回 ${Math.round(att.score)} 分（较前次 +${gain} ↑）· P${pid + 1}`,
                tone: 'sky',
              };
            }
          } else if (att.reason.startsWith('TLE')) {
            cellFxRef.current.set(key, { kind: 'tle', label: 'TLE', until: nowReal + 2600, seq });
            if (isSquad) {
              recentActionRef.current = {
                studentId: st.id,
                studentName: st.name,
                problemId: pid,
                atReal: nowReal,
                kind: 'tle',
                caption: `评测受阻：${att.reason}（P${pid + 1} · ${Math.round(att.score)} 分）`,
                tone: 'amber',
              };
            }
          } else if (att.reason.startsWith('RE')) {
            cellFxRef.current.set(key, { kind: 're', label: 'RE', until: nowReal + 2600, seq });
            if (isSquad) {
              recentActionRef.current = {
                studentId: st.id,
                studentName: st.name,
                problemId: pid,
                atReal: nowReal,
                kind: 're',
                caption: `运行错误：${att.reason}（P${pid + 1}）`,
                tone: 'rose',
              };
            }
          } else {
            cellFxRef.current.set(key, { kind: 'wa', label: 'WA', until: nowReal + 2600, seq });
            if (isSquad) {
              recentActionRef.current = {
                studentId: st.id,
                studentName: st.name,
                problemId: pid,
                atReal: nowReal,
                kind: 'wa',
                caption: `评测未拿满：${att.reason}（P${pid + 1} · ${Math.round(att.score)} 分）`,
                tone: 'rose',
              };
            }
          }
        } else {
          // OI 盲测赛制：严格保密真分，突出封存归档与保底切换仪式感
          const switchedBrute =
            att.mode === 'brute' && ps.attempts.length > 1 && ps.attempts.some((a) => a.mode === 'full');
          if (switchedBrute) {
            cellFxRef.current.set(key, { kind: 'restore', label: '保底', until: nowReal + 2600, seq });
            if (isSquad) {
              recentActionRef.current = {
                studentId: st.id,
                studentName: st.name,
                problemId: pid,
                atReal: nowReal,
                kind: 'restore',
                caption: `P${pid + 1} 撤回激进正解，重新封存暴力保底版（自估 ≈${Math.round(att.est)}）`,
                tone: 'amber',
              };
            }
          } else {
            cellFxRef.current.set(key, { kind: 'seal', label: `封存`, until: nowReal + 2300, seq });
            if (isSquad) {
              recentActionRef.current = {
                studentId: st.id,
                studentName: st.name,
                problemId: pid,
                atReal: nowReal,
                kind: 'seal',
                caption: `代码已封存归档 · P${pid + 1} 第 ${att.nth} 次提交（自估 ≈${Math.round(att.est)}）`,
                tone: att.est >= 100 ? 'good' : 'amber',
              };
              if (autoSlowMo && speed > 1 && att.est >= 80) {
                slowMoUntilRef.current = Math.max(slowMoUntilRef.current, nowReal + 1500);
              }
            }
          }
        }
      } else if (ps.debugRounds > prev.debugRounds) {
        const seq = fxSeqRef.current++;
        cellFxRef.current.set(key, {
          kind: 'rework',
          label: `返工×${ps.debugRounds}`,
          until: nowReal + 2600,
          seq,
        });
        if (isSquad) {
          recentActionRef.current = {
            studentId: st.id,
            studentName: st.name,
            problemId: pid,
            atReal: nowReal,
            kind: 'rework',
            caption: `对拍报警！P${pid + 1} 拍出第 ${ps.debugRounds} 处反例，正在紧急返工修 Bug`,
            tone: 'rose',
          };
        }
      }

      prevSnapRef.current.set(key, {
        subs: ps.submissions,
        bestScore: curBest,
        debugRounds: ps.debugRounds,
      });
    });
  }

  // 自动导播：优先聚焦正在犹豫提交 / 修锅 / 刚交题 / 我队头名或 OP 主角，并加驻留防抖
  const focusedStudent: Student | null = (() => {
    if (!contest.students.length) return null;
    if (!autoDirector && lockedFocusId !== null) {
      return contest.students.find((s) => s.id === lockedFocusId) ?? sorted[0] ?? null;
    }
    const recent = recentActionRef.current;
    if (recent && nowReal - recent.atReal < 2400) {
      const target = contest.students.find((s) => s.id === recent.studentId);
      if (target) {
        autoPickHoldRef.current = { id: target.id, until: nowReal + 2800 };
        return target;
      }
    }
    const pool = teamSet.size > 0
      ? sorted.filter((s) => teamSet.has(s.name) || s.name === opvName)
      : sorted.slice(0, Math.min(8, sorted.length));
    const candidates = pool.length > 0 ? pool : sorted;

    let best = candidates[0];
    let bestWeight = -1;
    for (let idx = 0; idx < candidates.length; idx += 1) {
      const s = candidates[idx];
      let w = (candidates.length - idx) * 2;
      if (s.name === opvName) w += 18;
      if (s.phase === 'deciding') w += 110;
      else if (s.phase === 'fixing' || s.phase === 'restoring') w += 95;
      else if (s.phase === 'testing' && s.currentProblem !== null && (s.problems[s.currentProblem]?.debugRounds ?? 0) > 0) {
        w += 80;
      } else if (s.phase === 'coding') {
        w += 25;
      }
      if (w > bestWeight) {
        bestWeight = w;
        best = s;
      }
    }

    // 普通状态下保持镜头至少驻留 3.2 秒，避免频繁跳切眼花；遇到关键提交/犹豫立刻切镜
    if (bestWeight < 80 && nowReal < autoPickHoldRef.current.until) {
      const held = candidates.find((s) => s.id === autoPickHoldRef.current.id);
      if (held) return held;
    }
    if (best && best.id !== autoPickHoldRef.current.id) {
      autoPickHoldRef.current = { id: best.id, until: nowReal + 3200 };
    }
    return best ?? sorted[0] ?? null;
  })();

  const displayedRows = useMemo(() => {
    if (boardFilter === 'team' && teamSet.size > 0) {
      return sorted.filter((s) => teamSet.has(s.name) || s.name === opvName);
    }
    return sorted;
  }, [sorted, boardFilter, teamSet, opvName]);

  const orderKey = displayedRows.map((s) => s.id).join(',');

  // 纯 transform FLIP 顺滑滚榜超车动画（静帧或超长列表自动跳过）
  useLayoutEffect(() => {
    const container = boardBodyRef.current;
    if (!container || !motionFull() || displayedRows.length > 60) {
      if (container) {
        const nodes = container.querySelectorAll<HTMLElement>('[data-row-sid]');
        const nextMap = new Map<number, number>();
        nodes.forEach((el) => {
          const sid = Number(el.dataset.rowSid);
          nextMap.set(sid, el.getBoundingClientRect().top);
        });
        rowTopsRef.current = nextMap;
      }
      return;
    }
    const nodes = container.querySelectorAll<HTMLElement>('[data-row-sid]');
    const nextMap = new Map<number, number>();
    const moved: { el: HTMLElement; dy: number }[] = [];
    nodes.forEach((el) => {
      const sid = Number(el.dataset.rowSid);
      const newTop = el.getBoundingClientRect().top;
      const oldTop = rowTopsRef.current.get(sid);
      nextMap.set(sid, newTop);
      if (oldTop !== undefined) {
        const dy = oldTop - newTop;
        if (Math.abs(dy) >= 4 && Math.abs(dy) <= 360) {
          moved.push({ el, dy });
        }
      }
    });
    rowTopsRef.current = nextMap;
    if (!moved.length) return;

    moved.forEach(({ el, dy }) => {
      el.style.transition = 'none';
      el.style.transform = `translateY(${dy}px)`;
    });
    const raf = requestAnimationFrame(() => {
      moved.forEach(({ el }) => {
        el.style.transition = 'transform 260ms cubic-bezier(0.22, 1, 0.36, 1)';
        el.style.transform = 'translateY(0)';
      });
    });
    return () => cancelAnimationFrame(raf);
  }, [orderKey, displayedRows.length]);

  const remain = Math.max(0, contest.duration - contest.timeElapsed);
  const progress = Math.min(1, contest.timeElapsed / contest.duration);
  const avgEst = contest.students.length
    ? Math.round(contest.students.reduce((a, s) => a + totalEstimate(s, ioi), 0) / contest.students.length)
    : 0;
  const topEst = contest.students.reduce((a, s) => Math.max(a, totalEstimate(s, ioi)), 0);
  const submittedCells = contest.students.reduce(
    (a, s) => a + s.problems.filter((p) => p.submissions > 0).length,
    0,
  );
  const minuteKey = Math.floor(contest.timeElapsed / 60);
  const feed = useMemo(() => buildContestFeed(contest), [contest, minuteKey]);
  const milestones = useMemo(
    () => buildContestMilestones(contest),
    [contest, minuteKey, contest.submissions.length],
  );
  const cellW = contest.problems.length >= 9 ? 34 : contest.problems.length >= 7 ? 40 : 50;

  const ratings = useMemo(() => {
    const g = loadGrowth();
    return new Map(contest.students.map((s) => [s.id, profileOf(g, s.name).rating]));
  }, [contest]);
  const avgRating = Math.round(
    [...ratings.values()].reduce((a, b) => a + b, 0) / Math.max(1, ratings.size),
  );

  const sortedGuideLines = useMemo(
    () => (guideLines ?? []).slice().sort((a, b) => b.score - a.score),
    [guideLines],
  );

  // 最新一条高光快讯（赛程内 25 分钟内触发的大事记在榜首高亮播报）
  const activeBreaking = milestones.find((m) => contest.timeElapsed - m.time <= 25 * 60) ?? null;
  const inSlowMo = !paused && autoSlowMo && speed > 1 && nowReal < slowMoUntilRef.current;

  const handleLockStudent = (sid: number) => {
    setLockedFocusId(sid);
    setAutoDirector(false);
    setSpotlightOpen(true);
  };

  return (
    <div className="text-slate-200 pb-6">
      <header data-testid="contest-screen" className="ui-panel-hero relative overflow-hidden flex flex-wrap items-center justify-between gap-3 px-3.5 py-2.5 mb-2.5">
        {confettiSeqRef.current > 0 && motionFull() && (
          <div key={confettiSeqRef.current} className="pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
            {CONFETTI_OFFSETS.map((c, idx) => (
              <span
                key={idx}
                className="ui-confetti-piece absolute top-1 w-1.5 h-2.5"
                style={{ left: c.left, backgroundColor: c.color, '--dx': c.dx } as CSSProperties}
              />
            ))}
          </div>
        )}

        <div className="flex items-center gap-2.5">
          <span className="text-base font-black text-white">{roundLabel ?? 'OI 模拟赛'}</span>
          <span className={`text-[10.5px] px-1.5 py-0.5 border font-bold ${ioi ? 'border-emerald-500/40 bg-emerald-500/15 text-emerald-300' : 'border-amber-500/40 bg-amber-500/15 text-amber-200'}`}>
            {ioi ? 'IOI 实时榜' : 'OI 估分榜'}
          </span>
          <span className={`w-1.5 h-1.5 rounded-full ${paused ? 'bg-amber-400' : 'bg-emerald-400 ui-live'}`} />
          <span className="text-[11.5px] text-slate-300">
            {paused ? '已暂停' : inSlowMo ? '1x 特写慢放' : '进行中'}
          </span>
        </div>

        <div className="flex items-center gap-4">
          <div className="text-center">
            <div className="font-mono text-lg font-bold text-white leading-none">{formatTime(contest.timeElapsed)}</div>
            <div className="text-[10.5px] text-slate-400 mt-0.5">剩余 {formatTime(remain)}</div>
          </div>
          <div className="w-36">
            <div className="h-1.5 bg-slate-800 overflow-hidden">
              <div
                className="h-full transition-all"
                style={{ width: `${progress * 100}%`, background: progress > 0.8 ? '#eb737c' : progress > 0.5 ? '#eab454' : 'var(--mood-accent)' }}
              />
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => setPaused((p) => !p)}
            className={`px-2.5 py-1 text-[11.5px] font-bold transition-colors ${
              paused ? 'ui-btn-primary' : 'ui-btn-ghost text-amber-200 border-amber-500/40'
            }`}
          >
            {paused ? <><Ic n="play" /> 继续</> : <><Ic n="pause" /> 暂停</>}
          </button>
          <div className="flex bg-slate-900 border border-white/10 p-0.5">
            {[1, 2, 4].map((s) => (
              <button
                key={s}
                onClick={() => setSpeed(s)}
                title={`${s}x：1 秒现实时间 = ${s * 60} 秒比赛时间`}
                className={`px-2 py-0.5 text-[11px] font-bold transition-colors ${
                  speed === s ? 'ui-btn-primary' : 'text-slate-300 hover:text-white'
                }`}
              >
                {s}x
              </button>
            ))}
          </div>
          <button
            type="button"
            onClick={() => setAutoSlowMo((v) => !v)}
            data-testid="toggle-slowmo"
            title="快进观看时，遇到我队关键提交或犹豫交卷自动切 1x 特写 1.5 秒（不改变任何结果）"
            className={`px-2 py-1 text-[11px] border transition-colors ${
              autoSlowMo ? 'border-sky-400/45 bg-sky-500/12 text-sky-200 font-bold' : 'border-white/10 bg-slate-900 text-slate-400'
            }`}
          >
            <Ic n="eye" size={11} /> 特写慢放
          </button>
          <div className="flex bg-slate-900 border border-white/10 p-0.5">
            <button
              onClick={() => tick(contest, 600)}
              title="快进 10 分钟比赛时间"
              className="px-2 py-0.5 text-[11px] font-bold text-slate-200 hover:text-white hover:bg-white/10 transition-colors"
            >
              <Ic n="fastForward" /> +10 分
            </button>
            <button
              onClick={() => {
                const left = Math.max(0, contest.duration - contest.timeElapsed);
                const step = 1800;
                for (let t = 0; t < left; t += step) tick(contest, Math.min(step, left - t));
              }}
              title="直接跳到收卷（结果与自然播完完全一致）"
              data-testid="finish-paper"
              className="px-2 py-0.5 text-[11px] font-bold text-slate-200 hover:text-white hover:bg-white/10 transition-colors"
            >
              <Ic n="skipForward" /> 到收卷
            </button>
          </div>
        </div>
      </header>

      <div className={`mb-2 border px-3 py-1.5 text-[11.5px] flex flex-wrap items-center justify-between gap-2 ${ioi ? 'border-emerald-500/30 bg-emerald-500/10 text-emerald-200' : 'border-amber-500/30 bg-amber-500/10 text-amber-200'}`}>
        <div>
          {ioi ? (
            <><Ic n="radio" /> <b className="font-bold">IOI 赛制</b>：实时反馈真实判题结果（AC / WA / TLE / RE），单题取历史最高分，无 freopen 爆零。</>
          ) : (
            <><Ic n="alert" /> <b className="font-bold">OI 盲测赛制</b>：赛中无评测反馈，榜上 <b className="font-bold">≈分数</b> 为选手自估；交题仅封存代码，赛后统一揭晓挂分或反挂。</>
          )}
        </div>
        {!spotlightOpen && (
          <button
            type="button"
            onClick={() => setSpotlightOpen(true)}
            data-testid="reopen-spotlight"
            className="ui-pill text-slate-100"
          >
            <Ic n="eye" size={11} /> 展开导播聚焦台
          </button>
        )}
      </div>

      {/* 顶部高光快讯条（全场一血 / 榜首易主 / 防 AK 警报 / 疑似 AK） */}
      {activeBreaking && (
        <div
          key={`${activeBreaking.kind}-${activeBreaking.time}-${activeBreaking.title}`}
          data-testid="live-breaking-banner"
          className="ui-ticker-enter mb-2.5 border border-white/15 bg-[#0f1520] px-3 py-1.5 flex flex-wrap items-center gap-2 text-[11.5px]"
        >
          <span className={`px-1.5 py-0.5 text-[10px] font-bold border ${
            activeBreaking.tone === 'good'
              ? 'border-emerald-400/50 bg-emerald-500/20 text-emerald-200'
              : activeBreaking.tone === 'warn'
                ? 'border-amber-400/50 bg-amber-500/20 text-amber-200'
                : 'border-sky-400/50 bg-sky-500/20 text-sky-200'
          }`}>
            <Ic n="zap" size={10} /> 赛场快讯 · {activeBreaking.title}
          </span>
          <span className="font-mono text-[10.5px] text-slate-400">{formatTime(activeBreaking.time).slice(0, 5)}</span>
          <span className="text-slate-100 font-medium">{activeBreaking.text}</span>
        </div>
      )}

      {/* 不遮挡榜单的顶部「导播聚焦台」 + 提交前推镜特写 */}
      {spotlightOpen && focusedStudent && (
        <DirectorSpotlight
          contest={contest}
          student={focusedStudent}
          rank={ranks.get(focusedStudent.id) || 0}
          ioi={ioi}
          isTeam={teamSet.has(focusedStudent.name)}
          isOpv={focusedStudent.name === opvName}
          autoDirector={autoDirector}
          recentAction={
            recentActionRef.current &&
            recentActionRef.current.studentId === focusedStudent.id &&
            nowReal - recentActionRef.current.atReal < 2400
              ? recentActionRef.current
              : null
          }
          onToggleAuto={() => {
            if (!autoDirector) {
              setAutoDirector(true);
              setLockedFocusId(null);
            } else {
              setAutoDirector(false);
              setLockedFocusId(focusedStudent.id);
            }
          }}
          onFocusLeader={() => {
            if (sorted[0]) handleLockStudent(sorted[0].id);
          }}
          onFocusTeamTop={() => {
            const topSquad = sorted.find((s) => teamSet.has(s.name) || s.name === opvName);
            if (topSquad) handleLockStudent(topSquad.id);
          }}
          onOpenDrawer={() => setDrawerStudentId(focusedStudent.id)}
          onCollapse={() => setSpotlightOpen(false)}
        />
      )}

      <div className="grid grid-cols-1 xl:grid-cols-4 gap-2.5">
        <section className="xl:col-span-3 ui-panel overflow-hidden">
          {/* 榜单筛选与色例工具栏 */}
          <div className="flex flex-wrap items-center gap-2 px-3 py-1.5 border-b border-white/[0.07] bg-[#0b1018] text-[11px]">
            {teamSet.size > 0 && (
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => setBoardFilter('all')}
                  data-testid="board-filter-all"
                  className={`ui-pill ${boardFilter === 'all' ? 'ui-pill-active' : ''}`}
                >
                  全场 ({contest.students.length})
                </button>
                <button
                  type="button"
                  onClick={() => setBoardFilter('team')}
                  data-testid="board-filter-team"
                  className={`ui-pill ${boardFilter === 'team' ? 'ui-pill-active' : ''}`}
                >
                  只看我队 ({contest.students.filter((s) => teamSet.has(s.name) || s.name === opvName).length})
                </button>
              </div>
            )}
            <span className="text-slate-400">点选手锁定跟拍 · 双击或点右侧图标展开全卷思维链</span>
            <div className="ml-auto hidden sm:flex items-center gap-2 text-[10px] text-slate-400">
              <span className="inline-flex items-center gap-1"><i className="w-2 h-2 inline-block bg-emerald-400/60 border border-emerald-400" />100</span>
              <span className="inline-flex items-center gap-1"><i className="w-2 h-2 inline-block bg-sky-400/50 border border-sky-400" />50–99</span>
              <span className="inline-flex items-center gap-1"><i className="w-2 h-2 inline-block bg-amber-400/50 border border-amber-400" />1–45</span>
              <span className="inline-flex items-center gap-1"><i className="w-2 h-2 inline-block bg-rose-400/45 border border-rose-400" />0分</span>
            </div>
          </div>

          <div className="flex items-center px-3 py-2 ui-table-head text-[11px] font-medium">
            <div className="w-11 text-center">#</div>
            <div className="w-44 flex items-center gap-1">
              选手<span className="text-slate-400 font-normal">· Rating</span>
            </div>
            <div className="px-2" style={{ width: contest.problems.length * (cellW + 3) + 16 }}>
              {ioi ? '实时单题得分 / 评测' : '单题自估 / 考场动作'}
            </div>
            <div className="flex-1" />
            <div className="w-16 text-right">{ioi ? '总分' : '总估分'}</div>
            <div className="w-32 text-right">当前阶段</div>
          </div>

          <div ref={boardBodyRef} className="max-h-[calc(100vh-250px)] overflow-y-auto">
            {(() => {
              const renderedLines = new Set<number>();
              const countAbove = (lineScore: number) => {
                let allAbove = 0;
                let teamAbove = 0;
                for (const s of sorted) {
                  if (s.totalSubmissions > 0 && totalEstimate(s, ioi) >= lineScore) {
                    allAbove += 1;
                    if (teamSet.has(s.name)) teamAbove += 1;
                  }
                }
                return { allAbove, teamAbove };
              };

              const elements: ReactNode[] = [];
              displayedRows.forEach((st) => {
                const stScore = st.totalSubmissions > 0 ? totalEstimate(st, ioi) : -1;
                // 把分数刚好卡在当前选手上方的参考线插入榜单中
                sortedGuideLines.forEach((gl, gi) => {
                  if (!renderedLines.has(gi) && stScore < gl.score) {
                    renderedLines.add(gi);
                    const { allAbove, teamAbove } = countAbove(gl.score);
                    elements.push(
                      <ScoreReferenceDivider
                        key={`gl-${gi}-${gl.label}`}
                        line={gl}
                        ioi={ioi}
                        allAbove={allAbove}
                        teamAbove={teamAbove}
                        teamTotal={teamSet.size}
                      />,
                    );
                  }
                });

                const shift = rankShiftRef.current.get(st.id);
                const activeShift = shift && nowReal < shift.until ? shift.delta : 0;

                elements.push(
                  <StudentRow
                    key={st.id}
                    student={st}
                    rank={ranks.get(st.id) || 0}
                    rankDelta={activeShift}
                    problems={contest.problems}
                    cellW={cellW}
                    rating={ratings.get(st.id) ?? 1500}
                    ioi={ioi}
                    isTeam={teamSet.has(st.name)}
                    isOpv={st.name === opvName}
                    isFocused={focusedStudent?.id === st.id}
                    cellFxMap={cellFxRef.current}
                    nowReal={nowReal}
                    onFocus={() => handleLockStudent(st.id)}
                    onOpenDrawer={() => setDrawerStudentId(st.id)}
                  />,
                );
              });

              // 若所有展示选手均高于某条参考线，把它补在底部兜底显示
              sortedGuideLines.forEach((gl, gi) => {
                if (!renderedLines.has(gi)) {
                  renderedLines.add(gi);
                  const { allAbove, teamAbove } = countAbove(gl.score);
                  elements.push(
                    <ScoreReferenceDivider
                      key={`gl-tail-${gi}-${gl.label}`}
                      line={gl}
                      ioi={ioi}
                      allAbove={allAbove}
                      teamAbove={teamAbove}
                      teamTotal={teamSet.size}
                    />,
                  );
                }
              });

              return elements;
            })()}
          </div>
        </section>

        <aside className="space-y-2.5">
          <div className="ui-panel p-2.5">
            <h3 className="text-[11.5px] font-bold text-slate-200 mb-1.5"><Ic n="clipboard" /> 题目与过题热力</h3>
            <div className="space-y-1.5 max-h-[38vh] overflow-y-auto pr-1">
              {contest.problems.map((p, i) => (
                <ProblemCard
                  key={p.id}
                  problem={p}
                  index={i}
                  students={contest.students}
                  ioi={ioi}
                />
              ))}
            </div>
          </div>

          <div className="ui-panel p-2.5">
            <h3 className="text-[11.5px] font-bold text-slate-200 mb-1.5"><Ic n="chart" /> 统计</h3>
            <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-[11.5px]">
              <Stat label="总提交" value={`${contest.submissions.length}`} />
              <Stat label="已交题" value={`${submittedCells}`} />
              <Stat label={ioi ? '平均分' : '平均估分'} value={ioi ? `${avgEst}` : `≈${avgEst}`} />
              <Stat label={ioi ? '最高分' : '最高估分'} value={ioi ? `${topEst}` : `≈${topEst}`} />
              <Stat label="人均提交" value={`${(contest.submissions.length / Math.max(1, contest.students.length)).toFixed(1)} 次`} />
              <Stat label="剩余时间" value={formatTime(remain)} />
              <Stat label="平均 Rating" value={`${avgRating}`} />
            </div>
          </div>

          <div className="ui-panel border-amber-500/25 p-2.5">
            <div className="flex items-center justify-between gap-1.5 mb-1.5">
              <h3 className="text-[11.5px] font-bold text-slate-200"><Ic n="mic" /> 赛场实况</h3>
              <div className="flex gap-1">
                <button
                  type="button"
                  onClick={() => setFeedTab('live')}
                  data-testid="feed-tab-live"
                  className={`text-[10px] px-1.5 py-0.5 border ${feedTab === 'live' ? 'border-amber-400/50 bg-amber-500/15 text-amber-200 font-bold' : 'border-white/10 text-slate-400 hover:text-slate-200'}`}
                >
                  实时动态
                </button>
                <button
                  type="button"
                  onClick={() => setFeedTab('milestones')}
                  data-testid="feed-tab-milestones"
                  className={`text-[10px] px-1.5 py-0.5 border ${feedTab === 'milestones' ? 'border-amber-400/50 bg-amber-500/15 text-amber-200 font-bold' : 'border-white/10 text-slate-400 hover:text-slate-200'}`}
                >
                  大事记 ({milestones.length})
                </button>
              </div>
            </div>
            <div className="h-44 overflow-y-auto bg-black/35 px-2.5 py-2 space-y-1.5">
              {feedTab === 'live' ? (
                feed.length === 0 ? (
                  <div className="text-slate-400 text-[11px] text-center py-6">选手还在通读题面…</div>
                ) : feed.map((f, i) => (
                  <div key={`${f.name}-${i}`} className="text-[11px] leading-snug border-b border-white/[0.06] pb-1.5">
                    <span className="text-slate-300 font-medium">{f.name}</span>
                    <span className="mx-1 text-slate-500">·</span>
                    <span className={FEED_TONE[f.tone]}>{f.text}</span>
                  </div>
                ))
              ) : (
                milestones.length === 0 ? (
                  <div className="text-slate-400 text-[11px] text-center py-6">暂未触发一血 / 榜首易主等转折节点…</div>
                ) : milestones.map((m, i) => (
                  <div key={`${m.kind}-${m.time}-${i}`} className="text-[11px] leading-snug border-b border-white/[0.06] pb-1.5">
                    <div className="flex items-center gap-1.5">
                      <span className="font-mono text-[10px] text-slate-400">{formatTime(m.time).slice(0, 5)}</span>
                      <span className={`font-bold ${FEED_TONE[m.tone]}`}>{m.title}</span>
                    </div>
                    <div className="text-slate-200 mt-0.5">{m.text}</div>
                  </div>
                ))
              )}
            </div>
            <div className="text-[10.5px] text-slate-400 mt-1.5">取材于真实游记：开题、卡题、止损、一血、易主与防 AK 预警</div>
          </div>

          <div className="ui-panel p-2.5">
            <h3 className="text-[11.5px] font-bold text-slate-200 mb-1.5"><Ic n="radio" /> 提交动态</h3>
            <div className="h-40 overflow-y-auto bg-black/35 px-2 py-1.5">
              {contest.submissions.length === 0 ? (
                <div className="text-slate-400 text-[11px] text-center py-6">还没有人交代码…</div>
              ) : (
                contest.submissions
                  .slice(-30)
                  .reverse()
                  .map((s, i) => {
                    const stObj = contest.students.find((x) => x.id === s.studentId);
                    const att = stObj?.problems[s.problemId]?.attempts.find((a) => a.nth === s.nth);
                    return (
                      <div key={`${s.studentId}-${s.problemId}-${s.nth}-${i}`} className="flex items-center gap-1.5 text-[11px] py-0.5 border-b border-white/[0.05]">
                        <span className="text-slate-400 font-mono w-11 shrink-0">{formatTime(s.time).slice(0, 5)}</span>
                        <span className={`w-20 truncate ${teamSet.has(s.studentName) ? 'text-amber-200 font-bold' : 'text-slate-200'}`}>
                          {s.studentName}
                        </span>
                        <span className="text-slate-300 font-mono">P{s.problemId + 1}</span>
                        <span className="ml-auto font-mono text-[10px]">
                          {ioi && att ? (
                            att.score >= 100
                              ? <span className="text-emerald-300 font-bold">AC 100</span>
                              : att.damaged
                                ? <span className="text-rose-300">{att.reason.split(' ')[0]} {Math.round(att.score)}</span>
                                : <span className="text-sky-300">{Math.round(att.score)}分</span>
                          ) : (
                            <span className="text-slate-400">第 {s.nth} 次</span>
                          )}
                        </span>
                      </div>
                    );
                  })
              )}
            </div>
            <div className="text-[10.5px] text-slate-400 mt-1.5">{ioi ? 'IOI 实时评测 · 立即反馈判题状态与得分' : 'OI 盲测 · 仅记录封存时间与次数'}</div>
          </div>
        </aside>
      </div>

      {drawerStudentId !== null && (() => {
        const st = contest.students.find((s) => s.id === drawerStudentId);
        return st ? <FocusPanel contest={contest} student={st} onClose={() => setDrawerStudentId(null)} /> : null;
      })()}
    </div>
  );
}

// ===== 顶部导播聚焦台（不遮挡榜单 + 提交前特写推镜 + 实时思维链步骤） =====
function DirectorSpotlight({
  contest,
  student: st,
  rank,
  ioi,
  isTeam,
  isOpv,
  autoDirector,
  recentAction,
  onToggleAuto,
  onFocusLeader,
  onFocusTeamTop,
  onOpenDrawer,
  onCollapse,
}: {
  contest: Contest;
  student: Student;
  rank: number;
  ioi: boolean;
  isTeam: boolean;
  isOpv: boolean;
  autoDirector: boolean;
  recentAction: RecentAction | null;
  onToggleAuto: () => void;
  onFocusLeader: () => void;
  onFocusTeamTop: () => void;
  onOpenDrawer: () => void;
  onCollapse: () => void;
}) {
  const curIdx = st.currentProblem;
  const activeProb = curIdx !== null ? contest.problems[curIdx] : null;
  const activePs = curIdx !== null ? st.problems[curIdx] : null;
  const phase: Phase = st.finished ? 'done' : st.phase;
  const pc = phaseColor(phase);
  const totalEst = totalEstimate(st, ioi);

  const minutes = contest.duration / 60;
  const nowMin = contest.timeElapsed / 60;
  const traces = useMemo(
    () => tracesForStudent(st, contest.problems, minutes, ioi),
    // 按分钟粒度与当前题重算思维链，避免每帧分配开销
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [st, contest.problems, minutes, ioi, Math.floor(nowMin), curIdx, st.totalSubmissions],
  );
  const curTrace = curIdx !== null ? traces[curIdx] : null;
  const activeStep = useMemo(() => {
    if (!curTrace || !activePs || activePs.phase === 'idle') return null;
    const passed = curTrace.steps.filter((s) => s.minute <= nowMin);
    return curTrace.steps[passed.length] ?? passed[passed.length - 1] ?? curTrace.steps[0] ?? null;
  }, [curTrace, activePs, nowMin]);

  // 提交前犹豫 / 实时修锅 / 刚提交完成 → 触发推镜特写与字幕
  const isCloseUp =
    phase === 'deciding' ||
    phase === 'fixing' ||
    phase === 'restoring' ||
    Boolean(recentAction);

  let closeUpCaption: { text: string; tone: 'good' | 'sky' | 'amber' | 'rose' } | null = null;
  if (recentAction) {
    closeUpCaption = { text: recentAction.caption, tone: recentAction.tone };
  } else if (phase === 'deciding' && curIdx !== null) {
    closeUpCaption = {
      text: ioi
        ? `提交前特写：P${curIdx + 1} 本地样例已过，准备送交评测机 Running on tests…`
        : `提交前特写：P${curIdx + 1}（${activePs?.mode === 'brute' ? '暴力档' : '正解档'}）自测完毕，正在核对文件名准备封存代码…`,
      tone: 'amber',
    };
  } else if (phase === 'fixing' && curIdx !== null) {
    closeUpCaption = {
      text: `紧急抢修特写：P${curIdx + 1} 收到实时评测反馈，正全速定位边界 Bug 准备重交…`,
      tone: 'rose',
    };
  } else if (phase === 'restoring' && curIdx !== null) {
    closeUpCaption = {
      text: `求稳特写：P${curIdx + 1} 担心正解挂穿，正在把保底暴力覆盖回提交目录…`,
      tone: 'amber',
    };
  }

  const activeStageIndex = (() => {
    if (phase === 'survey') return 0;
    if (phase === 'reading') return 1;
    if (phase === 'thinking') return 2;
    if (phase === 'coding') return 3;
    if (phase === 'testing') return 4;
    if (phase === 'deciding' || phase === 'fixing' || phase === 'restoring') return 5;
    return -1;
  })();

  return (
    <div
      data-testid="director-spotlight"
      className={`ui-spotlight px-3.5 py-2.5 mb-2.5 ${isCloseUp ? 'ui-spotlight-zoom' : ''}`}
    >
      <div className="flex flex-wrap items-center gap-2 pb-2 border-b border-white/[0.07]">
        <span className="text-[10.5px] font-mono uppercase tracking-wider px-1.5 py-0.5 border border-white/15 bg-white/[0.04] text-slate-200">
          <Ic n="eye" size={11} /> 导播跟拍
        </span>
        <span className="text-[13.5px] font-black text-white">{st.name}</span>
        {isOpv && <span className="text-[10px] px-1.5 py-0.5 border border-amber-400/45 bg-amber-500/15 text-amber-200 font-bold"><Ic n="zap" size={10} /> OP</span>}
        {isTeam && <span className="text-[10px] px-1.5 py-0.5 border border-indigo-400/40 bg-indigo-500/15 text-indigo-200 font-bold">我队主力</span>}
        <span className="text-[11.5px] font-mono text-slate-300">
          {st.totalSubmissions > 0 ? `#${rank} · ${ioi ? `${totalEst} 分` : `≈${totalEst} 分`}` : '暂未交题'}
        </span>

        {isCloseUp && (
          <span className="text-[10px] px-1.5 py-0.5 bg-rose-500/20 border border-rose-400/50 text-rose-200 font-bold">
            LIVE 特写镜头
          </span>
        )}

        <div className="ml-auto flex flex-wrap items-center gap-1.5">
          <button
            type="button"
            onClick={onToggleAuto}
            data-testid="toggle-auto-director"
            className={`ui-pill ${autoDirector ? 'ui-pill-active' : ''}`}
            title="自动把镜头切给正在提交、修锅或领跑的我队主力；点击任意选手行则转为手动锁定"
          >
            <Ic n="radio" size={10} /> {autoDirector ? '自动导播中' : '手动锁定（点此回自动）'}
          </button>
          <button type="button" onClick={onFocusTeamTop} className="ui-pill" title="锁定我队当前最高分">
            我队头名
          </button>
          <button type="button" onClick={onFocusLeader} className="ui-pill" title="锁定全场榜首">
            全场榜首
          </button>
          <button
            type="button"
            onClick={onOpenDrawer}
            data-testid="spotlight-open-drawer"
            className="ui-pill text-emerald-200 border-emerald-500/35"
          >
            <Ic n="brain" size={11} /> 全卷思维链
          </button>
          <button
            type="button"
            onClick={onCollapse}
            data-testid="spotlight-close"
            className="ui-pill text-slate-400"
            title="收起顶部导播台"
          >
            <Ic n="x" size={11} />
          </button>
        </div>
      </div>

      {closeUpCaption && (
        <div
          data-testid="spotlight-closeup-caption"
          className={`mt-2 px-2.5 py-1 border-l-2 text-[11.5px] font-medium ${
            closeUpCaption.tone === 'good'
              ? 'border-emerald-400 bg-emerald-500/12 text-emerald-200'
              : closeUpCaption.tone === 'sky'
                ? 'border-sky-400 bg-sky-500/12 text-sky-200'
                : closeUpCaption.tone === 'rose'
                  ? 'border-rose-400 bg-rose-500/12 text-rose-200'
                  : 'border-amber-400 bg-amber-500/12 text-amber-200'
          }`}
        >
          {closeUpCaption.text}
        </div>
      )}

      <div className="mt-2 grid grid-cols-1 lg:grid-cols-[1.35fr_1fr] gap-3 items-center">
        <div className="space-y-1.5 min-w-0">
          <div className="flex flex-wrap items-center gap-2 text-[12px]">
            {activeProb && curIdx !== null ? (
              <>
                <span className="font-bold text-white">
                  正在攻克：P{curIdx + 1} · {activeProb.title}
                </span>
                <span
                  className="text-[10px] px-1.5 py-0.5 font-bold"
                  style={{ color: levelInfo(activeProb.level).ink, backgroundColor: levelInfo(activeProb.level).color + '2b' }}
                >
                  {levelInfo(activeProb.level).name}
                </span>
                <span className="text-[11px] text-slate-400">{TOPIC_NAMES[activeProb.topic]}</span>
              </>
            ) : (
              <span className="text-slate-300 font-medium">
                {st.finished ? '已提前收工等收卷' : phase === 'survey' ? '正在通读全卷题面评估开题顺序…' : '全卷可做题已扫完，正在检查文件名与边界…'}
              </span>
            )}
            <span className="ml-auto font-mono text-[11px] font-bold" style={{ color: pc }}>
              {phaseLabel(phase)} {st.finished ? '' : `${Math.round(st.phaseProgress * 100)}%`}
            </span>
          </div>

          {/* 6 步考场流水线进度轨道 */}
          <div className="grid grid-cols-6 gap-1">
            {PIPELINE_STEPS.map((step, idx) => {
              const doneStep = activeStageIndex > idx || st.finished;
              const isCur = activeStageIndex === idx && !st.finished;
              return (
                <div
                  key={step.id}
                  className={`px-1.5 py-1 border text-center text-[10px] relative overflow-hidden ${
                    isCur
                      ? 'border-white/40 bg-white/[0.07] text-white font-bold'
                      : doneStep
                        ? 'border-emerald-500/30 bg-emerald-500/[0.08] text-emerald-300'
                        : 'border-white/[0.07] bg-black/25 text-slate-500'
                  }`}
                >
                  <span>{step.label}</span>
                  {isCur && (
                    <span
                      className="absolute bottom-0 left-0 h-[2px]"
                      style={{ width: `${Math.round(st.phaseProgress * 100)}%`, backgroundColor: pc }}
                    />
                  )}
                </div>
              );
            })}
          </div>

          {activeStep && !st.finished && (
            <div className="text-[11.5px] text-slate-200 bg-black/30 border border-white/[0.06] px-2.5 py-1 truncate">
              <span className="text-amber-300 font-bold mr-1.5">[{kindName(activeStep.step.kind)}]</span>
              <span>{activeStep.step.text}</span>
            </div>
          )}
        </div>

        {/* 右侧：该选手各题实时状态小卡 */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
          {contest.problems.map((p, i) => {
            const est = problemEstimate(st, i, ioi);
            const ps = st.problems[i];
            const isCur = curIdx === i && !st.finished;
            const lastAtt = ps.attempts[ps.attempts.length - 1];
            const heat = cellHeatStyle(est, ioi, isCur, pc);
            return (
              <div
                key={p.id}
                className="px-2 py-1.5 border text-[11px]"
                style={{ backgroundColor: heat.bg, borderColor: heat.border }}
              >
                <div className="flex items-center justify-between font-mono">
                  <span className="text-slate-300 font-bold">P{i + 1}</span>
                  <span className="font-bold" style={{ color: heat.text }}>
                    {est === null ? (isCur ? '推演中' : '—') : ioi ? `${est}` : `≈${est}`}
                  </span>
                </div>
                <div className="mt-0.5 flex items-center justify-between text-[9.5px] text-slate-400">
                  <span className="truncate">
                    {ioi && lastAtt
                      ? (est !== null && est >= 100 ? 'AC' : lastAtt.damaged ? lastAtt.reason.split(' ')[0] : '部分分')
                      : ps.debugRounds > 0
                        ? `对拍返工×${ps.debugRounds}`
                        : ps.tested
                          ? '已对拍'
                          : ps.submissions > 0
                            ? `已交${ps.submissions}次`
                            : '未交'}
                  </span>
                  <span>{Math.round(ps.timeSpent / 60)}m</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ===== 榜单内嵌实时目标参考线 =====
function ScoreReferenceDivider({
  line,
  ioi,
  allAbove,
  teamAbove,
  teamTotal,
}: {
  line: ContestGuideLine;
  ioi: boolean;
  allAbove: number;
  teamAbove: number;
  teamTotal: number;
}) {
  const st = LINE_TONE_STYLE[line.tone];
  return (
    <div
      data-testid={`score-line-${line.label}`}
      className="px-3 py-1 bg-[#0a0f18] border-y border-white/[0.06] flex items-center gap-2 text-[10.5px]"
    >
      <span className={`px-1.5 py-0.5 border font-bold shrink-0 ${st.badge}`}>
        <Ic n="flag" size={10} /> {line.label} · {ioi ? `${line.score}` : `≈${line.score}`} 分
      </span>
      <div className={`flex-1 border-t border-dashed ${st.border}`} />
      <span className={`font-mono shrink-0 ${st.text}`}>
        全场达线 {allAbove} 人{teamTotal > 0 ? ` · 我队 ${teamAbove}/${teamTotal}` : ''}
      </span>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between">
      <span className="text-slate-500">{label}</span>
      <span className="text-slate-200 font-mono">{value}</span>
    </div>
  );
}

function ProblemCard({
  problem,
  index,
  students,
  ioi,
}: {
  problem: Problem;
  index: number;
  students: Student[];
  ioi: boolean;
}) {
  const L = levelInfo(problem.level);
  const c = L.color;
  const tc = TOPIC_COLORS[problem.topic];
  const total = Math.max(1, students.length);
  let fullCnt = 0;
  let partCnt = 0;
  let subUsers = 0;
  for (const st of students) {
    const est = problemEstimate(st, index, ioi);
    if (est !== null) {
      subUsers += 1;
      if (est >= 100) fullCnt += 1;
      else if (est > 0) partCnt += 1;
    }
  }
  const fullPct = (fullCnt / total) * 100;
  const partPct = (partCnt / total) * 100;

  return (
    <div className="rounded-lg border p-1.5" style={{ borderColor: c + '55', backgroundColor: c + '0d' }}>
      <div className="flex items-center justify-between">
        <span className="text-[10.5px] font-bold text-slate-200 truncate">
          P{index + 1} · {problem.title}
        </span>
        <span
          className="text-[9px] font-bold px-1 rounded whitespace-nowrap shrink-0"
          style={{ color: L.ink, backgroundColor: c + '33' }}
          title={L.en}
        >
          {L.name}
        </span>
      </div>
      <div className="flex items-center justify-between mt-1">
        <span className="text-[9.5px] px-1 rounded-full" style={{ color: tc, backgroundColor: tc + '22' }}>
          {TOPIC_NAMES[problem.topic]}
        </span>
        <span className="text-[9.5px] text-slate-400 font-mono">
          {ioi ? 'AC' : '估满'} {fullCnt}/{students.length} · 交 {subUsers}人
        </span>
      </div>
      {/* 通过率与部分分占比热力条 */}
      <div className="mt-1.5 h-1.5 bg-slate-900/90 overflow-hidden flex" title={`满分 ${fullCnt} 人 · 部分分 ${partCnt} 人`}>
        <div className="h-full bg-emerald-400" style={{ width: `${fullPct}%` }} />
        <div className="h-full bg-sky-400/80" style={{ width: `${partPct}%` }} />
      </div>
      <div className="flex gap-0.5 mt-1">
        {problem.subtasks.map((s, i) => (
          <span key={i} className="flex-1 text-center text-[8px] py-[1px] rounded bg-slate-800/80 text-slate-400">
            {s.points}
          </span>
        ))}
      </div>
    </div>
  );
}

function cellHeatStyle(
  est: number | null,
  ioi: boolean,
  active: boolean,
  phaseCol: string,
): { bg: string; text: string; border: string } {
  if (est === null) {
    return {
      bg: active ? 'rgba(255,255,255,0.06)' : 'rgba(255,255,255,0.025)',
      text: active ? '#cbd5e1' : '#475569',
      border: active ? phaseCol : 'rgba(148,163,184,0.13)',
    };
  }
  if (est >= 100) {
    return {
      bg: ioi ? 'rgba(80,207,158,0.26)' : 'rgba(80,207,158,0.18)',
      text: '#d1f8e8',
      border: active ? phaseCol : 'rgba(80,207,158,0.62)',
    };
  }
  if (est >= 50) {
    return {
      bg: 'rgba(86,194,212,0.18)',
      text: '#b2e8f1',
      border: active ? phaseCol : 'rgba(86,194,212,0.48)',
    };
  }
  if (est > 0) {
    return {
      bg: 'rgba(234,180,84,0.17)',
      text: '#fae0a8',
      border: active ? phaseCol : 'rgba(234,180,84,0.44)',
    };
  }
  return {
    bg: 'rgba(235,115,124,0.15)',
    text: '#fbc3c7',
    border: active ? phaseCol : 'rgba(235,115,124,0.40)',
  };
}

function fxBadgeStyle(kind: CellFxKind): { cls: string; anim: string } {
  switch (kind) {
    case 'ac':
      return { cls: 'bg-emerald-400 text-slate-950 font-black', anim: 'ui-fx-ac' };
    case 'gain':
      return { cls: 'bg-sky-400 text-slate-950 font-black', anim: 'ui-fx-gain' };
    case 'tle':
      return { cls: 'bg-amber-400 text-slate-950 font-black', anim: 'ui-fx-tle' };
    case 're':
      return { cls: 'bg-violet-400 text-slate-950 font-black', anim: 'ui-fx-re' };
    case 'wa':
      return { cls: 'bg-rose-500 text-white font-black', anim: 'ui-fx-wa' };
    case 'rework':
      return { cls: 'bg-rose-500/90 text-white font-bold', anim: 'ui-fx-rework' };
    case 'restore':
      return { cls: 'bg-amber-500 text-slate-950 font-bold', anim: 'ui-fx-seal' };
    case 'seal':
    default:
      return { cls: 'bg-amber-300 text-slate-950 font-bold', anim: 'ui-fx-seal' };
  }
}

function StudentRow({
  student: st,
  rank,
  rankDelta,
  problems,
  cellW,
  rating,
  ioi,
  isTeam,
  isOpv,
  isFocused,
  cellFxMap,
  nowReal,
  onFocus,
  onOpenDrawer,
}: {
  student: Student;
  rank: number;
  rankDelta: number;
  problems: Problem[];
  cellW: number;
  rating: number;
  ioi: boolean;
  isTeam: boolean;
  isOpv: boolean;
  isFocused: boolean;
  cellFxMap: Map<string, CellFx>;
  nowReal: number;
  onFocus: () => void;
  onOpenDrawer: () => void;
}) {
  const current = st.currentProblem;
  const done = st.finished;
  const phase = done ? 'done' : st.phase;
  const pc = phaseColor(phase);

  const rowBg = isFocused
    ? 'bg-white/[0.07]'
    : isTeam
      ? 'bg-indigo-500/[0.07] hover:bg-indigo-500/[0.11]'
      : rank <= 3 && st.totalSubmissions > 0
        ? 'bg-amber-400/[0.035] hover:bg-white/[0.03]'
        : 'hover:bg-white/[0.025]';

  return (
    <div
      data-row-sid={st.id}
      style={
        isFocused
          ? { boxShadow: 'inset 3px 0 0 #ffffff' }
          : isTeam
            ? { boxShadow: 'inset 3px 0 0 var(--mood-accent)' }
            : undefined
      }
      className={`flex items-center px-3 py-[5px] border-b border-slate-800/55 text-[11px] ${rowBg}`}
    >
      <div className="w-11 flex items-center justify-center gap-0.5 font-mono text-[10px] text-slate-400 shrink-0">
        {st.totalSubmissions === 0 ? (
          '—'
        ) : rank <= 3 && rank > 0 ? (
          <span className="ui-rank" data-r={rank}>{rank}</span>
        ) : (
          <span>{rank}</span>
        )}
        {rankDelta !== 0 && (
          <span
            className={`text-[9px] font-bold leading-none ${
              rankDelta > 0 ? 'text-emerald-300' : 'text-rose-300'
            }`}
          >
            {rankDelta > 0 ? `↑${rankDelta}` : `↓${Math.abs(rankDelta)}`}
          </span>
        )}
      </div>

      <div className="w-44 flex items-center gap-1 overflow-hidden pr-1.5">
        <button
          onClick={onFocus}
          onDoubleClick={onOpenDrawer}
          title="单击锁定顶部导播台跟拍；双击展开全卷思维链抽屉"
          data-testid={`focus-${st.name}`}
          className={`truncate text-left transition-colors ${
            isTeam || isOpv ? 'text-white font-bold hover:text-amber-200' : 'text-slate-200 font-medium hover:text-indigo-300'
          }`}
        >
          {st.name}
        </button>
        {isOpv && <span className="text-[9px] px-1 border border-amber-400/45 bg-amber-500/15 text-amber-200 font-bold shrink-0">OP</span>}
        {!isOpv && isTeam && <span className="text-[9px] px-1 border border-white/15 bg-white/[0.05] text-indigo-200 shrink-0">主力</span>}
        <button
          type="button"
          onClick={onOpenDrawer}
          title="打开全卷思维链详情"
          className="ml-auto text-slate-500 hover:text-slate-200 shrink-0 px-0.5"
        >
          <Ic n="brain" size={11} />
        </button>
        <span className="font-mono text-[9px] text-slate-500 shrink-0" title="当前 Rating">
          {rating}
        </span>
      </div>

      <div className="flex gap-[3px] px-2" style={{ width: problems.length * (cellW + 3) + 16 }}>
        {problems.map((_, i) => {
          const est = problemEstimate(st, i, ioi);
          const ps = st.problems[i];
          const active = current === i && !done;
          const fx = cellFxMap.get(`${st.id}#${i}`);
          const hasLiveFx = fx && nowReal < fx.until;
          const fxInfo = hasLiveFx ? fxBadgeStyle(fx.kind) : null;
          const heat = cellHeatStyle(est, ioi, active, pc);

          return (
            <Fragment key={i}>
              <div
                key={hasLiveFx ? `${i}-fx-${fx.seq}` : `${i}-base`}
                className={`relative h-6 flex items-center justify-center font-mono font-bold ${
                  cellW >= 40 ? 'text-[10.5px]' : 'text-[9px]'
                } ${fxInfo ? fxInfo.anim : ''}`}
                style={{
                  width: cellW,
                  backgroundColor: heat.bg,
                  color: heat.text,
                  border: `1px solid ${heat.border}`,
                }}
                title={`P${i + 1} · ${ps.submissions} 次提交${ps.debugRounds > 0 ? ` · 对拍返工 ${ps.debugRounds} 次` : ''}`}
              >
                {est === null ? (active ? '…' : '—') : ioi ? `${est}` : `≈${est}`}

                {/* 正在攻克该题时的底部内嵌进度细条 */}
                {active && (
                  <span
                    className="absolute bottom-0 left-0 h-[2px]"
                    style={{ width: `${Math.round(ps.progress * 100)}%`, backgroundColor: pc }}
                  />
                )}

                {/* 判题 / 封存瞬时特效角标 */}
                {hasLiveFx && fxInfo ? (
                  <span className={`absolute -top-1.5 -right-1 z-10 text-[7.5px] px-1 leading-[11px] ${fxInfo.cls}`}>
                    {fx.label}
                  </span>
                ) : !ioi && ps.debugRounds > 0 ? (
                  <span className="absolute -top-1 -right-1 text-[7px] px-[3px] bg-rose-900/90 text-rose-200 border border-rose-400/40 leading-[9px]">
                    拍×{ps.debugRounds}
                  </span>
                ) : ps.submissions > 1 ? (
                  <span className="absolute -top-1 -right-1 text-[7px] px-[3px] bg-slate-800 text-slate-300 border border-white/10 leading-[9px]">
                    {ps.submissions}
                  </span>
                ) : null}
              </div>
            </Fragment>
          );
        })}
      </div>

      <div className="flex-1" />

      <div className="w-16 text-right font-mono font-bold text-slate-100">
        {st.totalSubmissions === 0 ? (
          <span className="text-slate-600">—</span>
        ) : ioi ? (
          `${totalEstimate(st, ioi)}`
        ) : (
          `≈${totalEstimate(st, ioi)}`
        )}
      </div>

      <div className="w-32 flex justify-end pl-2">
        {done ? (
          <span className="text-[10px] text-emerald-400/85 font-medium">收工待卷</span>
        ) : (
          <div className="flex flex-col items-end w-full">
            <span className="text-[9.5px] truncate max-w-full" style={{ color: pc }}>
              {phaseLabel(phase)}
              {current !== null ? ` · P${current + 1}` : ''} {Math.round(st.phaseProgress * 100)}%
            </span>
            <div className="w-20 h-1 bg-slate-800 mt-0.5 overflow-hidden">
              <div className="h-full" style={{ width: `${st.phaseProgress * 100}%`, backgroundColor: pc }} />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  return <div className="min-h-screen bg-[#08090c] text-slate-200 p-4">{children}</div>;
}
