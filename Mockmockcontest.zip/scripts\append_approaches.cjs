const fs = require('fs');

const block = `
// ---------- 同一道题的多种正解 ----------
// 只用于「按知识点随机生成」的题（题目专属链另有一套明确做法）。
// 同一条链必须在同一套观察/转化之后都能接上，所以每个分支只替换「结构 + 优化」两步。
export interface Approach {
  name: string;
  structure: string;
  optimize: string;
}

export const APPROACHES: Record<Topic, Approach[]> = {
  math: [
    {
      name: '推式子 + 线性筛',
      structure: '把答案写成前缀和的差，贡献拆到每个质因子上，O(n log log n) 预处理、O(1) 询问',
      optimize: '直接在线性筛里记最小质因子，边筛边算前缀，省掉第二遍循环',
    },
    {
      name: '杜教筛 / 整除分块',
      structure: '对 n/(i) 只有 O(√n) 种取值，按块跳，块内整体乘系数',
      optimize: '把已经算过的前缀和丢进 map 记忆化，递归层数就压到 O(n^(2/3))',
    },
  ],
  dp: [
    {
      name: '转移方程 + 前缀和优化',
      structure: '把 f[i] = f[j] + w(j) 的枚举区间拆成前后缀，边转移边维护前缀和',
      optimize: 'w(j) 只和 j 有关时，把前缀 min 提前维护好，每层就降到 O(1)',
    },
    {
      name: '线段树优化转移',
      structure: '转移区间不固定：把 f[j] 按 j 塞进线段树，询问是区间 max',
      optimize: '按右端点递增插入、查询 [l, r]，整体 O(n log n)，注意多测要清整棵树',
    },
  ],
  graph: [
    {
      name: '堆优化 Dijkstra',
      structure: '边权非负，用 priority_queue 每次取当前距离最小的点，懒删除过期项',
      optimize: '只把「松弛成功」的边 push 进堆，堆大小压到 O(m)，常数好很多',
    },
    {
      name: '缩点 + 拓扑',
      structure: 'Tarjan 求强连通分量，缩成一个点后变成 DAG，按拓扑序递推',
      optimize: '在 Tarjan 里顺便做递推，省掉一遍建图和拓扑排序',
    },
  ],
  greedy: [
    {
      name: '排序 + 反悔贪心',
      structure: '按右端点排序，能放就放；放不下时把代价最大的那个换掉',
      optimize: '用堆维护已选集合的最大值，每次 O(log n)，总复杂度 O(n log n)',
    },
    {
      name: '二分答案 + 检查',
      structure: '答案单调：二分最小可行值，check 里贪心地尽量少用资源',
      optimize: 'check 里的枚举用双指针或前缀和压掉，整体 O(n log V)',
    },
  ],
  ds: [
    {
      name: '树状数组 + 差分',
      structure: '区间加、单点查用差分，单点加、区间求和用树状数组，lowbit 跳着走',
      optimize: '两种操作一起要就上树状数组维护两个前缀，常数比线段树小一半',
    },
    {
      name: '线段树 + 懒标记',
      structure: '区间操作需要合并答案，懒标记把「先记账、真的要用再下传」做掉',
      optimize: 'pushdown 只在区间被完全覆盖时做，查询边界时别忘记先下传',
    },
  ],
  impl: [
    {
      name: '分步模拟 + 状态压缩',
      structure: '按时间线推进，把「当前状态」写成结构体整体迁移，每一步只动相关的几个字段',
      optimize: '把重复扫描换成桶/队列，同一层的事件一起处理，复杂度从 O(n²) 降到 O(n + 事件数)',
    },
    {
      name: '预处理 + 查表',
      structure: '先把所有可能出现的形贡献预处理出来，询问时直接查表',
      optimize: '表只开实际用得到的范围，多测共用一次预处理，别每组重做',
    },
  ],
  string: [
    {
      name: '哈希 + 二分',
      structure: '二分最长长度，前后缀哈希 O(1) 比较，答案单调可二分',
      optimize: '双模数防卡、基随机；比较时先比长度再比哈希，能省掉大半比较',
    },
    {
      name: 'KMP / Z 函数',
      structure: '求出每个前缀的最长 border，失配时沿 border 跳，总复杂度 O(n + m)',
      optimize: 'next 数组只算一遍，多串匹配时把它当自动机用，主串指针不回退',
    },
  ],
  geometry: [
    {
      name: '极角排序 + 扫描',
      structure: '按极角排序后单调栈维护凸壳，新点让栈顶变凹就弹掉',
      optimize: '排序是瓶颈，点已经有序时直接 O(n)；注意共线点要不要保留',
    },
    {
      name: '叉积判向 + 二分',
      structure: '凸包上找切线可以二分：用叉积符号判断在哪个单调段上',
      optimize: '预处理一下上下凸壳的分界点，把 O(log n) 的常数压下来',
    },
  ],
};
`;

const p = 'src/chains.ts';
let s = fs.readFileSync(p, 'utf8');
if (s.includes('export const APPROACHES')) {
  console.log('already');
  process.exit(0);
}
s = s.replace("import type { IdeaKind } from './thinking.ts';", "import type { IdeaKind } from './thinking.ts';\nimport type { Topic } from './types.ts';");
s = s + block;
fs.writeFileSync(p, s, 'utf8');
console.log('appended', fs.statSync(p).size);
